import React, { useEffect } from "react";
import { Box, Divider } from "@mui/material";
import { parseCookies } from "nookies";
import { useRouter } from "next/router";
import useSocket from "../utils/func/socket/useSocket";
import getUserInfo from "../utils/func/auth/getUserInfo";
import newMsgSound from "../utils/func/messages/newMessageSound";
import InputMessage from "../components/molecules/messages/InputMessage";
import Chat from "../components/molecules/messages/Chat";
import BannerChat from "../components/molecules/messages/Banner";
import ProfileChat from "../components/molecules/messages/ProfileChat";
import Message from "../components/molecules/messages/Message";
import { convertFilePathToURL } from "../utils/func/s3";
import ChatListSearch from "../components/molecules/messages/ChatListSearch";
import deleteDataFunc from "./../utils/func/api/deleteDataFunc";
import NoMessage from "./../components/molecules/messages/NoMessage";
import { Stack } from "@mui/material";
import Image from "next/image";
export const getServerSideProps = async (ctx) => {
  let authorize = {};
  let data = [];
  try {
    const token = parseCookies(ctx)?.token_user;
    if (token) {
      authorize = JSON.parse(token);
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/chats`,
        {
          headers: {
            "x-access-token": authorize.accessToken,
          },
        }
      );
      data = await res.json();
    }

    return {
      props: {
        chatsData: data,
      },
    };
  } catch (error) {
    return { errorLoading: true };
  }
};

const scrollDivToBottom = (divRef) => {
  divRef.current && divRef.current.scrollIntoView({ behaviour: "smooth" });
};
const Chats = ({ chatsData, user }) => {
  // console.log(chatsData);
  // console.log(user.data);
  const userInfo = user.data || {};
  const [chats, setChats] = React.useState(chatsData);
  const [connectedUsers, setConnectedUsers] = React.useState([]);
  const [messages, setMessages] = React.useState([]);
  const [bannerData, setBannerData] = React.useState({
    name: "",
    coverFileName: "",
    email: "",
  });
  const router = useRouter();
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const openChatId = React.useRef("");
  const divRef = React.useRef("");

  // convert chat path to url
  React.useEffect(() => {
    convertFilePathToURL(chatsData).then((data) => {
      setChats(data);
    });
  }, []);
  React.useEffect(() => {
    if (chats.length > 0 && router.query.message)
      router.push(`/messages?message=${chats[0].messageWith}`, undefined, {
        shallow: true,
      });
  }, []);

  React.useEffect(() => {
    if (socket) {
      // console.log("User ID :", userInfo._id);
      socket.emit("join", { userId: userInfo._id });
      socket.on("connectedUsers", ({ users }) => {
        users.length > 0 && setConnectedUsers(users);
      });
    }
  }, [socket]);

  React.useEffect(() => {
    const loadMessages = () => {
      socket.emit("loadMessages", {
        userId: userInfo._id,
        messageWith: router.query.message,
      });
      socket.on("messagesLoaded", ({ chat }) => {
        console.log("messagesLoaded ====", chat);
        setMessages(chat.messages);
        setBannerData({
          name: chat.messageWith.name,
          coverFileName: chat.messageWith.coverFileName,
          email: chat.messageWith.email,
        });
        openChatId.current = chat.messageWith._id;
      });
      socket.on("noChatFound", async () => {
        const user = await getUserInfo(router.query.message);
        setBannerData({
          name: user.name,
          coverFileName: user.coverFileName,
          email: user.email,
        });
        setMessages([]);
        openChatId.current = router.query.message;
        divRef.current && scrollDivToBottom(divRef);
      });
    };
    if (socket && router.query.message) {
      loadMessages();
    }
  }, [router.query.message]);

  React.useEffect(() => {
    if (socket) {
      socket.on("msgSent", ({ newMsg }) => {
        // console.log("Message Sent Client", newMsg.reciever, openChatId.current);
        if (newMsg.reciever === openChatId.current) {
          setMessages((prev) => [...prev, newMsg]);
          setChats((prev) => {
            let previousChat = prev.find(
              (chat) => chat.messageWith === newMsg.reciever
            );
            if (!previousChat) {
              previousChat = {};
            }
            previousChat.lastMessage = newMsg.msg;
            previousChat.data = newMsg.date;
            return [...prev];
          });
        }
      });
      socket.on("newMsgReceived", async ({ newMsg }) => {
        console.log("Message Receiver. ");
        let senderName;
        // when chat is opened inside your browser
        if (newMsg.sender === openChatId.current) {
          setMessages((prev) => [...prev, newMsg]);
          setChats((prev) => {
            const previousChat = prev.find(
              (chat) => chat.messageWith === newMsg.sender
            );
            previousChat.lastMessage = newMsg.msg;
            previousChat.date = newMsg.date;
            senderName = previousChat.name;

            return [...prev];
          });
        } else {
          const ifPreviouslyMessaged =
            chats.filter((chat) => chat.messageWith === newMsg.sender).length >
            0;
          if (ifPreviouslyMessaged) {
            setChats((prev) => {
              const previousChat = prev.find(
                (chat) => chat.messageWith === newMsg.sender
              );
              previousChat.lastMessage = newMsg.msg;
              previousChat.date = newMsg.date;
              senderName = previousChat.name;
              return [...prev];
            });
          } else {
            const user = await getUserInfo(newMsg.sender);
            senderName = user.name;
            const newChat = {
              messageWith: newMsg.sender,
              name: user.name,
              coverFileName: user.coverFileName,
              lastMessage: newMsg.msg,
              date: newMsg.date,
            };
            setChats((prev) => [newChat, ...prev]);
          }
        }
        newMsgSound(senderName);
      });
    }
  }, [socket]);

  useEffect(() => {
    messages.length > 0 && scrollDivToBottom(divRef);
  }, [messages]);

  const sendMsg = (msg) => {
    // console.log("UserID", openChatId.current);
    socket.emit("sendNewMsg", {
      userId: userInfo._id,
      msgSendToUserId: openChatId.current,
      msg,
    });
  };

  const deleteMsg = (messageId) => {
    if (socket) {
      console.log("DELETE MSG");
      socket.emit("deleteMsg", {
        userId: userInfo._id,
        messageWith: openChatId.current,
        messageId,
      });
      socket.on("msgDeleted", () => {
        setMessages((prev) =>
          prev.filter((message) => message._id != messageId)
        );
      });
    }
  };
  const deleteChat = async (messageWith) => {
    try {
      const res = await deleteDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/chats/${messageWith}`
      );
      console.log(res);
      setChats((prev) =>
        prev.filter((chat) => chat.messageWith !== messageWith)
      );
      router.push("/messages", undefined, { shallow: true });
      openChatId.current = "";
    } catch (error) {
      alert("Error deleting chat");
    }
  };

  return (
    <Box>
      <Stack direction="row">
        <Box sx={{ width: 375 }}>
          <Box sx={{ p: 2 }}>
            <ProfileChat user={userInfo} />
          </Box>
          <Divider />
          <Box sx={{ mb: 1, mt: 1 }}>
            <ChatListSearch chats={chats} setChats={setChats} />
          </Box>
          <Divider />

          {chats.length > 0 ? (
            chats.map((chat, i) => {
              return (
                <Chat
                  key={i}
                  chat={chat}
                  connectedUsers={connectedUsers}
                  deleteChat={deleteChat}
                />
              );
            })
          ) : (
            <NoMessage message={"No Chat Found"} />
          )}
        </Box>

        <Box sx={{ width: "100%", minWidth: 400 }}>
          {openChatId.current ? (
            <>
              <Box sx={{ m: 1 }}>
                <BannerChat user={bannerData} />
              </Box>
              <Divider />
              <Box
                sx={{
                  height: "70vh",
                  borderLeft: "1px solid lightblue",
                  overflowY: "scroll",
                }}
              >
                {messages.map((msg, index) => {
                  return (
                    <Message
                      key={index}
                      user={userInfo}
                      message={msg}
                      senderProfile={userInfo.coverFileName}
                      receiverProfile={bannerData.coverFileName}
                      deleteMsg={() => deleteMsg(msg._id)}
                      divRef={divRef}
                    />
                  );
                })}
              </Box>
              <Divider />
              <InputMessage
                profile={userInfo.coverFileName}
                sendMsg={sendMsg}
              />
            </>
          ) : (
            <Box sx={{ width: 300, display: "block", margin: "0px auto" }}>
              <Image
                src={"/images/noMessage.svg"}
                alt="No Message"
                height={500}
                width={300}
              />
              <NoMessage message={"Leave with the message"} />
            </Box>
          )}
        </Box>
      </Stack>
    </Box>
  );
};

export default Chats;
