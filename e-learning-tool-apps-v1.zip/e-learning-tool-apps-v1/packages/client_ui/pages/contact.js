import React, { useState } from "react";
import {
  Box,
  Stack,
  Typography,
  Grid,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Dialog,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import { makeStyles } from "@mui/styles";

// conponents
import HeaderTitle from "../components/molecules/HeaderTitle";
import IconTypography from "../components/molecules/typography/IconTypography";

//model
import { contactBy } from "../utils/constant/contact";
import unauthPostDataFunc from "./../utils/func/api/unauthPostFunc";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
  contact_by: {
    width: "100%",
    height: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  map_frame: {
    width: "100%",
    height: 500,
    [theme.breakpoints.down("md")]: {
      height: 400,
    },
    [theme.breakpoints.down("sm")]: {
      height: 300,
    },
  },
  iframeMap: {
    width: "100%",
    height: "100%",
    border: "none",
  },
  title_contact_information: {
    margin: "0px auto",
    marginTop: 80,
    marginBottom: 20,
    textAlign: "center",
    [theme.breakpoints.down("md")]: {
      marginTop: 60,
      marginBottom: 10,
    },
    [theme.breakpoints.down("sm")]: {
      marginTop: 40,
      marginBottom: 5,
    },
  },
  contact_image: {
    width: "90%",
    height: "100%",
    margin: "0 auto",
    backgroundImage: "url(./images/sentMessage.png)",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
  button: {
    width: "100%",
    marginTop: 20,
    display: "flex",
    justifyContent: "right",
  },
}));

export const getServerSideProps = async (ctx) => {
  let subjects = [];
  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/department`
  );
  subjects = await res.json();

  return {
    props: {
      subjects,
    },
  };
};
const Contact = ({ subjects }) => {
  const classes = useStyles();

  const [open, setOpen] = React.useState(false);
  
  return (
    <Box className={classes.root}>
      <Box>
        <HeaderTitle
          text={
            "Our goal is not to produce future computer scientists (although we would not be surprised if it happens). Our goal is to introduce computer science fundamentals to students at a young age. So that they do not grow up intimidated by computer science field."
          }
        />
      </Box>
      <Box className={classes.container}>
        {/* contact by */}
        <Grid container rowSpacing={4} columnSpacing={2}>
          <Grid item xs={12} sm={5}>
            <Box className={classes.contact_by}>
              <Stack spacing={{ xs: 2, sm: 3, md: 4, lg: 5 }}>
                <Typography variant="title">You Can Contact us by:</Typography>
                {contactBy.map((item, index) => {
                  return (
                    <IconTypography
                      key={index}
                      icon={item.icon}
                      title={item.title}
                    />
                  );
                })}
              </Stack>
            </Box>
          </Grid>
          <Grid item xs={12} sm={7}>
            <Box className={classes.map_frame}>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3882.675620102311!2d103.84787305064931!3d13.308192190589754!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x311019a3422af079%3A0xc3ec604987f983cb!2sAranh%20Sakor%20Cuthbert%20Primary%20and%20Junoir%20High%20School!5e0!3m2!1sen!2skh!4v1630332892578!5m2!1sen!2skh"
                loading="lazy"
                className={classes.iframeMap}
              />
            </Box>
          </Grid>
        </Grid>

        {/* contact information*/}
        <Grid container rowSpacing={4} columnSpacing={2}>
          <Grid item xs={12}>
            <Box className={classes.title_contact_information}>
              <Typography variant="title">CONTACT INFORMATION</Typography>
              <br />
              <Typography variant="primary">
                Don&rsquo;t hesitate to ask questions or make comments
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={0} sm={12} md={6}>
            <Box className={classes.contact_image} />
          </Grid>
          <Grid item xs={12} md={6}>
            <form onSubmit={handleContactUs}>
              <Stack spacing={3}>
                <TextField
                  variant="standard"
                  fullWidth
                  required
                  type="text"
                  size="small"
                  label="Name"
                  name="name"
                />
                <TextField
                  variant="standard"
                  fullWidth
                  type="email"
                  size="small"
                  label="Email"
                  name="email"
                />
                <TextField
                  required
                  variant="standard"
                  fullWidth
                  type="tel"
                  size="small"
                  label="Phone Number"
                  name="phone"
                />
                <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
                  <InputLabel id="demo-select-small">Subject</InputLabel>
                  <Select
                    required
                    name="subject"
                    variant="standard"
                    labelId="demo-select-small"
                    id="demo-select-small"
                    label="Subject"
                  >
                    {subjects.map((item, index) => {
                      return (
                        <MenuItem key={index} value={item._id}>
                          {item.name}
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
                <TextField
                  variant="outlined"
                  fullWidth
                  required
                  type="text"
                  size="small"
                  multiline
                  rows={6}
                  label="Message"
                  name="message"
                />
              </Stack>
              <Box className={classes.button}>
                <Button type="submit" variant="contained">
                  Submit
                </Button>
              </Box>
              {message != "" && (
                <Typography color={"secondary"}>{message}</Typography>
              )}
            </form>
          </Grid>
        </Grid>
      </Box>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>Contact Us</DialogTitle>
        <DialogContent>
          <Typography>
            Thank you for your message. We will contact you back soon.
          </Typography>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Contact;
