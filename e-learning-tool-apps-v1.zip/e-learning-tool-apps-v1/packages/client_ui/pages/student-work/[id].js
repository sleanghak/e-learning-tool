import React from "react";
import { Box, Grid, Typography, Button, Stack } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { FacebookShareButton } from "react-share";
import Carousel from "react-material-ui-carousel";
import StudentTeamProfile from "../../components/molecules/StudentTeamProfile";
import StudentProjectCard from "../../components/molecules/cards/StudentProjectCard";
import unauthFetcher from "../../utils/func/api/unauthFetch";
import useSWR from "swr";
import {
  convertFilePathToURL,
  convertFilePathToURLs,
} from "../../utils/func/s3";
import { toDateFormat } from "./../../utils/func/toDateFormat";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    marginTop: "50px",
  },
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
  project_image: {
    width: "100%",
    height: "350px",
    [theme.breakpoints.down("md")]: {
      height: "250px",
    },
    [theme.breakpoints.down("sm")]: {
      height: "320px",
    },
    backgroundPosition: "center",
    backgroundSize: "cover",
  },
  team_section: {
    marginTop: 50,
  },
  team_profile_box: {
    width: "100%",
    display: "flex",
    justifyContent: "center",
  },
  team_profile: {
    maxWidth: "800px",
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  section: {
    marginBottom: 100,
  },
  title: {
    margin: "50px 0",
  },
}));
export async function getServerSideProps(ctx) {
  let projects = {};
  const id = ctx.query.id;
  try {
    projects = await unauthFetcher(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/student_work?studentWorkId=${id}`
    );
  } catch (error) {
    console.log(error);
  }

  return {
    props: {
      projects,
    },
  };
}
const StudentProjectDetail = ({ projects }) => {
  // console.log("project ID:", projects);
  const classes = useStyles();
  const [data, setData] = React.useState({});

  const allProjects = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/student_work?status=false&&courseId=${projects?.data?.course?._id}&&page=1`,
    unauthFetcher
  ).data;

  React.useEffect(async () => {
    if (projects.data) {
      setData({
        ...projects.data,
        images: await convertFilePathToURLs(projects.data.images),
        students: await convertFilePathToURL(projects.data.students),
      });
    }
  }, []);
  return (
    <Box className={classes.root}>
      <Box className={classes.container}>
        <Grid container spacing={5}>
          <Grid item xs={12} sm={6} lg={6}>
            <Box>
              <Carousel swipe={true} fullHeightHover={true}>
                {data?.images?.map((cover, index) => {
                  return (
                    <Box
                      key={index}
                      className={classes.project_image}
                      sx={{ backgroundImage: `url('${cover}')` }}
                    />
                  );
                })}
              </Carousel>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6} lg={6}>
            <Box>
              <Stack spacing="30px" direction="column">
                <Box>
                  <Typography variant="title">{data.name}</Typography>
                </Box>
                <Box>
                  <Typography>{data.description}</Typography>
                </Box>
                <Box>
                  <Typography>{toDateFormat(data.date)}</Typography>
                </Box>
                <Box>
                  <FacebookShareButton url={data.link} hashtag={"#SabaiCode"}>
                    <Button variant="outlined" sx={{ mr: "20px", mb: "20px" }}>
                      Share
                    </Button>
                  </FacebookShareButton>

                  <Button
                    variant="contained"
                    sx={{ mb: "20px" }}
                    href={data.link}
                    target="_blank"
                  >
                    Visit
                  </Button>
                </Box>
              </Stack>
            </Box>
          </Grid>
        </Grid>
        <Box className={classes.team_section}>
          <Box sx={{ mb: "25px", textAlign: "center" }}>
            <Typography variant="secondary">Team</Typography>
          </Box>
          <Box className={classes.team_profile_box}>
            <Box className={classes.team_profile}>
              {data?.students?.map((student, index) => {
                return (
                  <StudentTeamProfile
                    key={index}
                    profileImage={student.coverFileName}
                    name={student.name}
                    position={student.position}
                  />
                );
              })}
            </Box>
          </Box>
        </Box>
        {allProjects?.data ? (
          <>
            <Box className={classes.section}>
              <Box className={classes.title}>
                <Typography variant="title">
                  {allProjects?.data?.length > 0 &&
                    allProjects?.data[0]?.course?.name}
                </Typography>
              </Box>
              <Grid container spacing={{ xs: 3, md: 5 }}>
                {allProjects?.data?.map((project, index) => {
                  return (
                    <Grid item xs={12} sm={6} md={4} key={index}>
                      <StudentProjectCard
                        key={index}
                        cover={project.images[0]}
                        title={project.name}
                        team={project.students}
                        isDynamic={true}
                        projectId={project._id}
                      />
                    </Grid>
                  );
                })}
              </Grid>
            </Box>
          </>
        ) : (
          <div>Loading ...</div>
        )}
      </Box>
    </Box>
  );
};
export default StudentProjectDetail;
