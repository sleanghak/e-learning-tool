import React, { useState, useEffect } from "react";
import { Box, Typography, Grid } from "@mui/material";
import { makeStyles } from "@mui/styles";
import StudentProjectCard from "../../components/molecules/cards/StudentProjectCard";
import HeaderTitle from "../../components/molecules/HeaderTitle";
import unauthFetcher from "../../utils/func/api/unauthFetch";
import { groupBy } from "../../utils/func/objects";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
  section: {
    marginBottom: 100,
  },
  title: {
    margin: "50px 0",
  },
}));
export async function getServerSideProps(ctx) {
  let projects = [];
  try {
    projects = await unauthFetcher(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/student_work?status=false`
    );
  } catch (error) {
    console.log(error);
  }

  return {
    props: {
      projects,
    },
  };
}
const StudentProject = ({ projects }) => {
  const classes = useStyles();

  return (
    <Box className={classes.root}>
      <HeaderTitle
        text={
          "Our goal is not to produce future computer scientists (although we would not be surprised if it happens). Our goal is to introduce computer science fundamentals to students at a young age. So that they do not grow up intimidated by computer science field."
        }
      />
      <Box className={classes.container}>
        <Box className={classes.section}>
          {groupBy(projects.data, (sub) =>
            JSON.stringify({ name: sub.course.name })
          ).map((subject, index) => {
            return (
              <Box key={index}>
                <Box className={classes.title}>
                  <Typography variant="title">
                    {subject?.label?.name}
                  </Typography>
                </Box>
                <Grid key={index} container spacing={{ xs: 3, md: 5 }}>
                  {subject.data.map((project, index) => {
                    return (
                      <Grid item xs={12} sm={6} md={4} key={index}>
                        <StudentProjectCard
                          cover={project.images[0]}
                          title={project.name}
                          team={project.students}
                          projectId={project._id}
                        />
                      </Grid>
                    );
                  })}
                </Grid>
              </Box>
            );
          })}
          {/* {projects?.data?.map((pro, index) => {
              return (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <StudentProjectCard
                    key={index}
                    cover={pro.images[0]}
                    title={pro.name}
                    team={pro.students}
                    projectId={pro._id}
                  />
                </Grid>
              );
            })} */}
        </Box>
      </Box>
    </Box>
  );
};
export default StudentProject;
