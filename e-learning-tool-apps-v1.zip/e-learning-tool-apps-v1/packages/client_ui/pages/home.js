import React, { useState } from "react";
import { Box, Grid, Stack, Divider, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";
import ShowMoreText from "react-show-more-text";

//component
import HeaderTitle from "../components/molecules/HeaderTitle";
import Collaboration from "../components/molecules/Collaboration";
import FeedbackSetion from "../components/templates/classes/FeedbackSetion";
import StoryCard from "../components/organisms/cards/StoryCard";
import { UpcomingClassCard } from "../components/organisms/cards";

// data
import {
  text,
  ourschool,
  ourschools,
  whyHowWhat,
} from "../utils/constant/home";
import { convertFilePathToURL } from "../utils/func/s3";
import useSocket from "../utils/func/socket/useSocket";

const useStyles = makeStyles((theme) => ({
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
}));

export async function getServerSideProps(ctx) {
  let posts = [];
  let reviews = [];
  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/reviews`
  );

  const resPost = await fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/post?status=false`
  );
  posts = await resPost.json();
  reviews = await res.json();
  return {
    props: {
      posts,
      data: reviews,
    },
  };
}
const Home = ({ posts, data, user }) => {
  const classes = useStyles();
  const [expand, setExpand] = useState(false);
  const [postStates, setPostStates] = React.useState([]);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const [reviewers, setReviewers] = React.useState(data);

  const onClick = () => {
    setExpand(!expand);
  };

  React.useEffect(() => {
    if (socket) {
      socket.on("all-reviews", (data) => {
        setReviewers(data);
      });
    }
  }, [socket]);

  React.useEffect(() => {
    if (posts) {
      convertFilePathToURL(posts.data).then((data) => {
        setPostStates(data);
        console.log(data);
      });
    }
  }, [posts]);

  return (
    <React.Fragment>
      <Box>
        <HeaderTitle
          text={
            "Our goal is not to produce future computer scientists (although we would not be surprised if it happens). Our goal is to introduce computer science fundamentals to students at a young age. So that they do not grow up intimidated by computer science field."
          }
        />
      </Box>
      <Box className={classes.container}>
        <Stack direction="column" spacing={5}>
          <Box>
            <Typography variant="h5" align="center">
              Upcoming Class
            </Typography>
          </Box>
          <Box>
            <Grid container spacing={1}>
              {postStates.map((post, index) => {
                return (
                  <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    key={index}
                    display="flex"
                    justifyContent="center"
                  >
                    <UpcomingClassCard
                      _id={post._id}
                      startDate={post.startDate}
                      description={post.description}
                      coverFileName={post.fileName}
                      title={post.name}
                      time={post.time}
                    />
                  </Grid>
                );
              })}
            </Grid>
          </Box>
          <Box>
            <Typography variant="h5" align="center">
              OUR STORY
            </Typography>
          </Box>
          <Box sx={{ p: "0 10px" }}>
            <Typography align="center">
              <ShowMoreText
                lines={3}
                more={<span style={{ color: "blue" }}>Show More</span>}
                less={<span style={{ color: "blue" }}>Show Less</span>}
                onClick={onClick}
                expanded={expand}
              >
                {text}
              </ShowMoreText>
            </Typography>
          </Box>
          <Box>
            <Grid container spacing={1}>
              {whyHowWhat.map((data, index) => {
                return (
                  <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    key={index}
                    display="flex"
                    justifyContent="center"
                  >
                    <StoryCard
                      name={data.name}
                      desc={data.desc}
                      profile={data.profile}
                      number={data.number}
                      title={data.title}
                    />
                  </Grid>
                );
              })}
            </Grid>
          </Box>
          <Box>
            <Typography variant="h5" align="center">
              CORE VALUE IN OUR SCHOOL
            </Typography>
          </Box>
          <Box
            sx={{
              boxShadow: "0px 0px 4px rgba(0, 0, 0, 0.25)",
              borderRadius: 5,
              p: { xs: "10px", sm: "15px" },
            }}
          >
            <Stack
              direction={{ xs: "column", sm: "row" }}
              justifyContent="center"
            >
              <Box flex={1}>
                <ul>
                  {ourschool.map((item, index) => {
                    return (
                      <li key={index}>
                        <Typography>{item.desc}</Typography>
                      </li>
                    );
                  })}
                </ul>
              </Box>
              <Divider
                sx={{ display: { xs: "none", sm: "flex" }, ml: "15px" }}
                color={"primary"}
                orientation="vertical"
                flexItem
              />
              <Box flex={1}>
                <ul>
                  {ourschools.map((item, index) => {
                    return (
                      <li key={index}>
                        <Typography>{item.desc}</Typography>
                      </li>
                    );
                  })}
                </ul>
              </Box>
            </Stack>
          </Box>
          <Box>
            <Typography variant="h5" align="center">
              COLLABORATION
            </Typography>
          </Box>
          <Box>
            <Collaboration />
          </Box>
          <Box>
            <Typography variant="h5">REVIEWS</Typography>

            {data && (
              <Box>
                <FeedbackSetion
                  isReview={true}
                  data={reviewers}
                  user={user?.data || null}
                  url={`${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/review`}
                />
              </Box>
            )}
          </Box>
        </Stack>
      </Box>
    </React.Fragment>
  );
};

export default Home;
