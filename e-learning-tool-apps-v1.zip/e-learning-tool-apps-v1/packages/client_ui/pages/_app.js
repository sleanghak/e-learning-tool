import "../styles/globals.css";
import "../styles/ImageGrid.css";
import "../styles/Modal.css";
import "react-multi-carousel/lib/styles.css";
import React from "react";
import { ThemeProvider } from "@mui/material/styles";
import { darkTheme, ligthTheme } from "../styles/theme";
import { Header, Layout } from "../components/templates/layout";
import NextNprogress from "nextjs-progressbar";
import Amplify from "aws-amplify";
import awsconfiguration from "../aws-exports";
import { useRouter } from "next/router";
import isPublicRoute from "./../utils/func/isPublicRoute";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import { parseCookies, destroyCookie } from "nookies";
import axios from "axios";
import { redirectUser } from "./../utils/func/auth/authUser";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "cropperjs/dist/cropper.css";
import { convertFilePathToURL } from "../utils/func/s3";
import MessengerCustomerChat from "react-messenger-customer-chat";

Amplify.configure(awsconfiguration);
function MyApp({ Component, pageProps, user }) {
  const router = useRouter();
  //Change Theme
  const [isLight, setIsLight] = React.useState(true);
  const handleChangeTheme = () => {
    setIsLight((prev) => (prev == true ? false : true));
  };

  return (
    <>
      <ThemeProvider theme={isLight ? ligthTheme : darkTheme}>
        <NextNprogress
          color="#FFC107"
          startPosition={0.3}
          stopDelayMs={200}
          height={3}
        />
        <MessengerCustomerChat pageId="<PAGE_ID>" appId="<APP_ID>" />
        <Header />
        <ToastContainer
        // icon={<HighlightOffIcon />}
        />
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          {isPublicRoute(router.pathname) ? (
            <Component {...pageProps} user={pageProps.user} />
          ) : (
            <Layout
              onChangeTheme={handleChangeTheme}
              isLight={true}
              {...pageProps}
              user={pageProps.user}
            >
              <Component {...pageProps} user={pageProps.user} />
            </Layout>
          )}
        </LocalizationProvider>
      </ThemeProvider>
    </>
  );
}

// Protected Route
MyApp.getInitialProps = async ({ Component, ctx }) => {
  let pageProps = {};
  const token = parseCookies(ctx)?.token_user;
  let authorize = {};
  const publicRoute =
    ctx.pathname === "/courses/[id]" || ctx.pathname === "/courses/post/[id]";
  const protectedRoute =
    ctx.pathname === "/courses" ||
    ctx.pathname === "/courses/[id]" ||
    ctx.pathname === "/messages" ||
    ctx.pathname === "/courses/post/[id]" ||
    ctx.pathname === "/classes" ||
    ctx.pathname === "/classes/classwork/[id]" ||
    ctx.pathname === "/classes/homework/[homeworkId]" ||
    ctx.pathname === "/classes/grade/[id]" ||
    ctx.pathname === "/classes/lessons/[id]" ||
    ctx.pathname === "/classes/stream/[id]" ||
    ctx.pathname === "/classes/students/[id]" ||
    ctx.pathname === "/classes/join/[code]" ||
    ctx.pathname === "/setting/class" ||
    ctx.pathname === "/setting/notification" ||
    ctx.pathname === "/setting/password" ||
    ctx.pathname === "/setting/personal" ||
    ctx.pathname === "/coaches" ||
    ctx.pathname === "/certificate" ||
    ctx.pathname === "/inventory" ||
    ctx.pathname === "/favorite";
  //  Todo add protected route
  if (!token) {
    if (publicRoute) {
      redirectUser(ctx.pathname);
      return { pageProps };
    }
    protectedRoute && redirectUser(ctx, "/home");
  } else {
    try {
      authorize = JSON.parse(token);
    } catch (error) {
      destroyCookie(ctx, "token_user");
      redirectUser("/");
    }

    if (Component.getInitialProps) {
      pageProps = await Component.getInitialProps(ctx);
    }
    try {
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/current_user`,
        {
          headers: {
            "x-access-token": authorize.accessToken,
          },
        }
      );
      let user = res.data;
      user = await convertFilePathToURL(res.data);
      // if (user) !protectedRoute && redirectUser(ctx, "/courses");

      pageProps.user = user;

      pageProps.token = token;
    } catch (error) {
      console.error(error);
      destroyCookie(ctx, "token_user");
      redirectUser("/");
    }
  }

  return { pageProps, token: authorize };
};

export default MyApp;
