import React, { useState, useEffect } from "react";
import { Box, Stack, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";

//component
import CareerCard from "../components/organisms/cards/CareerCard";

//data
import { careersData } from "../utils/constant/careers";
import HeaderTitle from "../components/molecules/HeaderTitle";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
  title_page: {
    margin: "75px auto",
    [theme.breakpoints.down("md")]: {
      margin: "55px auto",
    },
    [theme.breakpoints.down("sm")]: {
      margin: "35px auto",
    },
    textAlign: "center",
  },
}));

const CareersPage = ({}) => {
  const classes = useStyles();

  return (
    <Box className={classes.root}>
      <Box>
        <HeaderTitle />
      </Box>
      <Box className={classes.title_page}>
        <Typography variant="title" sx={{ fontSize: "50px", fontWeight: 700 }}>
          Careers
        </Typography>
      </Box>
      <Box className={classes.container}>
        <Stack spacing="50px" direction="column">
          {careersData.map((career, index) => {
            return (
              <CareerCard
                key={index}
                title={career.title}
                date={career.date}
                cover={career.cover}
              />
            );
          })}
        </Stack>
      </Box>
    </Box>
  );
};

export default CareersPage;
