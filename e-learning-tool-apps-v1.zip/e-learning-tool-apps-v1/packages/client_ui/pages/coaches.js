import React, { useState } from "react";
import {
  Box,
  Typography,
  Button,
  TextField,
  MenuItem,
  Dialog,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import GradeTable from "../components/organisms/tables/GradeTable";
import NumStuCard from "../components/molecules/cards/NumStuCard";
import AttendanceCoaches from "../components/organisms/tables/AttendanceCoaches";

import GroupRoundedIcon from "@mui/icons-material/GroupRounded";
import GroupAddRoundedIcon from "@mui/icons-material/GroupAddRounded";
import GroupRemoveRoundedIcon from "@mui/icons-material/GroupRemoveRounded";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import AddAttendance from "../components/molecules/dialogs/AddAttendance";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  num_students: {
    width: "100%",
    display: "flex",
    justifyContent: "space-around",
    flexWrap: "wrap",
    marginBottom: 30,
  },
  header: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    marginBottom: 30,
    padding: "0px 20px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 10px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 5px",
    },
  },
  add_button: {
    marginRight: 30,
    [theme.breakpoints.down("md")]: {
      padding: "5px 25px",
      marginRight: 20,
    },
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
  },
  add_button_sm: {
    marginRight: 10,
    paddingLeft: 20,
    paddingRight: 20,
    [theme.breakpoints.up("sm")]: {
      display: "none",
    },
  },
  select_year: {
    width: 200,
    [theme.breakpoints.down("md")]: {
      width: 150,
    },
    [theme.breakpoints.down("sm")]: {
      width: 100,
    },
  },
  input_text: {
    fontFamily: "Arial",
  },
  input_fieldset: {
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        borderColor: "#000000",
      },
    },
  },
  select_month_box: {
    marginBottom: 30,
    padding: "0px 20px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 10px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 5px",
    },
  },
  select_month: {
    width: 250,
    [theme.breakpoints.down("md")]: {
      width: 200,
    },
    [theme.breakpoints.down("sm")]: {
      width: 150,
    },
  },
}));

const Coaches = ({}) => {
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  const [year, setYear] = useState(2022);
  const handleChangeYear = (event) => {
    setYear(event.target.value);
  };
  const [month, setMonth] = useState(3);
  const handleChangeMonth = (event) => {
    setMonth(event.target.value);
  };
  return (
    <Box className={classes.root}>
      <Box className={classes.num_students}>
        <NumStuCard
          icon={<GroupRoundedIcon sx={{ fontSize: { sx: 30, md: 35 } }} />}
          title="All students"
          num={50}
        />
        <NumStuCard
          icon={<GroupAddRoundedIcon sx={{ fontSize: { sx: 25, md: 30 } }} />}
          title="Enroll "
          num={25}
        />
        <NumStuCard
          icon={
            <GroupRemoveRoundedIcon sx={{ fontSize: { sx: 25, md: 30 } }} />
          }
          title="Unenroll"
          num={0}
        />
      </Box>
      <Box className={classes.header}>
        <Typography variant="title" sx={{ mr: "20px", mb: "20px" }}>
          Attendance
        </Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Box sx={{ display: "flex", alignItems: "end", mb: "20px" }}>
          <Box>
            <Button
              variant="outlined"
              className={classes.add_button}
              startIcon={<AddRoundedIcon />}
              onClick={() => setOpen(true)}
            >
              <Typography>Add Attendance</Typography>
            </Button>
            <Button
              variant="outlined"
              onClick={() => setOpen(true)}
              className={classes.add_button_sm}
            >
              <AddRoundedIcon />
            </Button>
          </Box>
          <Box className={classes.select_year}>
            <TextField
              size="small"
              fullWidth
              select
              value={year}
              onChange={handleChangeYear}
              InputProps={{
                classes: {
                  root: classes.input_text,
                },
              }}
              className={classes.input_fieldset}
            >
              <MenuItem value={2020}>2020</MenuItem>
              <MenuItem value={2021}>2021</MenuItem>
              <MenuItem value={2022}>2022</MenuItem>
            </TextField>
          </Box>
        </Box>
      </Box>
      <Box className={classes.select_month_box}>
        <Box className={classes.select_month}>
          <TextField
            size="small"
            fullWidth
            select
            value={month}
            onChange={handleChangeMonth}
            InputProps={{
              classes: {
                root: classes.input_text,
              },
            }}
            className={classes.input_fieldset}
          >
            <MenuItem value={1}>
              <Typography>January</Typography>
            </MenuItem>
            <MenuItem value={2}>
              <Typography>February</Typography>
            </MenuItem>
            <MenuItem value={3}>
              <Typography>March</Typography>
            </MenuItem>
            <MenuItem value={4}>
              <Typography>April</Typography>
            </MenuItem>
            <MenuItem value={5}>
              <Typography>May</Typography>
            </MenuItem>
            <MenuItem value={6}>
              <Typography>June</Typography>
            </MenuItem>
            <MenuItem value={7}>
              <Typography>July</Typography>
            </MenuItem>
            <MenuItem value={8}>
              <Typography>August</Typography>
            </MenuItem>
            <MenuItem value={9}>
              <Typography>September</Typography>
            </MenuItem>
            <MenuItem value={10}>
              <Typography>October</Typography>
            </MenuItem>
            <MenuItem value={11}>
              <Typography>November</Typography>
            </MenuItem>
            <MenuItem value={12}>
              <Typography>December</Typography>
            </MenuItem>
          </TextField>
        </Box>
      </Box>
      <Box>
        <AttendanceCoaches />
      </Box>
      <Dialog open={open} onClose={() => setOpen(false)} sx={{ width: "100%" }}>
        <AddAttendance onClose={() => setOpen(false)} />
      </Dialog>
    </Box>
  );
};

export default Coaches;
