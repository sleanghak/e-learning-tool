import React from "react";
import { Box, Stack, Typography, TextField, Button, Grid } from "@mui/material";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/router";
const ResetPage = () => {
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [status, setStatus] = React.useState(false);
  const router = useRouter();
  const sendEmailToResetPassword = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const form = e.target.elements;
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/reset`,
        {
          method: "post",
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
          body: JSON.stringify({
            email: form.email.value,
          }),
        }
      );
      const data = await res.json();
      if (data.statusCode == 200) {
        e.target.reset();
        setStatus(true);
        router.push("/");
      } else {
        setError(data.message);
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      setError(error);
      setLoading(false);
    }
  };
  return (
    <Box>
      <form onSubmit={sendEmailToResetPassword}>
        <Grid sx={{ mt: 5 }} container spacing={3} justifyContent="center">
          <Grid item xs={3}>
            <Image src="/images/forgot_password.svg" width={300} height={300} />
          </Grid>
          <Grid item xs={3}>
            {status ? (
              <Typography variant="h5">
                Please check your email to reset your password.
              </Typography>
            ) : (
              <Stack spacing={2}>
                <Typography sx={{ mt: 5 }} variant="h4">
                  Reset Password
                </Typography>
                <Typography>
                  Enter the email address associated with your account and
                  we&apos;ll send you a link to reset your password.
                </Typography>
                <TextField
                  name="email"
                  required
                  label="Enter User Email"
                  type={"email"}
                />

                <Button disabled={loading} variant="outlined" type="submit">
                  Continue
                </Button>
                <Typography color={"error"}>{error}</Typography>
                <Typography align="center">
                  Don&apos;t have an account?
                  <Link href="/auth/signup">
                    <a style={{ color: "darkblue" }}> Sign up</a>
                  </Link>
                </Typography>
              </Stack>
            )}
          </Grid>
        </Grid>
      </form>
    </Box>
  );
};

export default ResetPage;
