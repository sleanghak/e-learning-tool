import React from "react";
import {
  Box,
  Stack,
  Typography,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Input,
  InputAdornment,
  IconButton,
} from "@mui/material";
import { useRouter } from "next/router";
import Image from "next/image";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
const TokenPage = () => {
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const router = useRouter();
  const sendEmailToResetPassword = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const form = e.target.elements;
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/reset/token`,
        {
          method: "post",
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
          body: JSON.stringify({
            password: form.password.value,
            token: router.query.token,
          }),
        }
      );
      const data = await res.json();
      if (data.statusCode == 200) {
        e.target.reset();
        router.push("/auth/signin");
      } else {
        setError(data.message);
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      setError(error);
      setLoading(false);
    }
  };
  return (
    <Box>
      <form onSubmit={sendEmailToResetPassword}>
        <Grid sx={{ mt: 5 }} container spacing={3} justifyContent="center">
          <Grid item xs={3}>
            <Image
              src="/images/password.svg"
              alt="password"
              width={300}
              height={300}
            />
          </Grid>
          <Grid item xs={3}>
            <Stack spacing={2}>
              <Typography sx={{ mt: 5 }} variant="h4">
                New Password
              </Typography>
              <Typography>
                Enter the email address associated with your account and
                we&apos;ll send you a link to reset your password.
              </Typography>

              <FormControl variant="filled" required fullWidth>
                <InputLabel htmlFor="standard-adornment-password">
                  Enter New Password
                </InputLabel>
                <Input
                  id="outlined-adornment-password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  name="password"
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={() => setShowPassword(!showPassword)}
                        edge="end"
                      >
                        {showPassword ? (
                          <Visibility color="primary" />
                        ) : (
                          <VisibilityOff color="primary" />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                  labelWidth={70}
                />
              </FormControl>

              <Button disabled={loading} variant="outlined" type="submit">
                Continue
              </Button>
              <Typography color={"error"}>{error}</Typography>
            </Stack>
          </Grid>
        </Grid>
      </form>
    </Box>
  );
};

export default TokenPage;
