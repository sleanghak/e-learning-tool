import React, { useState, useEffect } from 'react';
import {
    Box, Stack, Typography,

} from '@mui/material';
import { makeStyles } from '@mui/styles';

//component
import ScholarshipCard from '../components/organisms/cards/ScholarshipCard';
import HeaderTitle from "../components/molecules/HeaderTitle";

//data
import { scholarships } from '../utils/constant/scholarships';
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
    },
    container: {
        padding: '0px 30px',
        [theme.breakpoints.down("md")]: {
            padding: '0px 20px',
        },
        [theme.breakpoints.down("sm")]: {
            padding: '0px 10px',
        },
    },
    title_page: {
        margin: '75px auto',
        [theme.breakpoints.down("md")]: {
            margin: '55px auto',
        },
        [theme.breakpoints.down("sm")]: {
            margin: '35px auto',
        },
        textAlign: 'center'
    }

}));

const Scholarship = ({ }) => {

    const classes = useStyles();

    return (
        <Box className={classes.root}>
            <HeaderTitle />
            <Box className={classes.title_page}>
                <Typography
                    variant='title'
                    sx={{ fontSize: '50px', fontWeight: 700}}
                >
                    Scholarship
                </Typography>
            </Box>
            <Box className={classes.container}>
                <Stack
                    spacing='50px'
                    direction='column'
                >
                    {
                        scholarships.map((scholarship, index)=>{
                            return(
                                <ScholarshipCard
                                    key={index}
                                    logoImage={scholarship.logoImage}
                                    CompanyName={scholarship.CompanyName}
                                    title={scholarship.title}
                                    description={scholarship.description}
                                    date={scholarship.date}
                                    applyURL={scholarship.applyURL}
                                />
                            )
                        })
                    }
                </Stack>
            </Box>
        </Box>
    );
}
export default Scholarship;