import { Box, Grid } from "@mui/material";
import { makeStyles } from "@mui/styles";
import CertifateSection from "../components/templates/certificates/CertificateSetion";
import HeaderTitle from "../components/molecules/HeaderTitle";

const useStyles = makeStyles((theme) => ({
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  }
}));

const Certifate = () => {

  const classes = useStyles();

  return (
    <div>
      <Box>
        <HeaderTitle />
      </Box>
      <Box className={classes.container}>
          <CertifateSection title="Certificates of Courses" data={["", ""]} />
      </Box>
    </div>
  );
};

export default Certifate;
