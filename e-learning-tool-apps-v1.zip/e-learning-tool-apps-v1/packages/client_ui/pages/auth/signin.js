import React, { useState } from "react";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import { useRouter } from "next/router";
import { makeStyles } from "@mui/styles";
import IconButton from "@mui/material/IconButton";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import InputAdornment from "@mui/material/InputAdornment";
import FormControl from "@mui/material/FormControl";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import { ButtonBase, Stack, Typography, Box, Input } from "@mui/material";
import Image from "next/image";
import Link from "next/link";
import { loginUser } from "../../utils/func/auth/authUser";

export default function SignIn() {
  const classes = useStyles();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  async function signIn(e) {
    e.preventDefault();
    setErrorMessage("");
    setIsLoading(true);
    const email = e.target.elements.email.value;
    const password = e.target.elements.password.value;
    try {
      await loginUser(email, password, setErrorMessage, setIsLoading);
    } catch (error) {
      console.error(error);
      setErrorMessage(error);
      setIsLoading(false);
    }
  }

  return (
    <Box className={classes.root}>
      <div className={classes.paper}>
        <Stack spacing={2}>
          <Box className={classes.logo}>
            <Image
              src="/images/sabaicode.jpg"
              alt="sabaicode logo"
              width={80}
              height={80}
              className="logo"
            />
          </Box>
          <Typography variant="h6" color={"primary"} align="center">
            Login to student account
          </Typography>
        </Stack>

        <form className={classes.form} onSubmit={signIn}>
          <Stack spacing={2}>
            <TextField
              color="primary"
              variant="standard"
              margin="normal"
              required
              fullWidth
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
            />

            <FormControl variant="standard" fullWidth>
              <InputLabel htmlFor="standard-adornment-password">
                Password
              </InputLabel>
              <Input
                id="outlined-adornment-password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                name="password"
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? (
                        <Visibility color="primary" />
                      ) : (
                        <VisibilityOff color="primary" />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
                labelWidth={70}
              />
            </FormControl>
            <div
              style={{
                color: `red`,
              }}
            >
              {errorMessage}
            </div>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              className={classes.submit}
              disabled={isLoading}
            >
              {isLoading ? "Login ..." : "Login"}
            </Button>
            <Stack direction={"row"} justifyContent="space-between">
              <ButtonBase
                className={classes.forgotpwd}
                onClick={() => router.push("/reset")}
              >
                <Typography> Forgot Password ?</Typography>
              </ButtonBase>

              {/* <Typography color={"primary"}>
                <Link href="/auth/signup">
                  Don&apos;t have account? sign up
                </Link>
              </Typography> */}
            </Stack>
          </Stack>

          <br />
        </form>
      </div>
    </Box>
  );
}

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100vh",
    maxWidth: 400,
    margin: "0px auto",
    padding: 8,
  },
  forgotpwd: {
    textAlign: `right`,
    color: theme.palette.primary.main,
  },
  logo: {
    margin: "0px auto",
    marginTop: 50,
    "& .logo": {
      borderRadius: 8,
    },
  },
}));
