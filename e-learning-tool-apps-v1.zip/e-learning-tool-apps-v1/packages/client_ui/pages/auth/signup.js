import React, { useState } from "react";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import Link from "@mui/material/Link";

import { makeStyles } from "@mui/styles";
import IconButton from "@mui/material/IconButton";
import DesktopDatePicker from "@mui/lab/DesktopDatePicker";
import { useRouter } from "next/router";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import InputAdornment from "@mui/material/InputAdornment";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import Image from "next/image";
import { Box, Input, Menu, Stack, Select, MenuItem } from "@mui/material";
import { registerUser } from "../../utils/func/auth/authUser";
export default function SignIn() {
  const classes = useStyles();
  const router = useRouter();
  const [value, setValue] = React.useState(new Date("2000-01-01:11:54"));

  const handleChange = (newValue) => {
    setValue(newValue);
  };
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  async function signUp(e) {
    e.preventDefault();
    setErrorMessage("");
    setIsLoading(true);
    const form = e.target.elements;
    const username = form.username.value;
    const email = form.email.value;
    const password = form.password.value;
    const dateOfBirth = form.dateOfBirth.value;
    const tel = form.tel.value;
    const gender = form.gender.value;

    await registerUser(
      username,
      email,
      password,
      dateOfBirth,
      tel,
      gender,
      setErrorMessage,
      setIsLoading,
      router
    );
  }

  return (
    <Box className={classes.root}>
      <div className={classes.paper}>
        <Image
          src="/images/sabaicode.jpg"
          alt="me"
          width={80}
          height={80}
          className={classes.logo}
        />
        <form className={classes.form} onSubmit={signUp}>
          <Stack spacing={2}>
            <TextField
              variant="standard"
              margin="normal"
              required
              fullWidth
              label="User Name"
              name="username"
            />
            <TextField
              variant="standard"
              margin="normal"
              required
              fullWidth
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
            />
            <FormControl fullWidth variant="standard">
              <InputLabel id="demo-simple-select-label">Gender</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                label="Gender"
                name="gender"
              >
                <MenuItem value={"female"}>Female</MenuItem>
                <MenuItem value={"male"}>Male</MenuItem>
                <MenuItem value={"other"}>Other</MenuItem>
              </Select>
            </FormControl>
            <DesktopDatePicker
              label="Date of birth"
              inputFormat="MM/dd/yyyy"
              value={value}
              onChange={handleChange}
              color="primary"
              renderInput={(params) => (
                <TextField
                  variant="standard"
                  required
                  name="dateOfBirth"
                  {...params}
                />
              )}
            />
            <FormControl required variant="outlined" fullWidth>
              <InputLabel htmlFor="standard-adornment-password">
                Password
              </InputLabel>
              <Input
                id="outlined-adornment-password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                name="password"
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? (
                        <Visibility color="primary" />
                      ) : (
                        <VisibilityOff color="primary" />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
                labelWidth={70}
              />
            </FormControl>
            <TextField
              variant="standard"
              margin="normal"
              required
              fullWidth
              label="Phone Number"
              name="tel"
              autoFocus
            />
            <div
              style={{
                color: `red`,
              }}
            >
              {errorMessage}
            </div>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              disabled={isLoading}
            >
              {isLoading ? "Sign Up ..." : "Sign Up"}
            </Button>
            <Link href="/auth/signin">You already have account? SignIn</Link>
          </Stack>
          <br />
        </form>
      </div>
    </Box>
  );
}

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100vh",
    maxWidth: 450,
    margin: "0px auto",
    padding: 8,
  },
  paper: {
    margin: theme.spacing(8, 4),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },

  forgotpwd: {
    textAlign: `right`,
  },
  logo: {
    borderRadius: 8,
  },
}));
