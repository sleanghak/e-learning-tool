import React from "react";
import { makeStyles } from "@mui/styles";
import Image from "next/image";
import { Grid, Box, Typography, Stack } from "@mui/material";
import { Avatar } from "@mui/material";
import { TextField, InputLabel } from "@mui/material";
import { Button, IconButton } from "@mui/material";
import { convertFilePathToURL, uploadFile } from "./../../utils/func/s3";
import updateDataFunc from "./../../utils/func/api/updateDataFunc";
import dynamic from "next/dynamic";
import Cropper from "react-cropper";
import LinearProgression from "../../components/atoms/progressions/LinearProgression";
import undefinedFunc from "../../utils/func/undefinedFunc";

const FileView = dynamic(() => import("react-file-viewer"), {
  ssr: false,
});
const useStyles = makeStyles((theme) => ({
  container: {
    position: "relative",
  },
  avatar: {
    display: "block",
    margin: "0 auto",
  },
  btn_edit_pf: {
    margin: "0px auto",
    display: "block",
    padding: "5px 50px",
    background: " #5DE2E7",
    "&:hover ": {
      background: " #5DE2E7",
    },
  },
  btn_save: {
    margin: "0px auto",
    display: "block",
    padding: "5px 50px",
    background: " #5DE2E7",
    "&:hover ": {
      background: " #5DE2E7",
    },
  },
}));

export default function PersonalInfo({ user }) {
  const [currentUser, setCurrentUser] = React.useState({ fileName: null });
  const [file, setFile] = React.useState();
  const [message, setMessage] = React.useState("");
  const [progress, setProgress] = React.useState(0);
  const [loading, setLoading] = React.useState(false);
  React.useEffect(() => {
    if (user) {
      convertFilePathToURL(user.data).then((data) => {
        setCurrentUser(data);
        console.log(data);
      });
    }
  }, []);

  // Update User

  const handleUpdateUser = async (e) => {
    let data;
    setLoading(true);
    e.preventDefault();
    const form = e.target.elements;
    let body = {};
    console.log(form.email.value, user.data.email);
    if (form.email.value === user.data.email) {
      body = {
        name: form.name.value,
        tels: [form.phone_number.value],
        bio: form.bio.value,
      };
    } else {
      body = {
        name: form.name.value,
        email: form.email.value,
        tels: [form.phone_number.value],
        bio: form.bio.value,
      };
    }
    // update profile
    if (file) {
      try {
        const res = await uploadFile(
          "user_profile",
          file,
          setProgress,
          setMessage
        );

        data = await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/update_current_user`,
          {
            coverFileName: res.key,
            ...body,
          }
        );

        if (data.statusCode == 200) {
          convertFilePathToURL(data.user).then((res) => {
            setCurrentUser(data.user);
          });
        }

        setLoading(false);
      } catch (error) {
        console.log(error);
        setLoading(false);
      }
    } else {
      try {
        data = await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/update_current_user`,
          body
        );

        if (data.statusCode == 200) {
          convertFilePathToURL(data.user).then((res) => {
            setCurrentUser(data.user);
          });
        }

        setLoading(false);
      } catch (error) {
        console.log(error);
        setLoading(false);
      }
    }
  };
  const handleUploadCV = async (e) => {
    try {
      const fileName = e.target.files[0];
      const res = await uploadFile(
        `user_cv/${user.data._id}`,
        fileName,
        setProgress,
        setMessage
      );

      const data = await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/update_current_user`,
        {
          fileName: res.key,
        }
      );

      if (data.statusCode == 200) {
        convertFilePathToURL(data.user).then((res) => {
          setCurrentUser(res);
        });
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };
  const classes = useStyles();
  return (
    <Grid container justifyContent={"center"} spacing={4}>
      <Grid item xs={11} sm={5}>
        <LinearProgression
          show={progress > 0 && progress < 100}
          increase={progress}
        />
        <Box sx={{ mt: 4 }} className={classes.container}>
          <form onSubmit={handleUpdateUser}>
            <Box>
              <label htmlFor="profile">
                <Avatar
                  className={classes.avatar}
                  alt="img"
                  src={
                    file
                      ? window.URL.createObjectURL(file)
                      : currentUser?.coverFileName
                  }
                  sx={{ width: 100, height: 100 }}
                />
              </label>
              {/* <Cropper
                style={{ height: 400, width: "100%" }}
                zoomTo={0.5}
                initialAspectRatio={1}
                preview=".img-preview"
                src={
                  file
                    ? window.URL.createObjectURL(file)
                    : currentUser?.coverFileName
                }
                viewMode={1}
                minCropBoxHeight={10}
                minCropBoxWidth={10}
                background={false}
                responsive={true}
                autoCropArea={1}
                checkOrientation={false} // https://github.com/fengyuanchen/cropperjs/issues/671
                onInitialized={(instance) => {
                  conso
                }}
                guides={true}
              /> */}
              <input
                onChange={(e) => setFile(e.target.files[0])}
                type="file"
                hidden
                id="profile"
                label="profile"
                variant="outlined"
                name="coverFileName"
              />
            </Box>
            <br />
            <br />
            <Box>
              <TextField
                fullWidth
                required
                name="name"
                type="text"
                variant="standard"
                value={currentUser.name}
                onChange={(e) =>
                  setCurrentUser((prev) => ({
                    ...prev,
                    name: e.target.value,
                  }))
                }
              />
              <IconButton sx={{ position: "absolute", right: 0 }}>
                <Image
                  width={20}
                  height={20}
                  src="/images/edit.png"
                  alt="edit_img"
                />
              </IconButton>
            </Box>
            <br />
            <br />
            <Box>
              <TextField
                fullWidth
                required
                name="email"
                type="email"
                variant="standard"
                value={currentUser.email}
                onChange={(e) =>
                  setCurrentUser((prev) => ({
                    ...prev,
                    email: e.target.value,
                  }))
                }
              />
              <IconButton sx={{ position: "absolute", right: 0 }}>
                <Image
                  width={20}
                  height={20}
                  src="/images/edit.png"
                  alt="edit_img"
                />
              </IconButton>
            </Box>
            <br />
            <br />
            <Box>
              <TextField
                fullWidth
                name="phone_number"
                type=" "
                variant="standard"
                value={currentUser?.tels?.length > 0 ? currentUser.tels[0] : ""}
              />
              <IconButton sx={{ position: "absolute", right: 0 }}>
                <Image
                  width={20}
                  height={20}
                  src="/images/edit.png"
                  alt="edit_img"
                />
              </IconButton>
            </Box>
            <br />
            <br />

            <Box>
              <InputLabel>Bio</InputLabel>
              <TextField
                name="bio"
                fullWidth
                required
                multiline
                rows={4}
                type="text"
                variant="standard"
                value={currentUser?.bio}
                onChange={(e) =>
                  setCurrentUser((prev) => ({
                    ...prev,
                    bio: e.target.value,
                  }))
                }
              />
            </Box>
            <br />
            <br />

            <Box sx={{ width: "100%" }}>
              <Button type="submit" className={classes.btn_save}>
                {loading ? `Save ... ${progress}` : "Save"}
              </Button>
            </Box>
          </form>
        </Box>
      </Grid>
      <Grid item xs={11} sm={5}>
        <Stack sx={{ p: 3 }} direction="row" justifyContent={"space-between"}>
          <div>
            <Typography>Upload Your CV</Typography>
            <input type={"file"} accept=".pdf" onChange={handleUploadCV} />
          </div>
          {currentUser?.fileName && (
            <Button
              href={currentUser?.fileName}
              target="_blank"
              variant="contained"
            >
              Download{" "}
            </Button>
          )}
        </Stack>

        {undefinedFunc(currentUser.fileName) ? (
          <div style={{ width: "150%" }}>
            <FileView fileType="pdf" filePath={currentUser.fileName} />
          </div>
        ) : (
          <div>No CV,yet. Please Upload Your CV.</div>
        )}
      </Grid>
    </Grid>
  );
}
