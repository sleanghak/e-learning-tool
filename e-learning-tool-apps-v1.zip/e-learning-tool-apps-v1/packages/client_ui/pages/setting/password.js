import React from 'react';
import { makeStyles } from "@mui/styles";
import { Grid, Box } from "@mui/material";
import { Typography, Button, TextField } from "@mui/material";


const useStyles = makeStyles((theme) => ({
    btn_change: {
        margin: '0px auto',
        display: 'block',
        padding: '5px 50px',
        background: ' #5DE2E7',
        "&:hover ": {
            background: ' #5DE2E7',
        },
    },
}));

export default function Password({user}) {
    const classes = useStyles();

    return (
        <Grid container justifyContent={"center"} spacing={4}>
            <Grid item xs={8}><br /><br />
                <Box>
                    <Typography>
                        Change password
                    </Typography>
                </Box><br /><br />
                <form>
                    <Box>
                        <TextField
                            fullWidth
                            required
                            name="email"
                            type="email"
                            label="Email"
                            variant="standard"
                            defaultValue={user?.data?.email}
                        />

                    </Box><br /><br />
                    <Box>
                        <TextField
                            fullWidth
                            required
                            name="password"
                            type="password"
                            label="Password"
                            variant="standard"
                            defaultValue={"***********"}

                        />
                    </Box><br /><br />
                    <Box>
                        <TextField
                            fullWidth
                            required
                            name="new_password"
                            type="password"
                            label="New password"
                            variant="standard"
                        />

                    </Box><br /><br />
                    <Box>
                        <TextField
                            fullWidth
                            required
                            name="confirm_password"
                            type="password"
                            label="Confirm password"
                            variant="standard"
                        />

                    </Box><br /><br />
                    <Box
                    >
                        <Button className={classes.btn_change}>
                            Change
                        </Button>
                    </Box>
                </form>

            </Grid >
        </Grid >
    );
};