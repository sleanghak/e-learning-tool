import React from 'react';
import { makeStyles } from "@mui/styles";
import { Grid, Box, Stack } from "@mui/material";
import Switch from '@mui/material/Switch';
import { Typography, } from "@mui/material";

const useStyles = makeStyles((theme) => ({
    container: {
        position: 'relative',
    },

}));

const label = { inputProps: { 'aria-label': 'Switch demo' } };

const Notification = () => {
    const classes = useStyles();
    
    return (
        <Grid container justifyContent={"center"} spacing={4}>
            <Grid item xs={10}>
                <div className={classes.container}><br /><br />
                    <Box>
                        <Typography sx={{ fontSize: 20 }}>Notifications</Typography>
                    </Box><br /><br />

                    <Box>
                        <Typography>Email</Typography>
                    </Box><br />

                    <Box>
                        <Stack
                            direction={"row"}
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography>Receive email notifications</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>
                        </Stack>
                    </Box><br /><br />

                    <Box>
                        <Typography>Comment</Typography>
                    </Box><br />

                    <Box>
                        <Stack
                            direction={"row"}
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography>Comments on your post</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>
                        </Stack>
                    </Box><br />

                    <Box>
                        <Stack
                            direction={"row"}
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography>Comments that mentions you</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>
                        </Stack>
                    </Box><br />

                    <Box>
                        <Stack
                            direction={"row"}
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography>Private comments on work</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>
                        </Stack>
                    </Box><br /><br />

                    <Box>
                        <Typography>Classes you teach</Typography>
                    </Box><br />

                    <Box>
                        <Stack
                            direction={"row"}
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography>Late submissions of student work</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>
                        </Stack>
                    </Box><br />

                    <Box>
                        <Stack
                            direction={"row"}
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography>Resubmissions of student work</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>
                        </Stack>
                    </Box><br />

                    <Box>
                        <Stack
                            direction={"row"}
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography>Invitations to co-teach classes</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>
                        </Stack>
                    </Box><br />

                    <Box >
                        <Stack
                            direction={"row"}
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography>Scheduled post published or failed</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>
                        </Stack>
                    </Box><br />
                </div>
            </Grid>
        </Grid >
    );
}

export default Notification;