import React from 'react';
import { makeStyles } from "@mui/styles";
import { styled } from '@mui/material/styles';
import { CardContent, CardActions, Collapse } from '@mui/material';
import { Grid, Box, Stack } from '@mui/material';
import { IconButton, Avatar, Switch } from '@mui/material';
import { Typography, } from '@mui/material';
import Image from "next/image";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

const useStyles = makeStyles((theme) => ({
    container: {
        position: 'relative',
    },

}));


const ExpandMore = styled((props) => {
    const { expand, ...other } = props;
    return <IconButton {...other} />;
})(({ theme, expand }) => ({
    transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
    marginLeft: 'auto',
    transition: theme.transitions.create('transform', {
        duration: theme.transitions.duration.shortest,
    }),
}));


const label = { inputProps: { 'aria-label': 'Switch demo' } };

export default function Class() {
    const classes = useStyles();
    const [expanded, setExpanded] = React.useState(false);

    const handleExpandClick = () => {
        setExpanded(!expanded);
    };


    return (
        <Grid container justifyContent={"center"} spacing={4}>
            <Grid item xs={10}>
                <div className={classes.container}><br /><br />
                    <Box>
                        <Stack
                            direction="row"
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography sx={{ fontSize: 20 }}>
                                Class notifications
                            </Typography>

                            <CardActions
                                sx={{ position: 'absolute', right: 0, }}
                                disableSpacing
                            >
                                <ExpandMore
                                    expand={expanded}
                                    onClick={handleExpandClick}
                                    aria-expanded={expanded}
                                    aria-label="show more"
                                >
                                    <ExpandMoreIcon />
                                </ExpandMore>
                            </CardActions>
                            <Collapse in={expanded} timeout="auto" unmountOnExit>
                                <CardContent>

                                    {/* item */}

                                </CardContent>
                            </Collapse>
                        </Stack>
                    </Box><br /><br />

                    <Box>
                        <Stack
                            direction="row"
                            spacing={2}
                            alignItems="center"
                        >
                            <Avatar sx={{ background: ' #0D34FF96', }}>B</Avatar>
                            <Typography>Backend Development</Typography>
                            <Box sx={{ position: 'absolute', left: 220, }}>
                                <Typography
                                    variant="body2"
                                    color="textSecondary"
                                    component="p"
                                >
                                    Web & Mobile
                                </Typography>
                            </Box>

                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>

                        </Stack>
                    </Box><br />

                    <Box>
                        <Stack
                            direction="row"
                            spacing={2}
                            alignItems="center">
                            <Avatar sx={{ background: '#FF0D47', }}>F</Avatar>
                            <Typography>Frontend Development</Typography>
                            <Box sx={{ position: 'absolute', left: 220, }}>
                                <Typography
                                    variant="body2"
                                    color="textSecondary"
                                    component="p"
                                >
                                    Web & Mobile
                                </Typography>
                            </Box>

                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>

                        </Stack>
                    </Box><br />

                    <Box>
                        <Stack
                            direction="row"
                            spacing={2}
                            alignItems="center">
                            <Avatar sx={{ background: '#FF390D', }}>C</Avatar>
                            <Typography>Computer Science</Typography>
                            <Box sx={{ position: 'absolute', right: 0, }}>
                                <Switch {...label} defaultChecked />
                            </Box>

                        </Stack>
                    </Box><br /><br />

                    <Box>
                        <Stack
                            direction="row"
                            spacing={0}
                            alignItems="center"
                        >
                            <Typography sx={{ fontSize: 20 }}>
                                General
                            </Typography>

                            <CardActions
                                sx={{ position: 'absolute', right: 0, }}
                                disableSpacing
                            >
                                <ExpandMore
                                    expand={expanded}
                                    onClick={handleExpandClick}
                                    aria-expanded={expanded}
                                    aria-label="show more"
                                >
                                    <ExpandMoreIcon />
                                </ExpandMore>
                            </CardActions>
                            <Collapse in={expanded} timeout="auto" unmountOnExit>
                                <CardContent>

                                    {/* items */}

                                </CardContent>
                            </Collapse>
                        </Stack>
                    </Box>

                    <Box sx={{ padding: 2 }}>
                        <Typography
                            variant="body2"
                            // color="textSecondary"
                            component="p"
                            sx={{ fontSize: 16 }}
                        >
                            Invite code
                        </Typography><br />

                        {/* ------------------------------------------------------- */}

                        <Box>
                            <Stack
                                direction="row"
                                spacing={2}
                                alignItems="center"
                            >
                                <Typography>
                                    Manage  Invite
                                </Typography>

                                <Box sx={{ position: 'absolute', right: 0, }}>
                                    <Stack
                                        direction="row"
                                        spacing={2}
                                        alignItems="center"
                                    >
                                        <CardActions
                                            sx={{ position: 'absolute', right: 0, }}
                                            disableSpacing
                                        >
                                            <Typography>
                                                Turn on
                                            </Typography>

                                            <ExpandMore
                                                expand={expanded}
                                                onClick={handleExpandClick}
                                                aria-expanded={expanded}
                                                aria-label="show more"
                                            >
                                                <ArrowDropDownIcon />
                                            </ExpandMore>
                                        </CardActions>
                                        <Collapse in={expanded} timeout="auto" unmountOnExit>
                                            <CardContent>

                                                {/* item */}

                                            </CardContent>
                                        </Collapse>
                                    </Stack>
                                </Box>
                            </Stack>
                        </Box>

                    </Box>

                </div>
            </Grid>
        </Grid>
    );
};