import React from "react";
import { Box, Grid } from "@mui/material";
import HeaderTitle from "../../components/molecules/HeaderTitle";
import ClassSection from "../../components/templates/classes/ClassSection";
import EmptyItem from "../../components/atoms/EmptyItem";
import { convertFilePathToURL } from "../../utils/func/s3";
import fetcher from "./../../utils/func/api/fetcher";
import useSWR from "swr";
import useSocket from "./../../utils/func/socket/useSocket";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
}));

const Class = () => {
  const style = useStyles();
  const [loading, setLoading] = React.useState(false);
  const [classes, setClasses] = React.useState([]);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/class`,
    fetcher
  );
  React.useEffect(() => {
    if (data?.data) {
      setLoading(true);
      convertFilePathToURL(data.data).then((res) => {
        setClasses(res);
        setLoading(false);
      });
    }
  }, [data]);
  React.useEffect(() => {
    if (socket) {
      socket.on("class-student", (data) => {
        convertFilePathToURL(data).then((res) => {
          setClasses(res);
          setLoading(false);
        });
      });
    }
  }, [socket]);
  if (error) return "it is error";
  if (!data) return "loading ...";

  return (
    <React.Fragment>
      <Box>
        <HeaderTitle />
      </Box>
      <Box className={style.container}>
        <ClassSection loading={loading} data={classes} />
      </Box>
    </React.Fragment>
  );
};

export default Class;
