import React, { useState } from "react";
import { Box, Grid, Stack } from "@mui/material";
import { makeStyles } from "@mui/styles";
import StudentWorkCard from "../../../components/molecules/cards/StudentWorkCard";
import HomeworkDetailCard from "../../../components/organisms/cards/HomeworkDetailCard";
import CommentClassWork from "../../../components/templates/classworks/CommentClassWork";
import UploadHomeworkCard from "../../../components/molecules/cards/UploadHomeworkCard";
import { parseCookies } from "nookies";
import { convertFilePathToURL } from "./../../../utils/func/s3";
import { extractObjInArray } from "./../../../utils/func/objects/";
import CommentCard from "../../../components/molecules/cards/CommentCard";
import useSocket from "./../../../utils/func/socket/useSocket";

const customStyle = makeStyles((theme) => ({
  root: {
    width: "100%",
    padding: "0px 50px 50px 50px",
    display: "flex",
    justifyContent: "space-between",
    [theme.breakpoints.down("md")]: {
      padding: "0px 25px 25px 25px",
      flexWrap: "wrap",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px 10px 10px",
    },
  },
  left: {
    maxWidth: 700,
    width: "100%",
    marginRight: 50,
    [theme.breakpoints.down("md")]: {
      order: 2,
    },
  },
  right: {
    [theme.breakpoints.down("md")]: {
      order: 1,
    },
  },
}));

export const getServerSideProps = async (ctx) => {
  let allClass = {};
  const homeworkId = ctx.query.homeworkId;
  const token = parseCookies(ctx)?.token_user;
  if (token) {
    const authorize = JSON.parse(token);
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/student/classwork?homeworkId=${homeworkId}`,
      {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      }
    );

    allClass = await res.json();
  }

  return {
    props: {
      allClass,
    },
  };
};

export default function Homework({ allClass }) {
  console.log("original", allClass);
  const classes = customStyle();
  const [comments, setComments] = useState([]);
  const [homework, setHomework] = useState({});

  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  // init
  React.useEffect(() => {
    if (allClass?.comments?.length > 0) {
      convertFilePathToURL(extractObjInArray(allClass.comments)).then(
        (data) => {
          setComments(data);
        }
      );
      convertFilePathToURL(allClass).then((data) => {
        setHomework(data);
        console.log(data);
      });
    }
  }, [allClass]);

  //socket
  React.useEffect(() => {
    if (socket) {
      socket.on("comment-on-homework", (comments) => {
        convertFilePathToURL(extractObjInArray(comments)).then((data) => {
          setComments(data);
        });
      });
    }
  }, [socket]);
  return (
    <Grid container justifyContent={"center"}>
      <Grid item xs={10}>
        <Box className={classes.root}>
          <Box className={classes.left}>
            <HomeworkDetailCard
              title={allClass.name}
              asignDate={allClass.createdAt}
              dueDate={allClass.deadline}
            />
            <Box sx={{ mt: 4 }}>{allClass.instruction}</Box>
            <UploadHomeworkCard
              url={homework.fileName}
              instruction={allClass.instruction}
            />
            <CommentClassWork classworkId={allClass._id} />
            <Stack sx={{ mt: 2 }} spacing={2}>
              {comments?.map((item, index) => {
                return (
                  <Box key={index}>
                    <CommentCard
                      date={item.date}
                      name={item?.name || "Anonymous"}
                      profile={item?.coverFileName}
                      message={item.text}
                    />
                  </Box>
                );
              })}
            </Stack>
          </Box>
          <Box className={classes.right}>
            <StudentWorkCard homework={allClass} />
          </Box>
        </Box>
      </Grid>
    </Grid>
  );
}
