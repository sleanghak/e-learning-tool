import React from "react";
import ClassWorkCard from "../../../components/molecules/cards/ClassWorkCard";
import { Stack, Box, Grid } from "@mui/material";
import HorizontalTabs from "../../../components/molecules/tabs/HorizontalTabs";
import { classMenuItemsForSutdent } from "../../../utils/constant/navItems";
import { parseCookies } from "nookies";
import EmptyItem from "../../../components/atoms/EmptyItem";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
}));

export const getServerSideProps = async (ctx) => {
  let allClass = {};
  const id = ctx.query.id;
  const token = parseCookies(ctx)?.token_user;
  if (token) {
    const authorize = JSON.parse(token);
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/class?id=${id}&&stream=true`,
      {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      }
    );

    allClass = await res.json();
  }

  return {
    props: {
      allClass,
    },
  };
};
export default function Classworks({ allClass }) {
  const classes = useStyles();
  return (
    <Box className={classes.container}>
      <Box sx={{ maxWidth: 600, m: '25px auto' }}>
        <HorizontalTabs data={classMenuItemsForSutdent} />
      </Box>
      {allClass?.homeworkIds.length == 0 ? (
        <EmptyItem url="/images/welcome.svg" />
      ) : (
        <Stack spacing={2} direction='column'>
          {
            allClass?.homeworkIds?.map((item, index) => {
              return (
                <Box key={index}>
                  <ClassWorkCard data={item} />
                </Box>
              );
            })
          }
        </Stack>
      )}
    </Box>
  );
}
