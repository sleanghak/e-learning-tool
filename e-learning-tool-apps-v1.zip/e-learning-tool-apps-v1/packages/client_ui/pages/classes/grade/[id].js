import { Box, Typography } from "@mui/material";
import HorizontalTabs from "../../../components/molecules/tabs/HorizontalTabs";
import { classMenuItems } from "../../../utils/constant/navItems";
import GradeTable from "../../../components/organisms/tables/GradeTable";
const Grade = () => {
  return (
    <Box>
      <Box sx={{ maxWidth: 600, ml: "auto", mr: "auto", mt: 3 }}>
        <HorizontalTabs data={classMenuItems} />
      </Box>
      <GradeTable />
    </Box>
  );
};

export default Grade;
