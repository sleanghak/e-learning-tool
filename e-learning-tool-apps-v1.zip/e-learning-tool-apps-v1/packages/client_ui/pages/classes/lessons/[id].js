import React from "react";
import { Box, Tabs, Tab, Stack, Paper, Typography } from "@mui/material";
import HorizontalTabs from "../../../components/molecules/tabs/HorizontalTabs";

import { convertFilePathToURL } from "../../../utils/func/s3";
import { parseCookies } from "nookies";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/fetcher";
import {
  Video,
  Resource,
  Curriculum,
} from "../../../components/templates/courses";
import { classMenuItemsForSutdent } from "../../../utils/constant/navItems";
import { useRouter } from "next/router";
export const getServerSideProps = async (ctx) => {
  let allClass = {};
  let authorize = {};
  const id = ctx.query.id;
  const token = parseCookies(ctx)?.token_coach;
  if (token) {
    authorize = JSON.parse(token);
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/class?id=${id}`,
      {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      }
    );
    allClass = await res.json();
  }

  return {
    props: {
      allClass,
      authorize,
    },
  };
};
const Lesson = ({ allClass, authorize }) => {
  const router = useRouter();
  const [lessons, setLessons] = React.useState([]);
  const [tab, setTab] = React.useState(router.query.tab || "video");
  const handleChange = (event, newValue) => {
    setTab(newValue);
    router.push(`/classes/lessons/${allClass._id}?tab=${newValue}`);
  };
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/student/course?id=${allClass?.courseIds[0]?._id}`,
    fetcher
  );

  React.useEffect(() => {
    if (data?.lessonIds?.length > 0) {
      convertFilePathToURL(data.lessonIds).then((res) => {
        setLessons(res);
      });
    }
  }, [data]);

  if (error) return `Error Loading`;
  if (!data) return `Loading ...`;

  return (
    <Box sx={{ p: { xs: 1, sm: 2, md: 3 } }}>
      <Box sx={{ maxWidth: 600, ml: "auto", mr: "auto" }}>
        <HorizontalTabs data={classMenuItemsForSutdent} />
      </Box>
      <Stack direction="row" sx={{ mt: 4 }}>
        <Box sx={{ flexGrow: 1 }}>
          {tab === "video" && <Video lessons={lessons} authorize={authorize} />}
          {tab === "material" && <Resource resources={data?.resources} />}
          {tab === "curriculum" && (
            <Curriculum name={data?.name} curriculum={data?.curriculum} />
          )}
        </Box>
        <Paper square sx={{ pt: 12 }}>
          <Tabs
            orientation="vertical"
            value={tab}
            indicatorColor="primary"
            textColor="primary"
            onChange={handleChange}
            aria-label="disabled tabs example"
          >
            <Tab value={"video"} label={<Typography>Lesson</Typography>} />
            <Tab value={"material"} label={<Typography>Material</Typography>} />
            <Tab
              value={"curriculum"}
              label={<Typography>Curriculum</Typography>}
            />
          </Tabs>
        </Paper>
      </Stack>
    </Box>
  );
};

export default Lesson;
