import { Box, Grid } from "@mui/material";
import HorizontalTabs from "../../../components/molecules/tabs/HorizontalTabs";
import { classMenuItemsForSutdent } from "../../../utils/constant/navItems";
import { makeStyles } from "@mui/styles";
import SabaiCodeTable from "../../../components/organisms/tables/SabaiCodeTable";
import { parseCookies } from "nookies";

const useStyles = makeStyles((theme) => ({
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
}));

export const getServerSideProps = async (ctx) => {
  let allClass = {};
  let authorize = {};
  const id = ctx.query.id;
  const token = parseCookies(ctx)?.token_user;
  if (token) {
    authorize = JSON.parse(token);
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/class?id=${id}&student=true`,
      {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      }
    );
    allClass = await res.json();
  }

  return {
    props: {
      allClass,
      authorize,
    },
  };
};

const Students = ({ allClass }) => {
  console.log(allClass);
  const classes = useStyles();
  return (
    <Box className={classes.container}>
      <Box sx={{ maxWidth: 600, ml: "auto", mr: "auto", mt: 3 }}>
        <HorizontalTabs data={classMenuItemsForSutdent} />
      </Box>
      <SabaiCodeTable data={allClass} />
    </Box>
  );
};

export default Students;
