import React from "react";
import { makeStyles } from "@mui/styles";
import { Avatar, Box, IconButton, Stack, Typography } from "@mui/material";

//icon
import ShareRoundedIcon from "@mui/icons-material/ShareRounded";
import ContentCopyRoundedIcon from "@mui/icons-material/ContentCopyRounded";
import FileDownloadRoundedIcon from "@mui/icons-material/FileDownloadRounded";

//data
import { certificate_stream } from "../../../utils/constant/certificate";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  profile_box: {
    display: "flex",
    alignItems: "center",
    width: "100%",
    paddingTop: 25,
    paddingBottom: 25,
    borderBottom: "1px solid #5DE2E7",
  },
  profile: {
    width: 80,
    height: 80,
  },
  certificate_header: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    margin: "50px 0",
  },
  icon_image: {
    width: 35,
    height: 35,
    marginRight: 20,
  },
  certificate_box: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
  },
  certificate_image: {
    maxWidth: "800px",
    width: "100%",
    height: "auto",
    marginBottom: 30,
  },
  text: {
    width: "100%",
    textAlign: "center",
  },
}));
export default function ClassDetail({ allClass }) {
  const classes = useStyles();

  return (
    <Box className={classes.root}>
      {/* profile header */}
      <Box
        className={classes.profile_box}
        sx={{ pl: { xs: "20px", sm: "30px", md: "40px", lg: "50px" } }}
      >
        <Avatar src={certificate_stream.profile} className={classes.profile} />
        <Typography
          sx={{ ml: { xs: "20px", sm: "30px", md: "40px", lg: "50px" } }}
        >
          {certificate_stream.name}
        </Typography>
      </Box>
      {/* certificate */}
      <Box>
        <Box
          className={classes.certificate_header}
          sx={{ p: { xs: "0 20px", sm: "0 30px", md: "0 40px", lg: "50px" } }}
        >
          <img
            src="/icons/certificate_icon.png"
            className={classes.icon_image}
          />
          <Typography sx={{ display: { xs: "none", sm: "block" } }}>
            Certificate
          </Typography>
          <Box sx={{ flex: 1 }} />
          <Stack direction="row" spacing={{ xs: "10px", sm: "20px" }}>
            <IconButton>
              <FileDownloadRoundedIcon />
            </IconButton>
            <IconButton>
              <ShareRoundedIcon />
            </IconButton>
            <IconButton>
              <ContentCopyRoundedIcon />
            </IconButton>
          </Stack>
        </Box>
        <Box
          className={classes.certificate_box}
          sx={{ alignItems: "center", p: { xs: "0 20px", sm: "0 30px" } }}
        >
          <img
            src={certificate_stream.certificateImage}
            alt={`certificate of ${certificate_stream.name}`}
            className={classes.certificate_image}
          />
          <Box className={classes.text}>
            <Typography>{certificate_stream.text}</Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
