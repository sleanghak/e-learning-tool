import React from "react";
import Image from "next/image";
import CommentInput from "../../../components/atoms/inputs/CommentInput";
import { makeStyles } from "@mui/styles";
import { Grid, Box, Stack, Dialog, Snackbar } from "@mui/material";
import { Card, CardHeader } from "@mui/material";
import { IconButton, Typography } from "@mui/material";
import { Menu, MenuItem } from "@mui/material";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import InfoIcon from "@mui/icons-material/Info";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import UpcomingCard from "../../../components/molecules/cards/UpcomingCard";
import { classMenuItemsForSutdent } from "../../../utils/constant/navItems";
import HorizontalTabs from "../../../components/molecules/tabs/HorizontalTabs";
import { parseCookies } from "nookies";
import { CommentCard } from "../../../components/molecules/cards";
import useSocket from "./../../../utils/func/socket/useSocket";
import { toDateFormat, toTime } from "../../../utils/func/toDateFormat";
import { convertFilePathToURL } from "../../../utils/func/s3";
import { extractObjInArray } from "../../../utils/func/objects";
import CertificateDialogCard from "../../../components/organisms/cards/CertificateDialogCard";

import ClearIcon from "@mui/icons-material/Clear";
const useStyles = makeStyles((theme) => ({
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
  header: {
    backgroundPosition: "center",
    backgroundSize: "cover",
    height: "60vh",
    width: "100%",
    display: "flex",
    justifyContent: "end",
    flexDirection: "column",
    padding: 25,
    [theme.breakpoints.down("md")]: {
      padding: 20,
    },
    [theme.breakpoints.down("sm")]: {
      padding: 15,
    },
  },
  actions: {
    background: "red",
  },
  name: {
    backgroundColor: "Highlight",
    padding: 16,
    borderRadius: 16,
    marginBottom: 40,
    maxWidth: "max-content",
    width: "100%",
    // opacity: 0.9,
  },
  time: {
    borderRadius: 50,
    maxWidth: "max-content",
    display: "flex",
    background: "#FFFFFF",
    padding: "8px 18px",
  },
}));
export const getServerSideProps = async (ctx) => {
  let allClass = {};
  const id = ctx.query.id;
  const token = parseCookies(ctx)?.token_user;
  if (token) {
    const authorize = JSON.parse(token);
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/class?id=${id}&stream=true`,
      {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      }
    );

    allClass = await res.json();
  }

  return {
    props: {
      allClass,
    },
  };
};

export default function ClassDetail({ allClass }) {
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [comments, setComments] = React.useState([]);
  const [open1, setOpen] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  // init
  React.useEffect(() => {
    if (allClass) {
      convertFilePathToURL(extractObjInArray(allClass.comments)).then(
        (data) => {
          setComments(data);
          console.log(allClass.comments);
        }
      );
    }
  }, [allClass]);

  // Socket
  React.useEffect(() => {
    if (socket) {
      socket.on("class-detail", (data) => {
        convertFilePathToURL(extractObjInArray(data.comments)).then((data) => {
          setComments(data);
        });
      });
    }
  }, [socket]);

  return (
    <Box className={classes.container}>
      <Box sx={{ maxWidth: 600, m: "25px auto" }}>
        <HorizontalTabs data={classMenuItemsForSutdent} />
      </Box>
      <Box>
        <Stack spacing={5}>
          <Box
            className={classes.header}
            sx={{ backgroundImage: `url('/images/Rectangle.jpg')` }}
          >
            <Box className={classes.name}>
              <Typography variant="h6">{allClass.name}</Typography>
              <Typography variant="body2" color="textSecondary">
                {allClass.desc}
              </Typography>
            </Box>
            <Box className={classes.time}>
              <Stack
                direction={"row"}
                spacing={1}
                justifyContent="center"
                alignItems="center"
              >
                <Box sx={{ mr: 1 }}>
                  <Image
                    width={15}
                    height={15}
                    src="/images/time.png"
                    alt="time_img"
                  />
                </Box>
                <Typography>{toDateFormat(allClass.startDate)} </Typography>
                <Typography>{toTime(allClass.startDate)} </Typography>
              </Stack>
            </Box>
          </Box>
          <Box sx={{ width: "100%", display: "flex" }}>
            <Box
              sx={{
                maxWidth: "1200px",
                width: "100%",
                margin: "0 auto",
              }}
            >
              <Grid container spacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={12} sm={12} md={4}>
                  <Stack spacing={2}>
                    {/*  Class Code */}
                    <Box>
                      <Menu
                        id="basic-menu"
                        anchorEl={anchorEl}
                        open={open}
                        onClose={handleClose}
                        MenuListProps={{
                          "aria-labelledby": "basic-button",
                        }}
                      >
                        <MenuItem
                          onClick={() => {
                            navigator.clipboard.writeText(allClass.code);
                            setToast(true);
                            handleClose();
                          }}
                        >
                          Copy class code
                        </MenuItem>
                        <MenuItem onClick={handleClose}>
                          Reset class code
                        </MenuItem>
                      </Menu>
                      <Card>
                        <CardHeader
                          action={
                            <IconButton
                              aria-controls={open ? "basic-menu" : undefined}
                              aria-haspopup="true"
                              aria-expanded={open ? "true" : undefined}
                              onClick={handleClick}
                            >
                              <MoreVertIcon />
                            </IconButton>
                          }
                          subheader="Class Code"
                        />
                        <Typography
                          align="center"
                          sx={{ fontSize: 25, color: " #5DE2E7", mb: 2 }}
                        >
                          {allClass.code}
                        </Typography>
                      </Card>
                    </Box>
                    {/* Upcoming  */}
                    <Box>
                      <UpcomingCard onClick={() => setOpen(true)} />
                    </Box>
                  </Stack>
                </Grid>
                <Grid item xs={12} sm={12} md={8}>
                  <Stack spacing={1.5}>
                    <Box>
                      <CommentInput
                        url={`${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/class/comment/${allClass._id}`}
                      />
                    </Box>
                    {comments?.map((item, index) => {
                      return (
                        <Box key={index}>
                          <CommentCard
                            date={item.date}
                            name={item?.name || "Anonymous"}
                            profile={item?.coverFileName}
                            message={item.text}
                          />
                        </Box>
                      );
                    })}
                  </Stack>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Stack>
      </Box>
      <Snackbar
        open={toast}
        autoHideDuration={6000}
        onClose={() => setToast(false)}
        message={allClass.code}
        action={
          <IconButton
            size="small"
            color="primary"
            onClick={() => setToast(false)}
          >
            <ClearIcon />
          </IconButton>
        }
      />
      <Dialog open={open1}>
        <CertificateDialogCard
          onClose={() => setOpen(false)}
          // certificateImage={certificateImage}
          // certificateLink={certificateLink}
        />
      </Dialog>
    </Box>
  );
}
