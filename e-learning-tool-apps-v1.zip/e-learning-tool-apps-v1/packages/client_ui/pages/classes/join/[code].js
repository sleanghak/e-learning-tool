import React from "react";
import { Box, Paper, Typography, Stack, Button } from "@mui/material";
import { parseCookies } from "nookies";
import Image from "next/image";
export const getServerSideProps = async (ctx) => {
  let authorize = {};
  let data;
  let success = false;
  const code = ctx.query.code;
  const token = parseCookies(ctx)?.token_user;
  if (token) {
    authorize = JSON.parse(token);
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/class/join`,
      {
        method: "post",
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
          "x-access-token": authorize.accessToken,
        },
        body: JSON.stringify({
          classCode: code,
        }),
      }
    );
    data = await res.json();
    if (data.statusCode == 200) {
      success = true;
    }
  }

  return {
    props: {
      success,
      data,
    },
  };
};

const JoinClass = ({ success, data }) => {
  console.log(data);
  return (
    <Paper sx={{ mt: 4, width: 450, ml: "auto", mr: "auto", p: 3 }}>
      <Stack direction={"row"} spacing={3} alignItems="center">
        <Image
          src="/images/cloud_hosting.svg"
          alt="cloud hosting"
          width={300}
          height={300}
        />
        <Box>
          {success ? (
            <>
              <Typography color={"primary"} variant="h4">
                Success, {data.message}
              </Typography>
              <Button href={`/classes`}>See your class</Button>
            </>
          ) : (
            <Box>
              <Typography color={"secondary"} variant="h4">
                Fail, {data.message}
              </Typography>
            </Box>
          )}
        </Box>
      </Stack>
    </Paper>
  );
};

export default JoinClass;
