import React, { useState } from "react";
import {
  Box,
  Grid,
  Typography,
  Rating,
  Button,
  List,
  Stack,
  Dialog,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import HourglassEmptyRoundedIcon from "@mui/icons-material/HourglassEmptyRounded";
import HistoryRoundedIcon from "@mui/icons-material/HistoryRounded";
import HistoryToggleOffRoundedIcon from "@mui/icons-material/HistoryToggleOffRounded";
import MilitaryTechRoundedIcon from "@mui/icons-material/MilitaryTechRounded";
import LayersRoundedIcon from "@mui/icons-material/LayersRounded";
import GroupRoundedIcon from "@mui/icons-material/GroupRounded";
import WorkspacePremiumRoundedIcon from "@mui/icons-material/WorkspacePremiumRounded";
import CourseList from "../../../components/organisms/lists/CourseList";
import FeedbackSetion from "../../../components/templates/classes/FeedbackSetion";
import CourseSection from "../../../components/templates/courses/CourseSection";
import { PlayVideoCard } from "../../../components/molecules/cards";
import {
  learning_rules,
  join_rules,
  map_progression,
} from "../../../utils/constant/requirements";
import useSWR from "swr";
import unauthFetcher from "./../../../utils/func/api/unauthFetch";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import { customPromiseToast } from "../../../components/atoms/toasts";
import RegisterForm from "../../../components/organisms/forms/RegisterForm";
const useStyles = makeStyles((theme) => ({
  root: {
    minWidth: 200,
    paddingBottom: 50,
  },
  head: {},
  head_content: {
    display: "flex",
    flexDirection: "column",
    padding: "40px 40px 0px 40px",
    [theme.breakpoints.down("lg")]: {
      padding: "50px 30px 0px 30px",
    },
    [theme.breakpoints.down("md")]: {
      padding: "30px 20px 0px 20px",
    },
  },
  head_content_item: {
    marginBottom: 50,
    [theme.breakpoints.down("md")]: {
      marginBottom: 30,
    },
    [theme.breakpoints.down("sm")]: {
      marginBottom: 10,
    },
  },
  head_rate: {
    display: "flex",
    alignItems: "center",
  },
  head_description: {},
  head_detail: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  head_detail_item: {
    display: "flex",
    alignItems: "center",
    margin: "20px 20px 0px 0px",
  },
  head_detail_item_icon: {
    fontSize: 30,
    color: "#7D7878",
    marginRight: 20,
    [theme.breakpoints.down("sm")]: {
      fontSize: 25,
      marginRight: 10,
    },
  },
  head_detail_item_text: {
    width: "max-content",
    fontSize: 15,
    [theme.breakpoints.down("sm")]: {
      fontSize: 12,
    },
  },
  head_button: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    [theme.breakpoints.down("sm")]: {
      order: 2,
    },
  },
  head_button_button: {
    minWidth: 180,
    [theme.breakpoints.down("sm")]: {
      order: 2,
      marginBottom: 10,
    },
  },
  head_button_text: {
    minWidth: 200,
    [theme.breakpoints.down("sm")]: {
      order: 1,
      marginBottom: 10,
      marginRight: 10,
    },
  },
  description: {
    padding: "50px",
    [theme.breakpoints.down("md")]: {
      padding: "50px 30px 0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "50px 15px 0px 15px",
    },
  },
  description_title: {
    textAlign: "center",
    marginBottom: 20,
  },
  requirement: {
    padding: "50px",
    [theme.breakpoints.down("md")]: {
      padding: "50px 30px 0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "50px 15px 0px 15px",
    },
  },
  requirement_title: {
    textAlign: "center",
    marginBottom: 30,
  },
  requirement_content: {},
  requirement_content_head: {
    display: "flex",
    flexDirection: "column",
  },
  course: {
    marginTop: 20,
    padding: "0px 50px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 15px",
    },
  },
  course_list: {
    width: "100%",
  },
  feedback: {
    marginTop: 50,
    padding: "0px 50px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 15px",
    },
  },
  more_course: {
    marginTop: 50,
    padding: "0px 50px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 15px",
    },
  },
}));
export const getServerSideProps = async (ctx) => {
  let posts = {};
  const id = ctx.query.id;

  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/post?id=${id}`
  );
  posts = await res.json();

  return {
    props: {
      posts,
    },
  };
};
const PostDetail = ({ posts }) => {
  const classes = useStyles();
  const handleJoinClass = async () => {
    customPromiseToast(
      postDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/post/${posts._id}`
      )
    );
  };
  const [open, setOpen] = React.useState(false);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/course?id=${posts.course._id}`,
    unauthFetcher
  );
  if (error) return `${error}`;
  if (!data) return `Loading ...`;
  return (
    <Box className={classes.root}>
      <Grid container justifyContent={"center"}>
        <Grid item xs={12} sm={11}>
          <Box className={classes.head}>
            <Grid container>
              <Grid item xs={12} sm={12} md={6} lg={6} order={{ xs: 2, md: 1 }}>
                <Box className={classes.head_content}>
                  <Box className={classes.head_content_item}>
                    <Typography variant="title">{posts.name}</Typography>
                  </Box>
                  <Box className={classes.head_content_item}>
                    <Box className={classes.head_rate}>
                      <Box sx={{ mr: "10px" }}>
                        <Typography variant="primary" color="#faaf00">
                          4.8
                        </Typography>
                      </Box>
                      <Rating readOnly value={5} />
                    </Box>
                  </Box>
                  <Box className={classes.head_content_item}>
                    <Box className={classes.head_description}>
                      <Typography variant="primary">
                        {posts.description}
                      </Typography>
                    </Box>
                  </Box>
                  <Box className={classes.head_content_item}>
                    <Box className={classes.head_detail}>
                      <Box className={classes.head_detail_item}>
                        <HourglassEmptyRoundedIcon
                          className={classes.head_detail_item_icon}
                        />
                        <Typography
                          variant="secondary"
                          className={classes.head_detail_item_text}
                        >
                          Duration
                          <br />3 months
                        </Typography>
                      </Box>
                      <Box className={classes.head_detail_item}>
                        <HistoryRoundedIcon
                          className={classes.head_detail_item_icon}
                        />
                        <Typography
                          variant="secondary"
                          className={classes.head_detail_item_text}
                        >
                          Weekly Study
                          <br />3 hours / week
                        </Typography>
                      </Box>
                      <Box className={classes.head_detail_item}>
                        <HistoryToggleOffRoundedIcon
                          className={classes.head_detail_item_icon}
                        />
                        <Typography
                          variant="secondary"
                          className={classes.head_detail_item_text}
                        >
                          Age
                          <br />
                          11 - 18
                        </Typography>
                      </Box>
                      <Box className={classes.head_detail_item}>
                        <MilitaryTechRoundedIcon
                          className={classes.head_detail_item_icon}
                        />
                        <Typography
                          variant="secondary"
                          className={classes.head_detail_item_text}
                        >
                          Certification
                          <br />
                          of Completion
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                  <Box className={classes.head_detail_item}>
                    <Box className={classes.head_button}>
                      <Button
                        variant="contained"
                        className={classes.head_button_button}
                        onClick={() => setOpen(true)}
                      >
                        Join Course
                      </Button>
                      <Typography
                        variant="secondary"
                        className={classes.head_button_text}
                      >
                        ({posts.tels.length} enrolled on this course)
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12} sm={12} md={6} lg={6} order={{ xs: 1, md: 2 }}>
                <Box
                  className={classes.head_detail_video}
                  sx={{ width: "100%", height: "100%" }}
                >
                  <Box className={classes.head_video}>
                    <PlayVideoCard
                      fileName={"/4. Testing Libraries.mp4"}
                      coverFileName={
                        "https://myitconsult.net/wp-content/uploads/2016/08/o-BUSINESS-TECHNOLOGY-facebook-1.jpg"
                      }
                    />
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>
          <Box className={classes.description}>
            <Box>
              <Box className={classes.description_title}>
                <Typography variant="title">Learning on this course</Typography>
              </Box>
              <Box className={classes.description_content}>
                <Typography variant="primary">{posts.description}</Typography>
              </Box>
            </Box>
          </Box>
          <Box className={classes.requirement}>
            <Box>
              <Box className={classes.requirement_title}>
                <Typography variant="title">Requirements</Typography>
              </Box>
              <Box className={classes.requirement_content}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6} md={4} lg={4}>
                    <Box className={classes.requirement_content_head}>
                      <Stack direction="row">
                        <LayersRoundedIcon sx={{ mb: "20px", mr: 2, ml: 3 }} />
                        <Typography variant="title">
                          You learning, your rules
                        </Typography>
                      </Stack>
                    </Box>
                    <ul>
                      {learning_rules.map((item, index) => {
                        return (
                          <li key={index} style={{ padding: 8 }}>
                            <Typography variant="secondary">{item}</Typography>
                          </li>
                        );
                      })}
                    </ul>
                  </Grid>
                  <Grid item xs={12} sm={6} md={4} lg={4}>
                    <Box className={classes.requirement_content_head}>
                      <Stack direction={"row"}>
                        <GroupRoundedIcon sx={{ mb: "20px", mr: 2, ml: 3 }} />
                        <Typography variant="title">Join Classroom</Typography>
                      </Stack>
                    </Box>
                    <ul>
                      {join_rules.map((item, index) => {
                        return (
                          <li key={index} style={{ padding: 8 }}>
                            <Typography variant="secondary">{item}</Typography>
                          </li>
                        );
                      })}
                    </ul>
                  </Grid>
                  <Grid item xs={12} sm={6} md={4} lg={4}>
                    <Box className={classes.requirement_content_head}>
                      <Stack direction={"row"}>
                        <WorkspacePremiumRoundedIcon
                          sx={{ mb: "20px", mr: 2, ml: 3 }}
                        />
                        <Typography variant="title">
                          Map your progress
                        </Typography>
                      </Stack>
                    </Box>
                    <ul>
                      {map_progression.map((item, index) => {
                        return (
                          <li key={index} style={{ padding: 8 }}>
                            <Typography variant="secondary">{item}</Typography>
                          </li>
                        );
                      })}
                    </ul>
                  </Grid>
                </Grid>
              </Box>
            </Box>
          </Box>
          <Box className={classes.requirement_title}>
            <Typography variant="title">Course Content</Typography>
          </Box>
          <Box className={classes.course}>
            <CourseList course={posts.name} subList={data?.lessonIds} />
          </Box>
          {/* <Box className={classes.feedback}>
            <FeedbackSetion data={allCourse.comments} />
          </Box>
          <Box className={classes.more_course}>
            <Box>
              <CourseSection data={data.courseIds} title="More Course" />
            </Box>
          </Box> */}
          <Dialog open={open} onClose={() => setOpen(false)}>
            <RegisterForm postId={posts._id} onClose={() => setOpen(false)} />
          </Dialog>
        </Grid>
      </Grid>
    </Box>
  );
};

export default PostDetail;
