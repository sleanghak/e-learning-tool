import React from "react";
import { Box, Grid, Stack } from "@mui/material";
import CourseSection from "../../components/templates/courses/CourseSection";
import { UpcomingClassCard } from "./../../components/organisms/cards";
import { convertFilePathToURL } from "../../utils/func/s3";
import postDataFunc from "./../../utils/func/api/postDataFunc";
import HeaderTitle from "../../components/molecules/HeaderTitle";

export async function getServerSideProps(ctx) {
  let courses = [];
  let posts = [];
  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/department`
  );
  const resPost = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/post`);
  courses = await res.json();
  posts = await resPost.json();
  return {
    props: {
      courses,
      posts,
    },
  };
}

const Course = ({ courses, posts, user }) => {
  const [postStates, setPostStates] = React.useState([]);
  const handleJoinClass = async (data) => {
    // console.log(data);
    await postDataFunc(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/post/${data._id}`
    );
  };
  React.useEffect(() => {
    if (posts) {
      convertFilePathToURL(posts.data).then((data) => {
        setPostStates(data);
        console.log(data);
      });
    }
  }, [posts]);
  return (
    <React.Fragment>
      <Box>
        <HeaderTitle />
      </Box>
      <Box sx={{ mb: 5 }}>
        <Grid container justifyContent={"center"}>
          <Grid item xs={12} sm={11}>
            <Grid container spacing={1}>
              {postStates.map((post, index) => {
                return (
                  <Grid item xs={12} sm={6} md={4} key={index}>
                    <Box sx={{ ml: 2, mr: 2, mt: 1 }}>
                      <UpcomingClassCard
                        _id={post._id}
                        startDate={post.startDate}
                        description={post.description}
                        coverFileName={post.fileName}
                        title={post.name}
                        time={post.time}
                        onClick={() => console.log("hello")}
                        onJoinClassFunc={() => handleJoinClass(post)}
                      />
                    </Box>
                  </Grid>
                );
              })}
            </Grid>
          </Grid>
        </Grid>
      </Box>
      <Grid container justifyContent={"center"}>
        <Grid item xs={12} sm={11}>
          <Stack spacing={3}>
            {courses?.map((subject, index) => {
              return (
                <Box key={index} sx={{ mb: 3 }}>
                  <CourseSection
                    title={subject.name}
                    data={subject.courseIds}
                    user={user}
                  />
                </Box>
              );
            })}
          </Stack>
        </Grid>
      </Grid>
    </React.Fragment>
  );
};

export default Course;
