import React from "react";
import {
  Box,
  Grid,
  Typography,
  Rating,
  Button,
  List,
  Stack,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import HourglassEmptyRoundedIcon from "@mui/icons-material/HourglassEmptyRounded";
import HistoryRoundedIcon from "@mui/icons-material/HistoryRounded";
import HistoryToggleOffRoundedIcon from "@mui/icons-material/HistoryToggleOffRounded";
import MilitaryTechRoundedIcon from "@mui/icons-material/MilitaryTechRounded";
import LayersRoundedIcon from "@mui/icons-material/LayersRounded";
import GroupRoundedIcon from "@mui/icons-material/GroupRounded";
import WorkspacePremiumRoundedIcon from "@mui/icons-material/WorkspacePremiumRounded";
import CourseList from "../../components/organisms/lists/CourseList";
import FeedbackSetion from "../../components/templates/classes/FeedbackSetion";
import CourseSection from "../../components/templates/courses/CourseSection";
import { PlayVideoCard } from "./../../components/molecules/cards";
import useSWR from "swr";
import unauthFetcher from "../../utils/func/api/unauthFetch";
import useSocket from "./../../utils/func/socket/useSocket";
import {
  learning_rules,
  join_rules,
  map_progression,
} from "../../utils/constant/requirements";
import { convertFilePathToURL } from "../../utils/func/s3";

const useStyles = makeStyles((theme) => ({
  root: {
    minWidth: 200,
    paddingBottom: 50,
  },
  head: {},
  head_content: {
    display: "flex",
    flexDirection: "column",
    padding: "40px 40px 0px 40px",
    [theme.breakpoints.down("lg")]: {
      padding: "50px 30px 0px 30px",
    },
    [theme.breakpoints.down("md")]: {
      padding: "30px 20px 0px 20px",
    },
  },
  head_content_item: {
    marginBottom: 50,
    [theme.breakpoints.down("md")]: {
      marginBottom: 30,
    },
    [theme.breakpoints.down("sm")]: {
      marginBottom: 10,
    },
  },
  head_rate: {
    display: "flex",
    alignItems: "center",
  },
  head_description: {},
  head_detail: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  head_detail_item: {
    display: "flex",
    alignItems: "center",
    margin: "20px 20px 0px 0px",
  },
  head_detail_item_icon: {
    fontSize: 30,
    color: "#7D7878",
    marginRight: 20,
    [theme.breakpoints.down("sm")]: {
      fontSize: 25,
      marginRight: 10,
    },
  },
  head_detail_item_text: {
    width: "max-content",
    fontSize: 15,
    [theme.breakpoints.down("sm")]: {
      fontSize: 12,
    },
  },
  head_button: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    [theme.breakpoints.down("sm")]: {
      order: 2,
    },
  },
  head_button_button: {
    minWidth: 180,
    [theme.breakpoints.down("sm")]: {
      order: 2,
      marginBottom: 10,
    },
  },
  head_button_text: {
    minWidth: 200,
    [theme.breakpoints.down("sm")]: {
      order: 1,
      marginBottom: 10,
      marginRight: 10,
    },
  },
  description: {
    padding: "50px",
    [theme.breakpoints.down("md")]: {
      padding: "50px 30px 0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "50px 15px 0px 15px",
    },
  },
  description_title: {
    textAlign: "center",
    marginBottom: 20,
  },
  requirement: {
    padding: "50px",
    [theme.breakpoints.down("md")]: {
      padding: "50px 30px 0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "50px 15px 0px 15px",
    },
  },
  requirement_title: {
    textAlign: "center",
    marginBottom: 30,
  },
  requirement_content: {},
  requirement_content_head: {
    display: "flex",
    flexDirection: "column",
  },
  course: {
    marginTop: 20,
    padding: "0px 50px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 15px",
    },
  },
  course_list: {
    width: "100%",
  },
  feedback: {
    marginTop: 50,
    padding: "0px 50px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 15px",
    },
  },
  more_course: {
    marginTop: 50,
    padding: "0px 50px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 30px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 15px",
    },
  },
}));
export const getServerSideProps = async (ctx) => {
  let allCourse = {};
  const id = ctx.query.id;
  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/course?id=${id}`
  );
  allCourse = await res.json();
  return {
    props: {
      allCourse,
    },
  };
};
const CourseDetail = ({ allCourse, user }) => {
  console.log("course", allCourse);
  const classes = useStyles();
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const [course, setCourse] = React.useState({});
  const [reviewers, setReviewers] = React.useState(allCourse.comments);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/department?id=${allCourse.subjectId._id}`,
    unauthFetcher
  );
  React.useEffect(() => {
    console.log("before", allCourse);
    convertFilePathToURL(allCourse).then((data) => {
      setCourse(data);
      console.log("course", data);
    });
  }, []);
  React.useEffect(() => {
    if (socket) {
      socket.on("unauthor-course", (data) => {
        setReviewers(data.comments);
      });
    }
  }, [socket]);

  if (error) return `${error}`;
  if (!data) return `Loading ...`;

  return (
    <Box className={classes.root}>
      <Grid container justifyContent={"center"}>
        <Grid item xs={12} sm={11}>
          <Box className={classes.head}>
            <Grid container>
              <Grid item xs={12} sm={12} md={6} lg={6} order={{ xs: 2, md: 1 }}>
                <Box className={classes.head_content}>
                  <Box className={classes.head_content_item}>
                    <Typography variant="title">{allCourse.name}</Typography>
                  </Box>
                  <Box className={classes.head_content_item}>
                    <Box className={classes.head_rate}>
                      <Box sx={{ mr: "10px" }}>
                        <Typography variant="primary" color="#faaf00">
                          4.8
                        </Typography>
                      </Box>
                      <Rating readOnly value={5} />
                    </Box>
                  </Box>
                  <Box className={classes.head_content_item}>
                    <Box className={classes.head_description}>
                      <Typography variant="primary">
                        Improve your practical digital literacy skills and
                        enhance your confidence online with this practical
                        course.
                      </Typography>
                    </Box>
                  </Box>
                  <Box className={classes.head_content_item}>
                    <Box className={classes.head_detail}>
                      <Box className={classes.head_detail_item}>
                        <HourglassEmptyRoundedIcon
                          className={classes.head_detail_item_icon}
                        />
                        <Typography
                          variant="secondary"
                          className={classes.head_detail_item_text}
                        >
                          Duration
                          <br />3 months
                        </Typography>
                      </Box>
                      <Box className={classes.head_detail_item}>
                        <HistoryRoundedIcon
                          className={classes.head_detail_item_icon}
                        />
                        <Typography
                          variant="secondary"
                          className={classes.head_detail_item_text}
                        >
                          Weekly Study
                          <br />3 hours / week
                        </Typography>
                      </Box>
                      <Box className={classes.head_detail_item}>
                        <HistoryToggleOffRoundedIcon
                          className={classes.head_detail_item_icon}
                        />
                        <Typography
                          variant="secondary"
                          className={classes.head_detail_item_text}
                        >
                          Age
                          <br />
                          11 - 18
                        </Typography>
                      </Box>
                      <Box className={classes.head_detail_item}>
                        <MilitaryTechRoundedIcon
                          className={classes.head_detail_item_icon}
                        />
                        <Typography
                          variant="secondary"
                          className={classes.head_detail_item_text}
                        >
                          Certification
                          <br />
                          of Completion
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                  {/* <Box className={classes.head_detail_item}>
                    <Box className={classes.head_button}>
                      <Button
                        variant="contained"
                        className={classes.head_button_button}
                      >
                        Join Course
                      </Button>
                      <Typography
                        variant="secondary"
                        className={classes.head_button_text}
                      >
                        (25 enrolled on this course)
                      </Typography>
                    </Box>
                  </Box> */}
                </Box>
              </Grid>
              <Grid item xs={12} sm={12} md={6} lg={6} order={{ xs: 1, md: 2 }}>
                <Box
                  className={classes.head_detail_video}
                  sx={{ width: "100%", height: "100%" }}
                >
                  <Box className={classes.head_video}>
                    <PlayVideoCard
                      fileName={course.fileName}
                      coverFileName={course.coverFileName}
                    />
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>
          <Box className={classes.description}>
            <Box>
              <Box className={classes.description_title}>
                <Typography variant="title">Learning on this course</Typography>
              </Box>
              <Box className={classes.description_content}>
                <Typography variant="primary">{allCourse.desc}</Typography>
              </Box>
            </Box>
          </Box>
          <Box className={classes.requirement}>
            <Box>
              <Box className={classes.requirement_title}>
                <Typography variant="title">Requirements</Typography>
              </Box>
              <Box className={classes.requirement_content}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6} md={4} lg={4}>
                    <Box className={classes.requirement_content_head}>
                      <Stack direction="row">
                        <LayersRoundedIcon sx={{ mb: "20px", mr: 2, ml: 3 }} />
                        <Typography variant="title">
                          You learning, your rules
                        </Typography>
                      </Stack>
                    </Box>
                    <ul>
                      {learning_rules.map((item, index) => {
                        return (
                          <li key={index} style={{ padding: 8 }}>
                            <Typography variant="secondary">{item}</Typography>
                          </li>
                        );
                      })}
                    </ul>
                  </Grid>
                  <Grid item xs={12} sm={6} md={4} lg={4}>
                    <Box className={classes.requirement_content_head}>
                      <Stack direction={"row"}>
                        <GroupRoundedIcon sx={{ mb: "20px", mr: 2, ml: 3 }} />
                        <Typography variant="title">Join Classroom</Typography>
                      </Stack>
                    </Box>
                    <ul>
                      {join_rules.map((item, index) => {
                        return (
                          <li key={index} style={{ padding: 8 }}>
                            <Typography variant="secondary">{item}</Typography>
                          </li>
                        );
                      })}
                    </ul>
                  </Grid>
                  <Grid item xs={12} sm={6} md={4} lg={4}>
                    <Box className={classes.requirement_content_head}>
                      <Stack direction={"row"}>
                        <WorkspacePremiumRoundedIcon
                          sx={{ mb: "20px", mr: 2, ml: 3 }}
                        />
                        <Typography variant="title">
                          Map your progress
                        </Typography>
                      </Stack>
                    </Box>
                    <ul>
                      {map_progression.map((item, index) => {
                        return (
                          <li key={index} style={{ padding: 8 }}>
                            <Typography variant="secondary">{item}</Typography>
                          </li>
                        );
                      })}
                    </ul>
                  </Grid>
                </Grid>
              </Box>
            </Box>
          </Box>
          <Box className={classes.requirement_title}>
            <Typography variant="title">Course Content</Typography>
          </Box>
          <Box className={classes.course}>
            <List className={classes.course_list} component="nav">
              <CourseList
                course={allCourse.name}
                subList={allCourse.lessonIds}
              />
            </List>
          </Box>
          <Box className={classes.feedback}>
            <FeedbackSetion
              data={reviewers}
              user={user?.data || null}
              url={`${process.env.NEXT_PUBLIC_API_URL}/api/v1/student/course/comments/${allCourse._id}`}
            />
          </Box>
          <Box className={classes.more_course}>
            <Box>
              <CourseSection data={data.courseIds} title="More Course" />
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default CourseDetail;
