import React from "react";
import { Box, Grid, Typography } from "@mui/material";
import { CourseCard } from "../components/organisms/cards";
import { convertFilePathToURL } from "../utils/func/s3";
import deleteDataFunc from "./../utils/func/api/deleteDataFunc";
const FavoritePage = ({ user }) => {
  const [courses, setCourses] = React.useState([]);
  const removeFavoriteFunc = async (courseId) => {
    try {
      await deleteDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/course/removeFavorite/${courseId}`
      );
    } catch (error) {
      console.log(error);
    }
  };
  React.useEffect(() => {
    async function convertCourseToURL() {
      const courses = await convertFilePathToURL(user.data.courses);
      setCourses(courses);
    }
    convertCourseToURL();
  }, []);
  return (
    <Box>
      <Typography sx={{ m: 3 }} align="center" variant="h3">
        Your Favorite Courses
      </Typography>
      <Box sx={{ m: 3 }}>
        <Grid container spacing={3}>
          {courses?.map((course, index) => {
            return (
              <Grid key={index} item xs={12} sm={5} md={3}>
                <CourseCard
                  removeFavoriteFunc={() => removeFavoriteFunc(course._id)}
                  isRemove={true}
                  {...course}
                />
              </Grid>
            );
          })}
        </Grid>
      </Box>
    </Box>
  );
};

export default FavoritePage;
