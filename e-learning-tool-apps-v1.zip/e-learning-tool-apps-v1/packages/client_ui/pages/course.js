import React from "react";
import { Box, Grid, Stack, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";
import CourseSection from "../components/templates/courses/CourseSection";
import { convertFilePathToURL } from "../utils/func/s3";
import { UpcomingClassCard } from "../components/organisms/cards";
import { useRouter } from "next/router";
import unauthFetcher from "../utils/func/api/unauthFetch";
import HeaderTitle from "../components/molecules/HeaderTitle";
import Title from "../components/atoms/Title";

const useStyles = makeStyles((theme) => ({
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
}));

export async function getServerSideProps(ctx) {
  let courses = [];
  let posts = [];
  try {
    courses = await unauthFetcher(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/department`
    );
    posts = await unauthFetcher(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/post?disable=false`
    );
  } catch (error) {
    console.log(error);
  }

  return {
    props: {
      courses,
      posts,
    },
  };
}
const Course = ({ courses, posts }) => {
  const classes = useStyles();
  const [postStates, setPostStates] = React.useState([]);
  const router = useRouter();
  React.useEffect(() => {
    if (posts) {
      convertFilePathToURL(posts.data).then((data) => {
        setPostStates(data);
      });
    }
  }, [posts]);

  const handleJoinClassFunc = () => {
    router.push("/auth/signup");
  };
  return (
    <React.Fragment>
      <Box>
        <HeaderTitle
          text={
            "Our goal is not to produce future computer scientists (although we would not be surprised if it happens). Our goal is to introduce computer science fundamentals to students at a young age. So that they do not grow up intimidated by computer science field."
          }
        />
      </Box>
      <Box className={classes.container}>
        <Stack direction="column" spacing={5}>
          <Box>
            <Title>
              <Typography align="center" variant="h5">
                UPCOMING CLASS
              </Typography>
            </Title>
          </Box>
          <Box>
            <Grid container spacing={1}>
              {postStates.map((post, index) => {
                return (
                  <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    key={index}
                    display="flex"
                    justifyContent="center"
                  >
                    <UpcomingClassCard
                      _id={post._id}
                      startDate={post.startDate}
                      description={post.description}
                      coverFileName={post.fileName}
                      title={post.name}
                      time={post.time}
                      joinClassFunc={() => handleJoinClassFunc(post)}
                    />
                  </Grid>
                );
              })}
            </Grid>
          </Box>
          <Box>
            {courses?.map((subject, index) => {
              return (
                <Box key={index} mb={5}>
                  <CourseSection
                    title={subject.name}
                    data={subject.courseIds}
                  />
                </Box>
              );
            })}
          </Box>
        </Stack>
      </Box>
    </React.Fragment>
  );
};

export default Course;
