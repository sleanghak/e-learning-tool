import { Typography } from "@mui/material";

const Inventory = () => {
    return ( 
        <div>
            <Typography>
                Inventory
            </Typography>
        </div>
     );
}
 
export default Inventory;