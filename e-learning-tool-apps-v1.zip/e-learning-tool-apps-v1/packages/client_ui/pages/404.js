import React from "react";
import { makeStyles } from "@mui/styles";
import Image from "next/image";
import { Box, Typography, Button } from "@mui/material";
import Link from "next/link";

const useStyles = makeStyles((theme) => ({
  root: {
    width: 400,
    margin: "0px auto",
    textAlign: "center",
  },
}));
const NotFounded = ({}) => {
  const classes = useStyles();
  return (
    <Box sx={{ mb: 6 }}>
      <div className={classes.root}>
        <Image src="/404.svg" alt="unknow page" width={400} height={400} />
        <h1>Not Founded Page </h1>
      </div>
      <Typography align="center">
        <Link href="/">
          <Button>Home Page</Button>
        </Link>
      </Typography>
    </Box>
  );
};

export default NotFounded;
