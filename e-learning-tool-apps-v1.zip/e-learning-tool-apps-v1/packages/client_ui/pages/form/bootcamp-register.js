import React, { useState, useEffect } from "react";
import { Box } from "@mui/material";
import { makeStyles } from "@mui/styles";

//component
import RegisterForm from "../../components/templates/RegisterForm";
import CardFormSuccess from "../../components/molecules/cards/CardFormSuccess";

//data

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  container: {
    padding: "30px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "30px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "30px 10px",
    },
  },
}));

const Bootcamp_register = ({}) => {
  const classes = useStyles();
  const success = false;

  return (
    <Box className={classes.root}>
      <Box className={classes.container}>
        {success ? <CardFormSuccess /> : <RegisterForm />}
      </Box>
    </Box>
  );
};
export default Bootcamp_register;
