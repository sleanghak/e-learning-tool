import { Box, Typography } from "@mui/material";
const Page500 = () => {
  return (
    <Box>
      <Typography color="error"> Custom Internal Server Error</Typography>
    </Box>
  );
};

export default Page500;
