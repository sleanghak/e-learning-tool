import React, { useState, useEffect } from "react";
import { Box, Stack, Typography, Grid } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { getFileURL } from "../utils/func/s3";
// conponents
import HeaderTitle from "../components/molecules/HeaderTitle";
import OurstorySection from "../components/organisms/cards/OurstorySection";
import OurPeopleCard from "../components/organisms/cards/OurPeopleCard";
import CoachCard from "../components/organisms/cards/CoachCard";
import DifferentCard from "../components/molecules/cards/DifferentCard";
import Bookmark from "../components/organisms/lists/Bookmark";
import { Player } from "video-react";
import { aboutBookmark } from "../utils/constant/bookmark";

//model
import {
  ourStory,
  different,
  differentCard,
  ourPeople,
  ourCoaches,
  ourPeopleCard,
  ourCoachesCard,
} from "../utils/constant/about";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  container: {
    padding: "0px 30px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 20px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 10px",
    },
  },
  title: {
    fontSize: 30,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 20,
    marginBottom: "40px",
    [theme.breakpoints.down("md")]: {
      marginBottom: "30px",
    },
    [theme.breakpoints.down("sm")]: {
      marginBottom: "20px",
    },
  },
  our_story: {
    width: "100%",
  },
}));

const About = ({}) => {
  const classes = useStyles();
  const [videoUrl, setVideoUrl] = React.useState("");
  React.useEffect(() => {
    getFileURL("statics/Bootcamp.mp4").then((url) => {
      setVideoUrl(url);
    });
  });
  return (
    <Box className={classes.root}>
      <Box sx={{ p: 0 }}>
        <Player
          playInline
          poster="/images/poster_sabaicode_plan_2022.png"
          autoPlay={true}
          src={videoUrl}
        />
      </Box>
      <Stack direction="row">
        <Stack spacing={{ xs: 4, sm: 5, md: 6 }} className={classes.container}>
          <Box className={classes.our_story} id="our_story">
            <Typography className={classes.title}>{ourStory.title}</Typography>
            <Stack spacing={{ xs: 2, sm: 3 }}>
              {ourStory.description.map((item, index) => {
                return (
                  <Typography sx={{ fontSize: "18px" }} key={index}>
                    {item.paragraph}
                  </Typography>
                );
              })}
            </Stack>
            <Box sx={{ mt: { xs: 4, sm: 5, md: 6 } }}>
              <OurstorySection />
            </Box>
          </Box>

          <Box id="different">
            <Typography className={classes.title}>{different.title}</Typography>
            <Typography
              sx={{ fontSize: "18px", mb: { xs: "10px", md: "20px" } }}
            >
              {different.description}
            </Typography>
            <Stack spacing={{ xs: 2, sm: 3, md: 4 }}>
              {differentCard.map((item, index) => {
                return (
                  <DifferentCard
                    key={index}
                    flip={item.flip}
                    title={item.title}
                    description={item.description}
                    imagePath={item.imagePath}
                  />
                );
              })}
            </Stack>
          </Box>

          <Box id="our_people">
            <Typography className={classes.title}>{ourPeople.title}</Typography>
            <Stack spacing={{ xs: 4, sm: 5, md: 6 }}>
              <Typography sx={{ fontSize: "18px" }}>
                {ourPeople.description}
              </Typography>
              {ourPeopleCard.map((item, index) => {
                return (
                  <OurPeopleCard
                    key={index}
                    imagePath={item.imagePath}
                    name={item.name}
                    position={item.position}
                    description={item.description}
                  />
                );
              })}
            </Stack>
          </Box>
          <Box>
            <Typography className={classes.title}>
              {ourCoaches.title}
            </Typography>
            <Stack spacing={{ xs: 4, sm: 5, md: 6 }}>
              <Typography sx={{ fontSize: "18px" }}>
                {ourCoaches.description}
              </Typography>
              <Grid container spacing={2} sx={{ width: "100%" }}>
                {ourCoachesCard.map((item, index) => {
                  return (
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={4}
                      key={index}
                      sx={{ display: "flex", justifyContent: "center" }}
                    >
                      <CoachCard
                        cover={item.cover}
                        profile={item.profile}
                        name={item.name}
                        position={item.posiotion}
                      />
                    </Grid>
                  );
                })}
              </Grid>
            </Stack>
          </Box>
        </Stack>

        <Bookmark bookmark={aboutBookmark} />
      </Stack>
    </Box>
  );
};

export default About;
