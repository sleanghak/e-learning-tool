const listItemTheme = {
  styleOverrides: {
    root: {
      padding: 4,
    },
  },
};

export { listItemTheme };
