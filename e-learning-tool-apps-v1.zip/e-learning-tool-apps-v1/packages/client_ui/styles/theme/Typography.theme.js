const typographyTheme = {
    variants: [
        {
            props: { variant: 'primary' },
            style: {
                fontWeight: '400',
            },
        },
        {
            props: { variant: 'secondary' },
            style: {
                fontSize: 15,
                color: '#787878',
                fontWeight: '400',
            },
        },
        {
            props: { variant: 'title' },
            style: {
                fontSize: '20px',
                fontWeight: '700',
            },
        },
{
    props: { variant: 'logo' },
    style: {
        fontFamily: 'Cambria',
            fontSize: '2rem',
                fontWeight: '700',
            },
},
    ],
};

export default typographyTheme;