import { createTheme } from "@mui/material/styles";
import { red } from "@mui/material/colors";
import { tabsTheme, tabTheme } from "./tabs.theme";
import typographyTheme from "./Typography.theme";
import buttonTheme from "./button.theme";
import cardTheme from "./Card.theme";
import { listItemTheme } from "./list.theme";
// TODO : Change Theme
const ligthTheme = createTheme({
  palette: {
    type: "light",
    primary: {
      main: "#5DE2E7",
      contrastText: "#000000",
    },
    secondary: {
      main: "#F81818",
    },
    warning: {
      main: "#FFC107",
      contrastText: "#000",
    },
    info: {
      main: "#29b6f6",
    },
    success: {
      main: "#66bb6a",
    },
    error: {
      main: "#f44336",
    },
    black: {
      main: "#000",
    },
    white: {
      main: "#ffffff",
    },
  },

  typography: {
    fontSize: 14,
    bold: {
      fontWeight: "bold",
    },
    italic: {
      fontWeight: "italic",
    },
  },
  components: {
    MuiButton: buttonTheme,
    MuiTab: tabTheme,
    MuiTabs: tabsTheme,
    MuiTypography: typographyTheme,
    MuiButton: buttonTheme,
    MuiCard: cardTheme,
    MuiListItem: listItemTheme,
  },
});

const darkTheme = createTheme({
  palette: {
    type: "dark",
    primary: {
      main: "#000",
      contrastText: "#fff",
    },
    secondary: {
      main: red[700],
    },
    warning: {
      main: "#FFC107",
      contrastText: "#000",
    },
    info: {
      main: "#29b6f6",
    },
    success: {
      main: "#66bb6a",
    },
    error: {
      main: "#f44336",
    },
    black: {
      main: "#FFFFFf",
    },
    white: {
      main: "#000000",
    },
  },
  typography: {
    fontFamily: "Roboto",
    fontWeightLight: 300,
    fontWeightMedium: 500,
    fontWeightRegular: 400,
    fontWeightBold: 600,
  },
  components: {
    MuiButton: buttonTheme,
    MuiTab: tabTheme,
    MuiTabs: tabsTheme,
    MuiTypography: typographyTheme,
    MuiButton: buttonTheme,
    MuiCard: cardTheme,
    MuiListItem: listItemTheme,
  },
});
export { ligthTheme, darkTheme };
