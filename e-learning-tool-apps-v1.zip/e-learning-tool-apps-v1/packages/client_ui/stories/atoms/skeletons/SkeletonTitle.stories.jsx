import SkeletonTitle from '../../../components/atoms/skeletons/SkeletonTitle';

export default {
    title: 'atoms/skeletons/SkeletonTitle',
    component: SkeletonTitle,
};

const Template = (args) => <SkeletonTitle {...args} />;
export const Primary = Template.bind({});