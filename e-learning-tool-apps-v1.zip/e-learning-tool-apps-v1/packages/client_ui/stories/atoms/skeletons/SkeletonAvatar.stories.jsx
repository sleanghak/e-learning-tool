import SkeletonAvatar from '../../../components/atoms/skeletons/SkeletonAvatar';

export default {
    title: 'atoms/skeletons/SkeletonAvatar',
    component: SkeletonAvatar,
};

const Template = (args) => <SkeletonAvatar {...args} />;
export const Primary = Template.bind({});