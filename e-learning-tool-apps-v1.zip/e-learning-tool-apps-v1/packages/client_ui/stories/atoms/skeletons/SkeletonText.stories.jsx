import SkeletonText from '../../../components/atoms/skeletons/SkeletonText';

export default {
    title: 'atoms/skeletons/SkeletonText',
    component: SkeletonText,
};

const Template = (args) => <SkeletonText {...args} />;
export const Primary = Template.bind({});