import SkeletonIcon from '../../../components/atoms/skeletons/SkeletonIcon';

export default {
    title: 'atoms/skeletons/SkeletonIcon',
    component: SkeletonIcon,
};

const Template = (args) => <SkeletonIcon {...args} />;
export const Primary = Template.bind({});