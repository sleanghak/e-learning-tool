import SkeletonMadia from '../../../components/atoms/skeletons/SkeletonMadia';

export default {
    title: 'atoms/skeletons/SkeletonMadia',
    component: SkeletonMadia,
};

const Template = (args) => <SkeletonMadia {...args} />;
export const Primary = Template.bind({});