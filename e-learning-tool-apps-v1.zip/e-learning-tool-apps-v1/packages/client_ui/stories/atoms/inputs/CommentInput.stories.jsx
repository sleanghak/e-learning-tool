import CommentInput from '../../../components/atoms/inputs/CommentInput';

export default {
    title: 'atoms/inputs/CommentInput',
    component: CommentInput,
};

const Template = (args) => <CommentInput {...args} />;
export const Primary = Template.bind({});