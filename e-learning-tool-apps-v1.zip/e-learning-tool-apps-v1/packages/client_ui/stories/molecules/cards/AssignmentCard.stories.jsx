import AssignmentCard from '../../../components/molecules/cards/AssignmentCard';

export default {
    title: 'molecules/cards/AssignmentCard',
    component: AssignmentCard,
};

const Template = (args) => <AssignmentCard {...args} />;
export const Primary = Template.bind({});