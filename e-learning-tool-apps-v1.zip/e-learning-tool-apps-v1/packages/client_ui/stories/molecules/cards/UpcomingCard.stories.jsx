import UpcomingCard from '../../../components/molecules/cards/UpcomingCard';

export default {
    title: 'molecules/cards/UpcomingCard',
    component: UpcomingCard,
};

const Template = (args) => <UpcomingCard {...args} />;
export const Primary = Template.bind({});