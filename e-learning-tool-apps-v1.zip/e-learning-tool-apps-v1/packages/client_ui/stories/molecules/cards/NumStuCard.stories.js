import NumStuCard from '../../../components/molecules/cards/NumStuCard';

export default {
    title: 'molecules/cards/NumStuCard',
    component: NumStuCard,
};

const Template = (args) => <NumStuCard {...args} />;
export const Primary = Template.bind({});