
import ClassWorkCard from '../../../components/molecules/cards/ClassWorkCard';

export default {
    title: 'molecules/cards/ClassWorkCard',
    component: ClassWorkCard,
};

const Template = (args) => <ClassWorkCard {...args} />;
export const Primary = Template.bind({});