import ClassTitle from '../../../components/molecules/headers/ClassTitle';

export default {
    title: 'molecules/headers/ClassTitle',
    component: ClassTitle,
};

const Template = (args) => <ClassTitle {...args} />;
export const Classtitle = Template.bind({});