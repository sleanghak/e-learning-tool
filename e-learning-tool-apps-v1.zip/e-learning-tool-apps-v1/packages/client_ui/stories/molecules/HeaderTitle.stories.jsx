import HeaderTitle from "../../components/molecules/HeaderTitle";

export default {
    title: 'molecules/HeaderTitle',
    component: HeaderTitle,
};

const Template = (args) => <HeaderTitle {...args} />;
export const Primary = Template.bind({});