import CourseList from '../../../components/organisms/lists/CourseList';

export default {
    title: 'organisms/lists/CourseList',
    component: CourseList,
};

const Template = (args) => <CourseList {...args} />;
export const Primary = Template.bind({});