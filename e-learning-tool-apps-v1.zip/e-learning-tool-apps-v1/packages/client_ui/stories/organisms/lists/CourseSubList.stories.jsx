import CourseSubList from '../../../components/organisms/lists/CourseSubList';

export default {
    title: 'organisms/lists/CourseSubList',
    component: CourseSubList,
};

const Template = (args) => <CourseSubList {...args} />;
export const Primary = Template.bind({});