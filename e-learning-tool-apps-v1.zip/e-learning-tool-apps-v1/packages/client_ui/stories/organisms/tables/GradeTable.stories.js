import GradeTable from '../../../components/organisms/tables/GradeTable';

export default {
    title: 'organisms/tables/GradeTable',
    component: GradeTable,
};

const Template = (args) => <GradeTable {...args} />;
export const Primary = Template.bind({});