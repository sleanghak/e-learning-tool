import SabaiCodeTable from '../../../components/organisms/tables/SabaiCodeTable';

export default {
    title: 'organisms/tables/SabaiCodeTable',
    component: SabaiCodeTable,
};

const Template = (args) => <SabaiCodeTable {...args} />;
export const Primary = Template.bind({});