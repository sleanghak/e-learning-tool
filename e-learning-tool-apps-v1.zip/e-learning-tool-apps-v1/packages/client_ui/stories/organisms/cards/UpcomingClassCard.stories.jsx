import UpcomingClassCard from '../../../components/organisms/cards/UpcomingClassCard';

export default {
    title: 'organisms/cards/UpcomingClassCard',
    component: UpcomingClassCard,
};

const Template = (args) => <UpcomingClassCard {...args} />;
export const Primary = Template.bind({});