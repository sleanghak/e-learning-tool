import CertificateDialogCard from '../../../components/organisms/cards/CertificateDialogCard';

export default {
    title: 'organisms/cards/CertificateDialogCard',
    component: CertificateDialogCard,
};

const Template = (args) => <CertificateDialogCard {...args} />;
export const Primary = Template.bind({});