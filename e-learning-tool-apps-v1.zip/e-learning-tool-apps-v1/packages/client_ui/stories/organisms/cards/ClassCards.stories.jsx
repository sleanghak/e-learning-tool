import ClassCard from '../../../components/organisms/cards/ClassCard';

export default {
    title: 'organisms/cards/ClassCard',
    component: ClassCard,
};

const Template = (args) => <ClassCard {...args} />;
export const Primary = Template.bind({});