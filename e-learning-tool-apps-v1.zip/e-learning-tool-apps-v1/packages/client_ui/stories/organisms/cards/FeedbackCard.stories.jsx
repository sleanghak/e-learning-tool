import FeedbackCard from '../../../components/organisms/cards/FeedbackCard';

export default {
    title: 'organisms/cards/FeedbackCard',
    component: FeedbackCard,
};

const Template = (args) => <FeedbackCard {...args} />;
export const Primary = Template.bind({});