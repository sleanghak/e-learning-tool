import CertificateCard from '../../../components/organisms/cards/CertificateCard';

export default {
    title: 'organisms/cards/CertificateCard',
    component: CertificateCard,
};

const Template = (args) => <CertificateCard {...args} />;
export const Primary = Template.bind({});