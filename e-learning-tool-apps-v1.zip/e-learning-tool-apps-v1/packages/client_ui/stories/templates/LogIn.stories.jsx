import LogIn from '../../components/templates/LogIn';

export default {
    title: 'templates/LogIn',
    component: LogIn,
};

const Template = (args) => <LogIn {...args} />;
export const Primary = Template.bind({});