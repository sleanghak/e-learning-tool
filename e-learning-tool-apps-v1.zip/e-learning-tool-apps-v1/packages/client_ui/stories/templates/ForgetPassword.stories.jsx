import ForgetPassword from '../../components/templates/ForgetPassword';

export default {
    title: 'templates/ForgetPassword',
    component: ForgetPassword,
};

const Template = (args) => <ForgetPassword {...args} />;
export const Primary = Template.bind({});