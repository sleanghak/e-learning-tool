import CertificateSetion from '../../../components/templates/Certificates/CertificateSetion';

export default {
    title: 'templates/Certificates/CertificateSetion',
    component: CertificateSetion,
};

const Template = (args) => <CertificateSetion {...args} />;
export const Primary = Template.bind({});