import FeedbackSetion from '../../../components/templates/classes/FeedbackSetion';

export default {
    title: 'templates/classes/FeedbackSetion',
    component: FeedbackSetion,
};

const Template = (args) => <FeedbackSetion {...args} />;
export const Primary = Template.bind({});