import ClassSetion from '../../../components/templates/classes/ClassSection';

export default {
    title: 'templates/classes/ClassSetion',
    component: ClassSetion,
};

const Template = (args) => <ClassSetion {...args} />;
export const Primary = Template.bind({}); 
