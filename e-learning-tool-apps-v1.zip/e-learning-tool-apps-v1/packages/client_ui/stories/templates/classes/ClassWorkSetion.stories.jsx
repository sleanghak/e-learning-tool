import ClassWorkSetion from '../../../components/templates/classes/ClassWorkSetion';

export default {
    title: 'templates/classes/ClassWorkSetionn',
    component: ClassWorkSetion,
};

const Template = (args) => <ClassWorkSetion {...args} />;
export const Primary = Template.bind({});