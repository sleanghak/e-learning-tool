import SignUp from '../../components/templates/SignUp';

export default {
    title: 'templates/SignUp',
    component: SignUp,
};

const Template = (args) => <SignUp {...args} />;
export const Primary = Template.bind({});