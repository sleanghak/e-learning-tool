import CourseSection from '../../../components/templates/courses/CourseSection';

export default {
    title: 'templates/courses/CourseSection',
    component: CourseSection,
};

const Template = (args) => <CourseSection {...args} />;
export const Primary = Template.bind({});