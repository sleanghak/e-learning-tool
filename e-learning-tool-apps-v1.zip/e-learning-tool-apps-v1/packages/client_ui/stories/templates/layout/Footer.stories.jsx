import Footer from '../../../components/templates/layout/Footer';

export default {
    title: 'templates/layout/Footer',
    component: Footer,
};

const Template = (args) => <Footer{...args} />;
export const Primary = Template.bind({});