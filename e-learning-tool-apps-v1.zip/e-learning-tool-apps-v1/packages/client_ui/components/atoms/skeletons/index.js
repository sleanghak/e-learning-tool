import SkeletonMadia from "./SkeletonMadia";
import SkeletonIcon from "./SkeletonIcon";
import SkeletonAvatar from './SkeletonAvatar';
import SkeletonText from './SkeletonText';
import SkeletonTitle from './SkeletonTitle';
export {
    SkeletonMadia,
    SkeletonIcon,
    SkeletonAvatar,
    SkeletonText,
    SkeletonTitle
}