import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Skeleton,
} from '@mui/material';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
   
}));

const SkeletonIcon = ({
    size
}) => {
    const classes = useStyles();
    return (
        <Skeleton variant='circular' animation='wave' width={size} height={size} />
    );
}

export default SkeletonIcon;

SkeletonIcon.propTypes = {
    size: PropTypes.number.isRequired,
};

SkeletonIcon.defaultProps = {
    size: 35,
};