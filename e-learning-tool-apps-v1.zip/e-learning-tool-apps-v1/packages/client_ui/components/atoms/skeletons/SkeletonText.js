import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Skeleton,
} from '@mui/material';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
}));

const SkeletonText = ({
    width,
}) => {
    const classes = useStyles();
    return (
        <Skeleton animation='wave' width={width} height={15} />
    );
}

export default SkeletonText;

SkeletonText.propTypes = {
    width: PropTypes.number.isRequired,
};

SkeletonText.defaultProps = {
    width: 200,
};