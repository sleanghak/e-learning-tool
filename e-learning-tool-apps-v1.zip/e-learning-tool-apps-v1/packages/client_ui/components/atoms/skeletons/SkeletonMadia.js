import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Skeleton,
} from '@mui/material';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
}));

const SkeletonMadia = ({
    width,
    height,
}) => {
    const classes = useStyles();
    return (
        <Skeleton variant='rectangular' animation='wave' width={width} height={height} sx={{borderRadius: 2}}/>
    );
}

export default SkeletonMadia;

SkeletonMadia.propTypes = {
    width: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
      ]),
    height: PropTypes.number.isRequired,
};

SkeletonMadia.defaultProps = {
    width: '100%',
    height: 200,
};