import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Skeleton,
} from '@mui/material';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({

}));

const SkeletonAvatar = ({
    
}) => {
    const classes = useStyles();
    return (
        <Skeleton variant='circular' animation='wave' width={50} height={50} />
    );
}

export default SkeletonAvatar;

SkeletonAvatar.propTypes = {

};

SkeletonAvatar.defaultProps = {

};