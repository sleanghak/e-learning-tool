import React from 'react';
import Image from 'next/image';
import { Box } from '@mui/material';

const EmptyItem = ({url}) => {
    return ( 
        <Box sx={{width:400, margin:'0px auto'}}>
            <Image  src={url} width={400} height={400} />
        </Box>
     );
}
 
export default EmptyItem;