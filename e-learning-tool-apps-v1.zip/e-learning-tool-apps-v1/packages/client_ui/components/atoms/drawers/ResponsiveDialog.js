import React from 'react';
import { Dialog, useMediaQuery, useTheme } from "@mui/material";
import Slide from '@mui/material/Slide';
const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
  });
const ResponsiveDialog = ({ children, open, onClose }) => {
  const theme = useTheme();
  const responsive = useMediaQuery(theme.breakpoints.down("sm"));
  return (
    <Dialog 
    open={open} 
    onClose={onClose} 
    fullScreen={responsive}
    transitionDuration={500}
    keepMounted
    TransitionComponent={Transition}
    
    >
      {children}
    </Dialog>
  );
};

export default ResponsiveDialog;
