import React from "react";
import PropTypes from "prop-types";
import {
  Paper,
  Avatar,
  InputBase,
  Box,
  TextField,
  Stack,
  IconButton,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import SendIcon from "@mui/icons-material/Send";

const CommentInput = ({ src, url }) => {
  const theme = useTheme();
  const small = useMediaQuery(theme.breakpoints.down('sm'));
  console.log(small);
  const [loading, setLoading] = React.useState(false);
  const handleComment = async (e) => {
    setLoading(true);
    e.preventDefault();
    const form = e.target.elements;
    try {
      await postDataFunc(url, {
        text: form.text.value,
      });
      e.target.reset();
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  return (
    <Box>
      <form onSubmit={handleComment}>
        <Paper sx={{ p: 2 }}>
          <Stack spacing={1} direction="row" alignItems={"center"}>
            <Avatar variant="primary" src={src} sx={{ mr: 1 }} />
            <TextField
              placeholder={ small ? 'Comment...' : "Announce something in your class ..." }
              name="text"
              multiline
              variant="standard"
              fullWidth
            />
            <IconButton disabled={loading} id="submit" type="submit">
              <SendIcon color="primary" />
            </IconButton>
          </Stack>
        </Paper>
      </form>
    </Box>
  );
};

export default CommentInput;

// CommentInput.propTypes = {
//   src: PropTypes.string.isRequired,
// };

// CommentInput.defaultProps = {
//   src: "/images/avatar7.png",
// };
