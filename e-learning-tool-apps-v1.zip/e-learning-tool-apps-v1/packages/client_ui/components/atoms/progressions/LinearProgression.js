import React from "react";

import LinearProgressWithLabel from "./LinearWithLabel";
import PropTypes from "prop-types";

export default function LinearProgression({ increase = 0, show = false }) {
  return <div>{show && <LinearProgressWithLabel value={increase} />}</div>;
}

LinearProgression.propTypes = {
  increase: PropTypes.number,
  show: PropTypes.bool.isRequired,
};

LinearProgression.defaultProps = {
  increase: 50,
  show: false,
};
