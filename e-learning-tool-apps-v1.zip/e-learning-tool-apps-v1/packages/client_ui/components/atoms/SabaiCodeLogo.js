import { Avatar } from "@mui/material";
import Link from "next/link";
const SabaiCodeLogo = ({ href }) => {
  return (
    <Link href={href}>
      <Avatar src="/images/sabaicode.jpg" sx={{ width: 80, height: 80 }} />
    </Link>
  );
};

export default SabaiCodeLogo;
