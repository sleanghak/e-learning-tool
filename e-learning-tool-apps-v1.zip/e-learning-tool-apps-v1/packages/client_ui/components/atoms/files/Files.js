import React from "react";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  root: {
    minWidth: 150,
    maxWidth: 200,
    height: 152,
    boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.25)",
    borderRadius: 5,
    margin: 10,
    cursor: "pointer",
  },
  txt: {
    textAlign: "center",
    display: "flex",
    marginLeft: 15,
    marginTop: 20,
    marginRight: 30,
  },
  image: {
    display: "block",
    width: 95,
    height: 95,
    marginLeft: "auto",
    marginRight: "auto",
  },
  icon: {
    width: 20,
    height: 20,
    marginRight: 15,
  },
  text: {
    display: "inline-block",
    width: 200,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    textAlign: "left",
    marginTop: 2,
  },
}));
const Files = ({ icon, children, onclick }) => {
  const classes = useStyles();
  return (
    <div className={classes.root} onClick={onclick}>
      <img className={classes.image} src={icon} />
      <div className={classes.txt}>
        <img className={classes.icon} src={icon} />
        <span className={classes.text}>{children}</span>
      </div>
    </div>
  );
};

export default Files;
