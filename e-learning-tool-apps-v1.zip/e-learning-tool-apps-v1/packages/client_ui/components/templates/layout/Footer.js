import React from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import { Grid, Box, Stack, Avatar } from "@mui/material";
import { Typography } from "@mui/material";
import Image from "next/image";

const useStyles = makeStyles((theme) => ({
  footer: {
    background: theme.palette.primary.main,
    padding: "5%",
    zIndex: 1,
    position: "absolute",
    width: "100%",
  },
  sabai_code_logo: {
    position: "absolute",
    top: 125,
    left: 50,
    height: 50,
    borderRadius: 25,
  },
  container: {
    position: "relative",
  },
  layout: {
    position: "absolute",
    bottom: 15,
    marginLeft: 24,
  },

  fb_p: {
    width: 25,
    height: 25,
    cursor: "pointer",
  },
  img_technology: {
    opacity: 0.7,
  },
  box: {
    display: "flex",
    alignItems: "center",
  },
  icon_img: {
    borderRadius: 5,
    cursor: "pointer",
  },
}));

const Footer = ({}) => {
  const classes = useStyles({});

  return (
    <>
      <Box className={classes.footer}>
        <Grid container spacing={7}>
          <Grid className={classes.container} item xs={12} sm={6} md={4} lg={4}>
            <Typography>Sabai Code Facebook Page</Typography>
            <br />
            <div>
              <Image
                width={250}
                height={175}
                className={classes.img_technology}
                src="/images/image_2022-02-18_06-53-44.png"
                alt="imgTechnology"
              />
              <Stack
                spacing={2}
                direction={"row"}
                className={classes.sabai_code_logo}
              >
                <Avatar
                  sx={{ width: 60, height: 60, ml: 3 }}
                  src="/images/sabaicode.jpg"
                  alt="logo_sabai_code"
                />

                <Stack>
                  <Typography className={classes.sabai_code}>
                    Sabai Code
                  </Typography>
                  <Typography>2.7K likes</Typography>
                </Stack>
              </Stack>
            </div>

            <div className={classes.layout}>
              <Box className={classes.box}>
                <Box sx={{ mr: 2 }}>
                  <Image
                    width={40}
                    height={40}
                    className={classes.fb_p}
                    src="/images/facebook_icon.png"
                    alt="facebook_img"
                  />
                </Box>

                <Box sx={{ mr: 2 }}>
                  <Typography>likes</Typography>
                </Box>
              </Box>
            </div>
          </Grid>

          <Grid item xs={12} sm={6} md={4} lg={4}>
            <Typography>About Us</Typography>
            <br />

            <Typography>
              We aspire to be the highest quality coding and robots school for
              children.
            </Typography>
            <br />

            <Typography>Follow Us</Typography>
            <br />
            <Box className={classes.box}>
              <Box sx={{ mr: 5 }}>
                <Image
                  width={40}
                  height={40}
                  className={classes.icon_img}
                  src="/images/facebook.png"
                  alt="facebook_img"
                />
              </Box>
              <Box sx={{ mr: 5 }}>
                <Image
                  width={40}
                  height={40}
                  className={classes.icon_img}
                  src="/images/youtube.png"
                  alt="youtube_img"
                />
              </Box>
              <Box sx={{ mr: 5 }}>
                <Image
                  width={40}
                  height={40}
                  className={classes.icon_img}
                  src="/images/linkedIn.png"
                  alt="linkedIn_img"
                />
              </Box>
            </Box>
          </Grid>

          <Grid item xs={12} sm={6} md={4} lg={4}>
            <Typography>Contact Us</Typography>
            <br />
            <Typography>Phone : 012-555-080</Typography>
            <br />
            <Typography>Email : sabaicode@gmail.com</Typography>
            <br />
            <Typography>
              Location : 28 saint 368, Phnom Penh, Cambodia
            </Typography>
          </Grid>
        </Grid>
      </Box>
    </>
  );
};
export default Footer;

Footer.propTypes = {
  // avatar: PropTypes.string.isRequired,
  // title: PropTypes.string,
  // date: PropTypes.string,
};

Footer.defaultProps = {
  // avatar: "https://ddi-dev.com/uploads/backend-is.png",
  // title: "Mr.Nak posted a new assigment : Homework",
  // date: "02 Feb 2022",
};
