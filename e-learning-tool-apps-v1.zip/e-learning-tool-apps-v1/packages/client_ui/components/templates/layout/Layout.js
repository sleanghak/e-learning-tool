import React from "react";
import UserAppBar from "./UserAppBar";
import UserDrawer from "./UserDrawer";
import { Paper, Box, useMediaQuery, useTheme, Fab } from "@mui/material";
import ResponsiveDialog from "../../atoms/drawers/ResponsiveDialog";
import { SearchBox } from "../../organisms/searchbox";
import { makeStyles } from "@mui/styles";
import ChatIcon from "@mui/icons-material/Chat";
import Footer from "./Footer";
import { useRouter } from "next/router";
import Navbar from "./Navbar";
const useStyles = makeStyles((theme) => ({
  root: {
    height: "70vh",
    [theme.breakpoints.down("sm")]: {
      height: "100vh",
    },
  },
}));
const Layout = ({ children, user, token, isLight, onChangeTheme }) => {
  const classes = useStyles();
  const theme = useTheme();
  const onMobile = useMediaQuery(theme.breakpoints.up("md"));
  const [open, setOpen] = React.useState(false);
  const [openDialog, setOpenDialog] = React.useState(false);
  const router = useRouter();

  return (
    <div>
      <>
        {/* <UserAppBar
          user={user}
          onMobile={onMobile}
          openDrawerFunc={() => setOpen(true)}
          openSearchFunc={() => setOpenDialog(true)}
          isLight={isLight}
          onChangeTheme={onChangeTheme}
        /> */}
        <Navbar
          user={user}
          onMobile={onMobile}
          openDrawerFunc={() => setOpen(true)}
        />
        <UserDrawer
          user={user}
          open={open}
          anchor="left"
          onCloseFunc={() => setOpen(false)}
          onOpenFunc={() => setOpen(true)}

        />
        <ResponsiveDialog
          open={openDialog}
          onClose={() => setOpenDialog(false)}
        >
          <Paper sx={{ p: 1 }} className={classes.root}>
            <SearchBox />
          </Paper>
        </ResponsiveDialog>
        <Box>{children}</Box>
      </>

      <Box sx={{ mb: 5 }} />
      {router.pathname !== "/messages" && <Footer />}
    </div>
  );
};

export default Layout;
