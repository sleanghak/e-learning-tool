import React from "react";
import Link from "next/link";
import {
  Box,
  CircularProgress,
  ListItemButton,
  SwipeableDrawer,
  Typography,
} from "@mui/material";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import { List, ListItemText, ListItemIcon } from "@mui/material";
import { Avatar, Divider } from "@mui/material";
import { navItems, noUserItems } from "../../../utils/constant/navItems";
import { useRouter } from "next/router";
import { convertFilePathToURL } from "./../../../utils/func/s3";
import { logoutUser } from "../../../utils/func/auth/authUser";
import ListItemCollapse from "../../molecules/menus/ListItemCollapse";
import LogoutRoundedIcon from "@mui/icons-material/LogoutRounded";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";

const useStyles = makeStyles((theme) => ({
  root: {
    minWidth: 250,
    maxWidth: 300,
  },
  logo: {
    marginTop: 16,
    width: 80,
    height: 80,
    margin: "0px auto",
    marginBottom: 16,
  },
  profile: {
    marginBottom: 16,
  },
  active: {
    borderLeft: `3px solid ${theme.palette.primary.main}`,
    borderRight: `3px solid ${theme.palette.primary.main}`,
    borderTopLeftRadius: 5,
    borderBottomLeftRadius: 5,
    borderTopRightRadius: 5,
    borderBottomRightRadius: 5,
  },
}));
const UserDrawer = ({
  open,
  handleClose,
  anchor,
  onCloseFunc,
  onOpenFunc,
  user,
}) => {
  const classes = useStyles();
  const router = useRouter();
  const role = user?.data?.role || null;
  const navs = role == "user" ? navItems : noUserItems;
  const [submenu, setSubmenu] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [currentUser, setCurrentUser] = React.useState(null);
  const handleClickSublist = () => {
    setSubmenu(!submenu);
  };
  React.useEffect(() => {
    if (user) {
      convertFilePathToURL(user.data).then((data) => {
        setCurrentUser(data);
      });
    }
  }, []);
  return (
    <div>
      <SwipeableDrawer
        anchor={anchor}
        open={open}
        onClose={onCloseFunc}
        onOpen={onOpenFunc}
      >
        <div className={classes.root}>
          <div className={classes.profile}>
            <Avatar
              className={classes.logo}
              alt="Remy Sharp"
              src={
                currentUser
                  ? currentUser.coverFileName
                  : "/images/sabaicode.jpg"
              }
            />
            <Typography sx={{ display: "block" }} align="center" variant="body">
              {currentUser ? currentUser.name : "SabaiCode"}
            </Typography>
            <Typography sx={{ display: "block" }} align="center" variant="body">
              {currentUser ? currentUser.email : "info@sabaicode.com"}
            </Typography>
          </div>
          <Divider />
          <div className={classes.container}>
            <List>
              {navs.map((item, index) => {
                return (
                  <Box key={index}>
                    {" "}
                    {item.sublist ? (
                      <ListItemCollapse title={item.label} icon={item.icon}>
                        {item.sublist.map((item, index) => {
                          return (
                            <Link href={item.path} key={index}>
                              <ListItemButton
                                sx={{ p: "16px 0 16px 40px" }}
                                onClick={onCloseFunc}
                              >
                                {item.label}
                              </ListItemButton>
                            </Link>
                          );
                        })}
                      </ListItemCollapse>
                    ) : (
                      <Link href={item.path}>
                        <ListItemButton onClick={onCloseFunc}>
                          <ListItemIcon>{item.icon}</ListItemIcon>
                          <ListItemText primary={item.label} />
                        </ListItemButton>
                      </Link>
                    )}
                  </Box>
                );
              })}
              <Box>
                {role == "user" ? (
                  <ListItemButton onClick={logoutUser}>
                    <ListItemIcon>
                      {loading ? (
                        <CircularProgress size={25} />
                      ) : (
                        <LogoutRoundedIcon />
                      )}
                    </ListItemIcon>
                    <ListItemText primary="Sign Out" />
                  </ListItemButton>
                ) : (
                  <Link href={"/auth/signin"}>
                    <ListItemButton>
                      <ListItemIcon>
                        <ExitToAppIcon />
                      </ListItemIcon>
                      <ListItemText primary="Login" />
                    </ListItemButton>
                  </Link>
                )}
              </Box>
            </List>
          </div>
        </div>
      </SwipeableDrawer>
    </div>
  );
};

export default UserDrawer;

UserDrawer.defaultProps = {
  open: true,
  anchor: "left",
  onCloseFunc: undefined,
  onOpenFunc: undefined,
};

UserDrawer.propTypes = {
  open: PropTypes.bool.isRequired,
  anchor: PropTypes.oneOf(["left", "right", "top", "bottom"]),
  onCloseFunc: PropTypes.func.isRequired,
  onOpenFunc: PropTypes.func,
};
