import {
  AppBar,
  IconButton,
  Toolbar,
  Badge,
  Box,
  Button,
  ButtonBase,
} from "@mui/material";
import { Avatar } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { AccountMenu } from "../../molecules/menus";
import { HorizontalTabs } from "../../molecules/tabs";
import { navItems, noUserItems } from "../../../utils/constant/navItems";
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
import MailIcon from "@mui/icons-material/Mail";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";
import SabaiCodeLogo from "../../atoms/SabaiCodeLogo";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import ChatIcon from "@mui/icons-material/Chat";
import { useRouter } from "next/router";
import CircleNotificationsIcon from "@mui/icons-material/CircleNotifications";
const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
},
appBar: {
    width: '100%',
    background: '#FFFFFF',
    boxShadow: '0px 0px 4px rgba(0, 0, 0, 0.25)',
},
container: {
    width: '100%',
    height: 135,
},
line: {
    width: '100%',
    height: 10,
    background: '#5DE2E7'
},
toolbar: {
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    height: 125,
    padding: '0 40px'
},
menuIcon: {
    color: '#999999',
},
logo: {
    display: 'flex',
    alignItems: 'center',
},
page: {
    display: 'flex',
    flexGrow: 1,
},
}));
const UserAppBar = ({
  onMobile,
  openDrawerFunc,
  openSearchFunc,
  user,
  isLight = true,
  onChangeTheme,
}) => {
  const classes = useStyles();
  const router = useRouter();
  // console.log(user?.data?.role);
  const role = user?.data?.role;
  return (
    <AppBar
      color="white"
      position="static"
      elevation={0}
      sx={{ boxShadow: "0px -1px 8px rgba(0, 0, 0, 0.25)" }}
    >
      <Toolbar className={classes.root}>
        {onMobile ? (
          <SabaiCodeLogo href="/" />
        ) : (
          <IconButton onClick={openDrawerFunc}>
            <MenuIcon />
          </IconButton>
        )}

        <div className={classes.menus}>
          {onMobile && (
            <HorizontalTabs
              data={role == "user" ? navItems : noUserItems}
              isDynamic={false}
            />
          )}
          {/* <IconButton onClick={openSearchFunc} color="primary">
            <SearchIcon />
          </IconButton> */}
          {role == "user" && (
            <>
              <Box>
                <ButtonBase onClick={() => router.push("/favorite")}>
                  <Badge
                    sx={{ mr: 2 }}
                    badgeContent={user?.data?.courses?.length}
                    color="secondary"
                  >
                    <FavoriteBorderIcon />
                  </Badge>
                </ButtonBase>
              </Box>
              <Box>
                <Badge badgeContent={4} color="secondary">
                  <CircleNotificationsIcon color="action" />
                </Badge>
              </Box>
              <Box>
                <ButtonBase onClick={() => router.push("/messages")}>
                  <Badge sx={{ ml: 1 }} badgeContent={2} color="secondary">
                    <ChatIcon color="action" />
                  </Badge>
                </ButtonBase>
              </Box>
              {/* <Box>
                <IconButton onClick={onChangeTheme}>
                  {isLight ? <Brightness4Icon /> : <Brightness7Icon />}
                </IconButton>
              </Box> */}
            </>
          )}
          <div>
            {role == "user" ? (
              <AccountMenu user={user} />
            ) : (
              <Button size="small" variant="outlined" href="/auth/signin">
                Login
              </Button>
            )}
          </div>
        </div>
      </Toolbar>
    </AppBar>
  );
};

export default UserAppBar;
