import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Box, Divider, Grid, Stack, Typography, Button
} from '@mui/material';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        height: 530,
        backgroundPosition: 'left center',
        backgroundSize: 'cover',
        display: 'flex',
    },
    grid_left: {
        height: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    content_box: {
        display: 'flex',
        maxWidth: '400px',
        padding: '0 25px',
        justifyContent: 'center',
        alignItems: 'center'
    },
    button: {
        display: "flex",
        justifyContent: "space-between",
        flexWrap: "wrap",
    },
    button_item: {
        marginBottom: 10,
    },
}));

const HeaderTitle = ({

}) => {
    const classes = useStyles();
    return (
        <Box
            className={classes.root}
            sx={{ backgroundImage: `url('./images/header_bg.png')` }}
        >
            <Grid container>
                <Grid item xs={12} sm={12} md={6}>
                    <Box className={classes.grid_left} >
                        <Box
                            className={classes.content_box}
                        >
                            <Stack
                                spacing='25px'
                                direction='column'
                            >
                                <Box>
                                    <Typography variant='logo'>
                                        SabaiCode
                                    </Typography>
                                </Box>
                                <Divider sx={{ width: '150px', height: '4px', background: '#605D66', borderRadius: '2px' }} />
                                <Box>
                                    <Typography variant='primary'>
                                        Coding and STEM for the Youngters.
                                        We aspire to be the highest quality coding and robots school for children.
                                    </Typography>
                                </Box>
                                <Box className={classes.button}>
                                    <Button variant="contained" className={classes.button_item}>
                                        Get Start
                                    </Button>
                                    <Button variant="outlined" className={classes.button_item}>
                                        Learn more
                                    </Button>
                                </Box>
                            </Stack>
                        </Box>
                    </Box>

                </Grid>
                <Grid item xs={0} sm={0} md={6} sx={{ height: { xs: '0', md: '100%' } }}>
                    <Box sx={{ height: '100%', display: { xs: 'none', md: 'flex', justifyContent: 'center', alignItems: 'center' } }}>
                        <img
                            src='./images/header_image.png'
                            style={{ maxWidth: '543px', width: '100%', maxHeight: '500px', height: 'auto' }}
                        />
                    </Box>
                </Grid>
            </Grid>
        </Box>
    );
}

export default HeaderTitle;

HeaderTitle.propTypes = {

};

HeaderTitle.defaultProps = {

};