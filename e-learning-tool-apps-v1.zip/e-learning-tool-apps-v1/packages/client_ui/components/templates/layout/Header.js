import Head from "next/head";
import { app_name } from "../../../utils/constant/app";
const Header = () => {
  return (
    <Head>
      <meta
        name="viewport"
        content="minimum-scale=1, initial-scale=1, width=device-width"
      />
      <link
        rel="shortcut icon"
        href="/images/sabaicode.jpg"
        type="image/x-icon"
      />
     <link
        rel="stylesheet"
        href="https://video-react.github.io/assets/video-react.css"
      />
      <title>{app_name}</title>
    </Head>
  );
};

export default Header;
