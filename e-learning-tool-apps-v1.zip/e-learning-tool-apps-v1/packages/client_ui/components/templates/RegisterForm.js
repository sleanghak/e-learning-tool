import React, { useState } from "react";
import PropTypes from "prop-types";
import {
    Box,
    Button,
    FormControl,
    FormControlLabel,
    FormLabel,
    Grid,
    Input,
    MenuItem,
    Radio,
    RadioGroup,
    Select,
    Stack,
    Typography,

} from "@mui/material";
import { makeStyles } from '@mui/styles';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';

//components
import CardFormHeader from "../molecules/cards/CardFormHeader";
import CardFormInput from "../molecules/cards/CardFormInput";

//icons
import CloudUploadRoundedIcon from '@mui/icons-material/CloudUploadRounded';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        display: 'flex',
        justifyContent: 'center'
    },
    container: {
        maxWidth: '1200px',
        width: '100%',
    },
    texField: {
        "& .MuiFormLabel-root": {
            fontSize: 16,
            color: 'black',
        },
        "& .MuiFormLabel-asterisk": {
            color: '#F81818',
            '&$error': {
                color: '#F81818'
            },
        },
    },
    button_upload: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        cursor: 'pointer',
        '&:hover': {
            background: '#FCFCFC',
        }
    },
    button_box: {
        display: 'flex',
        flexDirection: 'row',
        width: '100%',
    }
}));

const RegisterForm = ({ }) => {

    const classes = useStyles();
    const [filePre, setFilePre] = useState(null);
    const [value, setValue] = React.useState(new Date());
    const [values, setValues] = useState({
        job: '',
    });
    const handleChange = (prop) => (e) => {
        setValues({ ...values, [prop]: e.target.value });
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        const form = e.target.elements;
        {
            if (filePre == null) {
                alert('Please Upload File first!')
            } else {
                const fname = form.fname.value;
                const lname = form.lname.value;
                const job = form.job.value;
                const where = form.where.value;
                const major = form.major.value;
                const email = form.email.value;
                const phoneNumber = form.phoneNumber.value;
                const birthDate = form.birthDate.value;
                const address = form.address.value;
                const gender = form.gender.value;
                const apply = form.apply.value;
                const extracurricular = form.extracurricular.value;
                const essay = form.essay.value;
                const file = filePre;
                console.log(
                    fname, lname, job, where, major, email, phoneNumber, birthDate, address, gender, apply, extracurricular, essay, file
                );
            }
        }
    };
    return (
        <Box className={classes.root}>
            <Box className={classes.container}>
                <Box>
                    <form onSubmit={handleSubmit}>
                        <Grid container spacing={2}>
                            <Grid item sx={12} sm={12} md={12}>
                                <CardFormHeader />
                            </Grid>
                            {/* first name */}
                            <Grid item xs={12} sm={6} md={6}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            First Name
                                        </FormLabel>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            name='fname'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* last name */}
                            <Grid item xs={12} sm={6} md={6}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Last Name
                                        </FormLabel>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            name='lname'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* current job */}
                            <Grid item xs={12} sm={6} md={6}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        select
                                        className={classes.texField}
                                        onChange={handleChange('job')}
                                        value={values.job}
                                    >
                                        <FormLabel>
                                            Current Job
                                        </FormLabel>
                                        <Select name='job'>
                                            <MenuItem value='student'>Student</MenuItem>
                                            <MenuItem value='employee'>Employee</MenuItem>
                                        </Select>
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* where */}
                            <Grid item xs={12} sm={6} md={6}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Where
                                        </FormLabel>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            name='where'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* major */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Major
                                        </FormLabel>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            name='major'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* email */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Email
                                        </FormLabel>
                                        <Input
                                            type='email'
                                            placeholder='Your answer'
                                            name='email'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* phone number */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Phone Number
                                        </FormLabel>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            name='phoneNumber'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* date of birth */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Date of Birth
                                        </FormLabel>
                                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                                            <DatePicker
                                                value={value}
                                                onChange={(newValue) => {
                                                    setValue(newValue);
                                                }}
                                                renderInput={({ inputRef, inputProps, InputProps }) => (
                                                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                        <Input
                                                            sx={{ width: '100%' }}
                                                            placeholder='Your answer'
                                                            name='birthDate'
                                                            ref={inputRef} {...inputProps}
                                                        />
                                                        {InputProps?.endAdornment}
                                                    </Box>
                                                )}
                                            />
                                        </LocalizationProvider>
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* Current Address */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Current Address
                                        </FormLabel>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            name='address'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* gender */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Gender
                                        </FormLabel>
                                        <br />
                                        <RadioGroup name='gender' required>
                                            <FormControlLabel value='female' control={<Radio required size='small' color='secondary' />} label='Female' />
                                            <FormControlLabel value='male' control={<Radio required size='small' color='secondary' />} label='Male' />
                                        </RadioGroup>
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* why do you apply */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Why do you apply?
                                        </FormLabel>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            name='apply'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* Describe your extracurricular activiies (activities outside of school ) or work experience */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Describe your extracurricular activiies (activities outside of school ) or work experience
                                        </FormLabel>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            multiline
                                            name='extracurricular'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* Write an essay */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        required
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Write an essay.You may choose your own topic or select from ONE of the following topics. You can write in either English or Khmer.No more than 500 word
                                        </FormLabel>
                                        <Typography>
                                            <ul style={{ padding: '0 0 0 20px' }}>
                                                <li>
                                                    Describe your most meaningful experience
                                                </li>
                                                <li>
                                                    Describe unusual circumstances in your life
                                                </li>
                                                <li>
                                                    Describe your hero
                                                </li>
                                                <li>
                                                    Describe your life goals
                                                </li>
                                                <li>
                                                    Describe something special about you
                                                </li>
                                            </ul>
                                        </Typography>
                                        <Input
                                            type='text'
                                            placeholder='Your answer'
                                            multiline
                                            name='essay'
                                        />
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* upload */}
                            <Grid item xs={12} sm={12} md={12}>
                                <CardFormInput>
                                    <FormControl
                                        variant='standard'
                                        fullWidth
                                        className={classes.texField}
                                    >
                                        <FormLabel>
                                            Submit a CV
                                        </FormLabel>
                                        <Stack
                                            sx={{
                                                mt: 2,
                                                display: 'flex',
                                                flexDirection: { xs: 'column', sm: 'row' },
                                                alignItems: { xs: 'start', sm: 'end' },
                                            }}
                                        >
                                            <Box order={{ xs: 3, sm: 1 }}>
                                                {
                                                    filePre && <Typography>
                                                        {filePre.name}
                                                    </Typography>
                                                }
                                            </Box>
                                            <Box flex={1} order={2} />
                                            <Box order={{ xs: 1, sm: 3 }}>
                                                <input
                                                    accept='image/*, .pdf, .docx'
                                                    id='icon-button-file'
                                                    type='file'
                                                    style={{ display: 'none' }}
                                                    onChange={(e) => { setFilePre(e.target.files[0]) }}
                                                />
                                                <label htmlFor='icon-button-file'>
                                                    <Box className={classes.button_upload}
                                                        sx={{
                                                            mb: { xs: 2, sm: 0 },
                                                            p: { xs: 0, sm: '10px 40px' },
                                                            borderRadius: { xs: 0, sm: '8px' },
                                                            border: { xs: 'none', sm: '2px solid #5DE2E7' },
                                                            '&:hover': {
                                                                boxShadow: { xs: 'none', sm: '0px 0px 4px #5DE2E7' },
                                                            }
                                                        }}
                                                    >
                                                        <CloudUploadRoundedIcon sx={{ color: '#5DE2E7', fontSize: '30px' }} />
                                                        <Typography sx={{ color: '#5DE2E7', fontSize: '18px', display: { xs: 'none', sm: 'block' } }}>
                                                            upload
                                                        </Typography>
                                                    </Box>
                                                </label>
                                            </Box>
                                        </Stack>
                                    </FormControl>
                                </CardFormInput>
                            </Grid>
                            {/* Button */}
                            <Grid item xs={12} sm={12} md={12} sx={{ display: 'flex', justifyContent: 'center' }}>
                                <Box className={classes.button_box}>
                                    <Box flex={1} />
                                    <Button
                                        variant='outlined'
                                        type='reset'
                                        sx={{ borderRadius: '8px', mr: '8px' }}
                                    >
                                        Clear form
                                    </Button>
                                    <Button
                                        variant='contained'
                                        type='submit'
                                        sx={{ borderRadius: '8px' }}
                                    >
                                        Submit
                                    </Button>
                                </Box>
                            </Grid>
                        </Grid>
                    </form>
                </Box>
            </Box>
        </Box>
    );
};

export default RegisterForm;

RegisterForm.propTypes = {
};

RegisterForm.defaultProps = {
};
