import React from "react";
import { makeStyles } from "@mui/styles";
import { styled } from "@mui/material/styles";
import Image from "next/image";
import { MenuItem, InputLabel, FormControl, Select } from "@mui/material";
import { Stack, Box, Grid } from "@mui/material";
import { Button, IconButton, TextField, Typography } from "@mui/material";
import CardActions from "@mui/material/CardActions";
import Collapse from "@mui/material/Collapse";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const useStyles = makeStyles((theme) => ({
  container: {
    position: "relative",
  },
  div: {
    position: "absolute",
    right: "25%",
    width: "100vh",
    border: " 1px solid #C4C4C4",
    transform: "rotate(90deg)",
    [theme.breakpoints.down("md")]: {
      display: "none",
    },
  },
  assign: {
    position: "absolute",
    left: "50%",
    padding: 5,
    width: 180,
    background: " #5DE2E7",
    "&:hover ": {
      background: " #5DE2E7",
    },
  },
  icons: {
    position: "absolute",
    bottom: 0,
  },
  expand_more: {
    position: "absolute",
    bottom: 0,
    left: "80%",
  },
}));

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
  marginLeft: "auto",
  transition: theme.transitions.create("transform", {
    duration: theme.transitions.duration.shortest,
  }),
}));

export default function ClassworksAssignment() {
  const classes = useStyles();
  const [student, setStudent] = React.useState("");
  const [expanded, setExpanded] = React.useState(false);
  const handleChange = (event) => {
    setStudent(event.target.value);
  };
  const handleExpandClick = () => {
    setExpanded(!expanded);
  };
  return (
    <Grid container justifyContent={"center"} spacing={4}>
      <Grid item xs={10} sm={6}>
        <Typography variant="title">Assignment</Typography>
        <br />
        <br />
        <Box>
          <TextField
            label="Title"
            fullWidth
            required
            name="title"
            type="text"
            variant="standard"
          />
           <InputLabel>Due</InputLabel>
          <FormControl variant="standard" fullWidth required>
            <Select value={student} onChange={handleChange}>
              <MenuItem value={0}>No due date</MenuItem>
            </Select>
          </FormControl>
        </Box>
        <br />

        <Box>
          <TextField
            label="Instructions"
            multiline
            fullWidth
            required
            name="instructions"
            type="text"
            rows={8}
            variant="standard"
          />
        </Box>

        {/* ------------------------------------------------------------- */}
        {/* icon style font */}
        <Box className={classes.container}>
          <Stack
            className={classes.icons}
            direction={"row"}
            spacing={2}
            alignItems="center"
          >
            <IconButton>
              <Image
                width={15}
                height={15}
                src="/images/bold.png"
                alt="bold_img"
              />
            </IconButton>
            <IconButton>
              <Image
                width={15}
                height={15}
                src="/images/bold.png"
                alt="bold_img"
              />
            </IconButton>
            <IconButton>
              <Image
                width={15}
                height={15}
                src="/images/underline.png"
                alt="underline_img"
              />
            </IconButton>
            <IconButton>
              <Image
                width={15}
                height={15}
                src="/images/bullet.png"
                alt="bullet_img"
              />
            </IconButton>
            <IconButton>
              <Image
                width={15}
                height={15}
                src="/images/clear.png"
                alt="clear_img"
              />
            </IconButton>
          </Stack>

          {/* --------------------------------------------------------------- */}
          <Box className={classes.expand_more} sx={{ width: 100 }}>
            <CardActions disableSpacing>
              <ExpandMore
                expand={expanded}
                onClick={handleExpandClick}
                aria-expanded={expanded}
              >
                <ExpandMoreIcon />
              </ExpandMore>
            </CardActions>
            <Collapse in={expanded} timeout="auto" unmountOnExit>
              <Stack direction={"row"} spacing={2} alignItems="center">
                <IconButton>
                  <Image
                    width={15}
                    height={15}
                    src="/images/google_drive.png"
                    alt="google_drive_img"
                  />
                </IconButton>
                <IconButton>
                  <Image
                    width={15}
                    height={15}
                    src="/images/upload.png"
                    alt="upload_img"
                  />
                </IconButton>
                <IconButton>
                  <Image
                    width={15}
                    height={15}
                    src="/images/add-link.png"
                    alt="add-link_img"
                  />
                </IconButton>
              </Stack>
            </Collapse>
          </Box>
        </Box>
      </Grid>

      {/* -------------------------------------------------------------------- */}

      <Grid item xs={10} sm={4}>
        <Box className={classes.container}>
          <div className={classes.div} />
        </Box>

        <Box>
          <InputLabel>For</InputLabel>
          <FormControl variant="standard" fullWidth required>
            <Select value={student} onChange={handleChange}>
              <MenuItem value={0}>All Student</MenuItem>
              <MenuItem value={1}>Student1</MenuItem>
              <MenuItem value={2}>Student2</MenuItem>
            </Select>
          </FormControl>
        </Box>
        <br />
        <Box>
          <InputLabel>Points</InputLabel>
          <FormControl variant="standard" fullWidth required>
            <Select value={student} onChange={handleChange}>
              <MenuItem value={0}>100</MenuItem>
              <MenuItem value={1}>80</MenuItem>
              <MenuItem value={2}>70</MenuItem>
            </Select>
          </FormControl>
        </Box>
        <br />
        <Box>
         
        </Box>
        <br />
        <Box>
          <InputLabel>Topic</InputLabel>
          <FormControl variant="standard" fullWidth required>
            <Select value={student} onChange={handleChange}>
              <MenuItem value={0}>No topic</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Grid>

      {/* -------------------------------------------------------------------- */}
      {/*Button Assign */}
      <Grid item xs={10} className={classes.container}>
        <br />
        <br />
        <Button className={classes.assign}>Assign</Button>
      </Grid>
    </Grid>
  );
}
