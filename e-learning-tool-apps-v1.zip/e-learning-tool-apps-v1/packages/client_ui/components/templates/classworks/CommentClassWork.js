import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import { Box, Typography, TextField, MenuItem } from "@mui/material";
import PeopleRoundedIcon from "@mui/icons-material/PeopleRounded";
import CommentInput from "../../atoms/inputs/CommentInput";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    marginTop: 80,
  },
  head: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    marginRight: 20,
    flexWrap: "wrap",
  },
  to_section: {
    display: "flex",
    alignItems: "center",
    marginTop: 20,
  },
  input_fieldset: {
    width: 150,
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        borderColor: "#7D7878",
        borderRadius: 5,
      },
    },
  },
  input_text: {
    fontSize: 15,
  },
  comment_box: {
    marginTop: 25,
  },
}));

const CommentClassWork = ({ classworkId }) => {
  const classes = useStyles();
  return (
    <Box className={classes.root}>
      <Box className={classes.head}>
        <PeopleRoundedIcon
          sx={{ mr: { xs: "10px", sm: "20px", md: "40px" }, mt: "20px" }}
        />
        <Typography
          sx={{ fontSize: 15, fontWeight: 700, minWidth: 120, mt: "20px" }}
        >
          Class Comments
        </Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Box className={classes.to_section}>
          <Typography sx={{ width: 50 }}>To :</Typography>
          <TextField
            size="small"
            fullWidth
            select
            required
            InputProps={{
              classes: {
                root: classes.input_text,
              },
            }}
            name="rate"
            defaultValue={0}
            className={classes.input_fieldset}
          >
            <MenuItem value={0}>Everyone</MenuItem>
            <MenuItem value={1}>student 1</MenuItem>
            <MenuItem value={2}>student 2</MenuItem>
            <MenuItem value={3}>student 3</MenuItem>
            <MenuItem value={4}>student 4</MenuItem>
          </TextField>
        </Box>
      </Box>
      <Box className={classes.comment_box}>
        <CommentInput
          url={`${process.env.NEXT_PUBLIC_API_URL}/api/v1/student/classwork/comment/${classworkId}`}
        />
      </Box>
    </Box>
  );
};

export default CommentClassWork;

CommentClassWork.propTypes = {};

CommentClassWork.defaultProps = {};
