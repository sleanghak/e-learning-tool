import React from "react";
import PropTypes from "prop-types";
import CertificateCard from "../../organisms/cards/CertificateCard";
import { Grid, Box, Typography } from "@mui/material";

const CertifateSection = ({ title, data }) => {
  return (
    <div>
      <Box>
        <Box sx={{mb:4,mt:4}}>
          <Typography variant="title">{title}</Typography>
          <Box sx={{ flexGrow: 1 }} />
        </Box>
      </Box>
      <Grid
        container
        justifyContent={data?.length >= 3 ? "center" : "left"}
        spacing={2}
      >
        {data.map((data, index) => (
          <Grid
            item
            xs={12}
            sm={6}
            md={4}
            key={index}
          >
            <CertificateCard
              cover={data.cover}
              title={data.title}
              certificateImage={data.certificateImage}
              certificateLink={data.certificateLink}
            />
          </Grid>
        ))}
      </Grid>
    </div>
  );
};

export default CertifateSection;

CertifateSection.propTypes = {
  title: PropTypes.string.isRequired,
  data: PropTypes.array.isRequired,
};

CertifateSection.defaultProps = {
  title: "Certificates of Courses",
};
