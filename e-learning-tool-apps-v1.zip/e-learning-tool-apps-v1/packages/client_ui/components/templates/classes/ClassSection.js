import React, { useState } from "react";
import PropTypes from "prop-types";
import ClassCard from "../../organisms/cards/ClassCard";
import ClassTitle from "../../molecules/headers/ClassTitle";
import { Grid, Box, Dialog, Stack } from "@mui/material";
import { JoinClassForm } from "../../organisms/forms";
import { useRouter } from "next/router";
import EmptyItem from "../../atoms/EmptyItem";

const ClassSection = ({ title, data, loading }) => {
  const router = useRouter();
  const [open, setOpen] = React.useState(false);
  return (
    <Stack spacing={5}>
      <ClassTitle title={title} onOpenFunc={() => setOpen(true)} />
      <Box>
        <Grid container spacing={1}>
          {data.length === 0 ? (
            <EmptyItem url="/images/classes.svg" />
          ) : (
            data.map((data, index) => (
              <Grid
                item
                xs={12}
                sm={6}
                md={4}
                key={index}
                sx={{ display: "flex", justifyContent: "center" }}
              >
                <ClassCard
                  cover={data.coverFileName}
                  profile={data.profile}
                  name={data.name}
                  title={data.title}
                  time={data.time}
                  isCoach={true}
                  loading={loading}
                  code={data.code}
                  href={`classes/stream/${data._id}`}
                  onUnrollFunc={() => console.log("Unroll")}
                  onOpenClassFunc={() =>
                    router.push(`classes/stream/${data._id}`)
                  }
                />
              </Grid>
            ))
          )}
        </Grid>
      </Box>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <JoinClassForm onClose={() => setOpen(false)} />
      </Dialog>
    </Stack>
  );
};

export default ClassSection;

ClassSection.propTypes = {
  title: PropTypes.string.isRequired,
  data: PropTypes.array.isRequired,
};

ClassSection.defaultProps = {};
