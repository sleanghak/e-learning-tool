import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Box,
  Grid,
  TextField,
  Typography,
  MenuItem,
  Button,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import FeedbackCard from "../../organisms/cards/FeedbackCard";
import postDataFunc from "./../../../utils/func/api/postDataFunc";
import { convertFilePathToURL } from "../../../utils/func/s3";
import { extractObjInArray } from "../../../utils/func/objects";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  input_box: {
    margin: "20px 0",
  },
  input_fieldset: {
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        borderColor: "#7D7878",
        borderRadius: 0,
      },
    },
  },
  input_text: {
    fontWeight: 700,
    color: "#7D7878",
  },
  button_box: {
    marginTop: 50,
  },
  button: {
    borderRadius: 25,
    border: "1px solid #5DE2E7",
  },
}));

const FeedbackSetion = ({ data, loading, user, url, isReview = false }) => {
  const classes = useStyles();
  const [reviewers, setReviewers] = React.useState([]);

  const handleReview = async (e) => {
    e.preventDefault();
    const form = e.target.elements;
    try {
      await postDataFunc(url, {
        text: form.text.value,
        rate: form.rate.value,
      });
      e.target.reset();
    } catch (error) {
      console.log(error);
    }
  };

  React.useEffect(() => {
    if (data?.length > 0) {
      convertFilePathToURL(extractObjInArray(data)).then((reviews) => {
        setReviewers(reviews);
      });
    }
  }, [data]);
  return (
    <Box className={classes.root}>
      <Box>
        {!isReview && <Typography variant="title">Student Feedback</Typography>}
      </Box>
      <Box className={classes.input_box}>
        {user && (
          <form onSubmit={handleReview}>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={12} md={8} lg={8}>
                <TextField
                  size="small"
                  fullWidth
                  required
                  placeholder="Reviews..."
                  InputProps={{
                    classes: {
                      root: classes.input_text,
                    },
                  }}
                  name="text"
                  className={classes.input_fieldset}
                />
              </Grid>
              <Grid item xs={12} sm={12} md={4} lg={4}>
                <TextField
                  size="small"
                  fullWidth
                  select
                  required
                  InputProps={{
                    classes: {
                      root: classes.input_text,
                    },
                  }}
                  name="rate"
                  className={classes.input_fieldset}
                >
                  <MenuItem value={5}>Five Star</MenuItem>
                  <MenuItem value={4}>Four Star</MenuItem>
                  <MenuItem value={3}>Three Star</MenuItem>
                  <MenuItem value={2}>Two Star</MenuItem>
                  <MenuItem value={1}>One Star</MenuItem>
                </TextField>
              </Grid>
            </Grid>
            <button type="submit" hidden>
              Submit
            </button>
          </form>
        )}
      </Box>
      <Box>
        {reviewers.map((item, index) => {
          return (
            <Box key={index} sx={{ mb: 3 }}>
              <FeedbackCard
                profile={item.coverFileName}
                name={item.name}
                rate={item.rate}
                date={item.date}
                feedback={item.text}
                loading={loading}
              />
            </Box>
          );
        })}
      </Box>
      {user && (
        <Box className={classes.button_box}>
          <Button variant="outlined" fullWidth className={classes.button}>
            Show More Comment
          </Button>
        </Box>
      )}
    </Box>
  );
};

export default FeedbackSetion;

FeedbackSetion.propTypes = {
  data: PropTypes.array.isRequired,
  loading: PropTypes.bool.isRequired,
};

FeedbackSetion.defaultProps = {
  loading: false,
};
