import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Box,
    Button,
} from '@mui/material';
import { makeStyles } from '@mui/styles';
import AssignmentIndRoundedIcon from '@mui/icons-material/AssignmentIndRounded';
import AddToDriveRoundedIcon from '@mui/icons-material/AddToDriveRounded';
import ClassWorkCard from '../../molecules/cards/ClassWorkCard';

const useStyles = makeStyles((theme) => ({
    header_box: {
        width: '100%',
        display: 'flex',
        alignItems: 'center',
    },
    view_work: {
        fontSize: 15,
        color: '#5DE2E7',
    },
    drive_folder: {
        fontSize: 15,
    },
    content: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: 20,
        padding: '0px 20px'
    }


}));

const Template = ({
    data,
}) => {
    const classes = useStyles();
    return (
        <div>
            <Box
                className={classes.header_box}
            >
                <Box>
                    <Button
                        className={classes.view_work}  
                        variant='text' 
                        startIcon={<AssignmentIndRoundedIcon sx={{ fontSize: 25 }} />}
                    >
                        View your work
                    </Button>
                </Box>
                <Box sx={{ flexGrow: 1 }} />
                <Box>
                    <Button
                        className={classes.drive_folder}
                        variant='contained'
                        startIcon={<AddToDriveRoundedIcon style={{ fontSize: 25 }} />}
                    >
                        Class drive folder
                    </Button>
                </Box>
            </Box>
            <Box
                    className={classes.content}
                >
                {data.map((item, index) => (
                    <ClassWorkCard
                        key={index}
                        title={item.title}
                        date={item.date}
                    />
                ))}
                </Box>
        </div>
    );
}

export default Template;

Template.propTypes = {
    data: PropTypes.array.isRequired,
};

Template.defaultProps = {

};