import React from "react";
import makeStyles from "@mui/styles/makeStyles";
import PropTypes from "prop-types";
import { Button, IconButton, TextField, Grid, Typography } from "@mui/material";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogContentText,
} from "@mui/material";
import Slide from "@mui/material/Slide";
import CloseIcon from "@mui/icons-material/Close";

const useStyles = makeStyles((theme) => ({
  dialog: {
    // maxWidth: 500,
    width: "auto",
  },

  dialog_title: {
    textAlign: "center",
    color: " #5DE2E7",
    fontSize: 25,
  },
  forget_password: {
    // position: 'absolute',
    // left: 25,
    // top: 210,
    color: " #5DE2E7",
    fontSize: 15,
    cursor: "pointer",
  },
  acc_signin: {
    position: "absolute",
    left: 25,
    // top: 210,
    color: " #5DE2E7",
    fontSize: 15,
    cursor: "pointer",
  },
}));

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function ForgetPassword({ nameTitle }) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleForgotPassword = (e) => {
    e.preventDefault();
    const form = e.target.elements;
    setLoading(true);
  };

  return (
    <div>
      <Typography onClick={handleClickOpen} className={classes.forget_password}>
        Forget Password ?
      </Typography>

      <Dialog
        className={classes.dialog}
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClickOpen}
      >
        <IconButton
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
          }}
          onClick={handleClose}
        >
          <CloseIcon />
        </IconButton>

        <DialogTitle className={classes.dialog_title}>
          {/* {"Forgot Password ?"} */}
          {nameTitle}
        </DialogTitle>
        <DialogContentText sx={{ padding: 3 }}>
          No worries! Just enter your email and we&apos;ll send you a reset
          password link.
        </DialogContentText>
        <DialogContent>
          <form onSubmit={handleForgotPassword}>
            <Grid container spacing={3} justifyContent="space-evenly">
              <Grid item xs={12} sm={12} md={12} lg={12}>
                <TextField
                  fullWidth
                  required
                  label="Email"
                  name="email"
                  type="email"
                  variant="standard"
                />
              </Grid>

              <Grid item xs={12} sm={12} md={12} lg={12}>
                <Button
                  sx={{
                    textTransform: "none",
                    color: " #000000",
                    background: " #5DE2E7",
                    border: "1px solid #5DE2E7",
                    boxSizing: "border-box",
                    borderRadius: 50,
                    "&:hover": {
                      background: " #5DE2E7",
                      border: "1px solid #5DE2E7",
                    },
                  }}
                  type="submit"
                  fullWidth
                  variant="outlined"
                >
                  {loading ? "Loading ..." : "SEND RECOVERY EMAIL"}
                </Button>
                <br />
                <br />
                <Typography className={classes.acc_signin}>
                  Don&apos;t have account? signin
                </Typography>
              </Grid>
            </Grid>
          </form>
          <br />
          <br />
          <Typography align="center">Just Remembered ?</Typography>
        </DialogContent>
      </Dialog>
    </div>
  );
}
ForgetPassword.propTypes = {
  nameTitle: PropTypes.string.isRequired,
};

ForgetPassword.defaultProps = {
  nameTitle: " Forgot Password ?",
};
