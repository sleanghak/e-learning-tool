import React from 'react';
import makeStyles from '@mui/styles/makeStyles';
import PropTypes from "prop-types";
import { Button, IconButton, TextField, Grid, Typography } from '@mui/material';
import { Dialog, DialogContent, DialogTitle } from '@mui/material';
import Slide from '@mui/material/Slide';
import CloseIcon from '@mui/icons-material/Close';

const useStyles = makeStyles((theme) => ({
  dialog: {
    // maxWidth: 500,
    width: 'auto',
  },
  dialog_title: {
    textAlign: 'center',
    color: ' #5DE2E7',
    fontSize: 25,
  },
  forget_password: {
    position: 'absolute',
    left: 25,
    top: 210,
    color: ' #5DE2E7',
    fontSize: 15,
    cursor: 'pointer',
  },
}));


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function LogIn({
  nameTitle,
}) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleUserSignIn = (e) => {
    e.preventDefault();
    const form = e.target.elements;
    setLoading(true);

  };


  return (
    <div>
      <Button
        variant="outlined"
        onClick={handleClickOpen}
      >
        Log In
      </Button>
      <Dialog
        className={classes.dialog}
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClickOpen}

      >
        <IconButton
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
          }}
          onClick={handleClose}
        >
          <CloseIcon />
        </IconButton>

        <DialogTitle className={classes.dialog_title}>
          {/* {"Login to your account !"} */}
          {nameTitle}
        </DialogTitle>
        <DialogContent>
          <form onSubmit={handleUserSignIn}>
            <Grid
              container
              spacing={3}
              justifyContent="space-evenly"
            >
              <Grid item xs={12} sm={12} md={12} lg={12}>
                <TextField
                  fullWidth
                  required
                  label="Email"
                  name="email"
                  type="email"
                  variant="standard"
                />
              </Grid>

              <Grid item xs={12} sm={12} md={12} lg={12}>
                <TextField
                  fullWidth
                  required
                  label="Password"
                  name="password"
                  type="password"
                  variant="standard"
                />
              </Grid>

              <Typography className={classes.forget_password}>
                Forget Password ?
              </Typography>

              <Grid item xs={12} sm={12} md={12} lg={12}><br /><br />
                <Button
                  sx={{
                    textTransform: 'none',
                    color: ' #000000',
                    background: ' #5DE2E7',
                    border: '1px solid #5DE2E7',
                    boxSizing: 'border-box',
                    borderRadius: 50,
                    '&:hover': {
                      background: ' #5DE2E7',
                      border: '1px solid #5DE2E7',
                    },
                  }}
                  type="submit"
                  fullWidth
                  variant="outlined"
                >
                  {
                    loading ? 'Loading ...' : 'Log In'
                  }
                </Button>
              </Grid>

            </Grid>
          </form>
        </DialogContent>

      </Dialog>
    </div>
  );
};
LogIn.propTypes = {
  nameTitle: PropTypes.string.isRequired,
};  

LogIn.defaultProps = {
  nameTitle: "Login to your account !",
};
