import React from "react";
import Carousel from "react-multi-carousel";
import {
  Snackbar,
  Button,
  IconButton,
  Typography,
  Box,
  Tooltip,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import { CourseCard } from "../../organisms/cards";
import { responsive } from "../../../styles/theme/responsive.carousel";
import { convertFilePathToURL } from "../../../utils/func/s3";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import ClearIcon from "@mui/icons-material/Clear";
import jsCookie from "js-cookie";

//component
import { motion } from "framer-motion";

//icon
import ArrowForwardIosRoundedIcon from "@mui/icons-material/ArrowForwardIosRounded";

const useStyles = makeStyles((theme) => ({}));

export default function CourseSection({ title, data, isDynamic, user }) {
  const classes = useStyles();
  const [courses, setCourses] = React.useState([]);
  const [open, setOpen] = React.useState(false);
  const handleAddFavorite = async (courseId) => {
    const token = jsCookie.get("token_user");
    try {
      if (token) {
        await postDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/course/addFavorite/${courseId}`
        );
      } else {
        setOpen(true);
      }
    } catch (error) {
      console.log(error);
    }
  };
  React.useEffect(() => {
    async function convertToUrl(data) {
      const course = await convertFilePathToURL(data);
      setCourses(course);
    }
    convertToUrl(data);
  }, []);
  return (
    <div>
      <Box display="flex" mb={5}>
        <Typography variant="h6">{title}</Typography>
        <Box flex={1} />
        <Box sx={{ display: { xs: "none", sm: "flex" } }}>
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button variant="contained" size="small">
              View all
            </Button>
          </motion.div>
        </Box>
        <Box sx={{ display: { xs: "flex", sm: "none" } }}>
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <IconButton>
              <Tooltip title="View All">
                <ArrowForwardIosRoundedIcon />
              </Tooltip>
            </IconButton>
          </motion.div>
        </Box>
      </Box>
      <Box>
        <Carousel responsive={responsive}>
          {courses.map((item, index) => {
            return (
              <Box sx={{ mr: 1 }} key={index}>
                <CourseCard
                  {...item}
                  amount_video={item.lessonIds?.length}
                  href={isDynamic ? item._id : `/courses/${item._id}`}
                  favoriteFunc={() => handleAddFavorite(item._id)}
                />
              </Box>
            );
          })}
        </Carousel>
      </Box>
      <Snackbar
        open={open}
        autoHideDuration={6000}
        onClose={() => setOpen(false)}
        message="Please login to add favorite"
        action={
          <IconButton
            size="small"
            color="primary"
            onClick={() => setOpen(false)}
          >
            <ClearIcon />
          </IconButton>
        }
      />
    </div>
  );
}
