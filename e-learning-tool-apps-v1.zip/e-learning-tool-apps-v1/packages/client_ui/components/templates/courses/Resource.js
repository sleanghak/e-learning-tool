import React from "react";
import { Paper, Box } from "@mui/material";

import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { convertFilePathToURL } from "../../../utils/func/s3";
import dynamic from "next/dynamic";
const FileView = dynamic(() => import("react-file-viewer"), {
  ssr: false,
});
const Resource = ({ resources }) => {
  const [data, setData] = React.useState([]);
  const onError = (e) => {
    console.log(e, "error in file-viewer");
  };
  React.useEffect(() => {
    convertFilePathToURL(resources).then((data) => {
      console.log(data);
      setData(data);
    });
  }, []);
  return (
    <Paper square>
      <Typography sx={{ p: 2 }} variant="h3" align="center">
        Course Materials Book & Slide{" "}
      </Typography>

      <Box sx={{ mt: 2, p: 3 }}>
        {data?.map((item, index) => {
          return (
            <Accordion key={index}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography>{item.name}</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <div style={{ width: "100%", margin: "0px auto" }}>
                  <FileView
                    fileType="pdf"
                    filePath={item.fileName}
                    onError={onError}
                  />
                </div>
              </AccordionDetails>
            </Accordion>
          );
        })}
      </Box>
    </Paper>
  );
};

export default Resource;
