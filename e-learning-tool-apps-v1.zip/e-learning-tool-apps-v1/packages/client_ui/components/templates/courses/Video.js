import React from "react";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import {
  Box,
  Stack,
  Typography,
  Accordion,
  Grid,
  AccordionSummary,
  Dialog,
  AccordionDetails,
} from "@mui/material";
import CourseSubList from "./../../organisms/lists/CourseSubList";
import { Player } from "video-react";
import { convertFilePathToURL } from "../../../utils/func/s3";
const Video = ({ lessons, authorize }) => {
  const [video, setVideo] = React.useState(null);
  const handlePlay = async (item) => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/video?id=${item._id}`,
        {
          headers: {
            "x-access-token": authorize.accessToken,
          },
        }
      );
      const data = await res.json();

      const video = await convertFilePathToURL({
        ...item,
        ...data,
        isPlay: true,
      });

      setVideo(video);
      window.scrollTo(0, 200);
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <Box>
      {video && (
        <Box sx={{ mt: 2 }}>
          <Player
            className="video"
            playInline
            poster={video.coverFileName}
            autoPlay={video.isPlay}
            src={video.fileName}
          />
          <Stack spacing={1} sx={{ pt: 1, mb: 3 }}>
            <Typography variant="h4">{video.name}</Typography>
            <Typography>{video.description}</Typography>
          </Stack>
        </Box>
      )}
      {lessons?.map((item, index) => {
        return (
          <Accordion key={index}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1a-content"
              id="panel1a-header"
            >
              <Typography>{item.name}</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Stack direction={"row"} justifyContent="space-between">
                <Box />
              </Stack>
              {item.videoIds.map((video, index) => {
                return (
                  <CourseSubList
                    playFunc={() => handlePlay(video)}
                    key={index}
                    title={video.name}
                    time={video.duration}
                  />
                );
              })}
            </AccordionDetails>
          </Accordion>
        );
      })}
    </Box>
  );
};

export default Video;
