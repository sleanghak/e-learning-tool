import { Button, Paper, Stack, Typography } from "@mui/material";
import dynamic from "next/dynamic";
import React from "react";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import { convertFilePathToURL, uploadFile } from "../../../utils/func/s3";

const FileView = dynamic(() => import("react-file-viewer"), {
  ssr: false,
});
const Curriculum = ({ courseId, name, curriculum }) => {
  const [data, setData] = React.useState(null);

  React.useEffect(() => {
    if (curriculum) {
      convertFilePathToURL({ fileName: curriculum }).then((data) => {
        setData(data);
      });
    }
  }, []);
  return (
    <Paper>
      <Typography
        variant="h3"
        align="center"
        sx={{ p: 1, m: 1, backgroundColor: "#00EDFF", borderRadius: 2 }}
      >
        {name} Curriculum
      </Typography>
      {data ? (
        <div style={{ width: "90%", margin: "0px auto" }}>
          <FileView fileType="pdf" filePath={data.fileName} />
        </div>
      ) : (
        <div>No Curriculum.</div>
      )}
    </Paper>
  );
};

export default Curriculum;
