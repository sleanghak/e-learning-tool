import React from 'react';
import makeStyles from '@mui/styles/makeStyles';
import PropTypes from "prop-types";
import { Button, IconButton, TextField, Grid } from '@mui/material';
import { Dialog, DialogContent, DialogTitle } from '@mui/material';
import { InputLabel, MenuItem, FormControl, Select } from '@mui/material';
import Slide from '@mui/material/Slide';
import CloseIcon from '@mui/icons-material/Close';

const useStyles = makeStyles((theme) => ({
  dialog: {
    // maxWidth: 500,
    width: 'auto',
  },

  dialog_title: {
    textAlign: 'center',
    color: ' #5DE2E7',
    fontSize: 25,
  },

}));


const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function SignUp({ nameTitle, }) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [role, setRole] = React.useState('');

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleUserRegister = (e) => {
    e.preventDefault();
    const form = e.target.elements;
    setLoading(true);

  };

  const handleChange = (event) => {
    setRole(event.target.value);
  };

  return (
    <div>
      <Button
        variant="outlined"
        onClick={handleClickOpen}
      >
        Sign Up
      </Button>
      <Dialog
        className={classes.dialog}
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClickOpen}

      >
        <IconButton
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
          }}
          onClick={handleClose}
        >
          <CloseIcon />
        </IconButton>

        <DialogTitle className={classes.dialog_title}>
          {/* {"Sign up and start learning !"} */}
          {nameTitle}
        </DialogTitle>
        <DialogContent>
          <form onSubmit={handleUserRegister}>
            <Grid
              container
              spacing={3}
              justifyContent="space-evenly"
            >

              <Grid item xs={12} sm={12} md={12} lg={12}>
                <TextField
                  fullWidth
                  required
                  label="Name"
                  name="username"
                  type="text"
                  variant="standard"
                />
              </Grid>

              <Grid item xs={12} sm={12} md={12} lg={12}>
                <TextField
                  fullWidth
                  required
                  label="Email"
                  name="email"
                  type="email"
                  variant="standard"
                />
              </Grid>

              <Grid item xs={12} sm={12} md={12} lg={12}>
                <TextField
                  fullWidth
                  required
                  label="Phone Number"
                  name="phone_number"
                  type="number"
                  variant="standard"
                />
              </Grid>

              <Grid item xs={12} sm={12} md={12} lg={12}>

                <FormControl
                  fullWidth
                  required
                  variant="standard"
                >
                  <InputLabel >Role </InputLabel>
                  <Select
                    value={role}
                    onChange={handleChange}
                    label="Role"
                  >
                    <MenuItem value="">
                      <em>Select Role</em>
                    </MenuItem>
                    <MenuItem value={0}>Teacher</MenuItem>
                    <MenuItem value={1}>Student</MenuItem>

                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12} sm={12} md={12} lg={12}>
                <TextField
                  fullWidth
                  required
                  label="Password"
                  name="password"
                  type="password"
                  variant="standard"
                />
              </Grid>

              <Grid item xs={12} sm={12} md={12} lg={12}>
                <TextField
                  fullWidth
                  required
                  label="Confirm Password"
                  name="confirm_password"
                  type="password"
                  variant="standard"
                />
              </Grid>

              <Grid item xs={12} sm={12} md={12} lg={12}>
                <Button

                  sx={{
                    textTransform: 'none',
                    color: ' #000000',
                    background: ' #5DE2E7',
                    border: '1px solid #5DE2E7',
                    boxSizing: 'border-box',
                    borderRadius: 50,
                    '&:hover': {
                      background: ' #5DE2E7',
                      border: '1px solid #5DE2E7',
                    },
                  }}

                  type="submit"
                  fullWidth
                  variant="outlined"
                >
                  {
                    loading ? 'Loading ...' : 'Sing Up'
                  }
                </Button>
              </Grid>

            </Grid>
          </form>
        </DialogContent>

      </Dialog>
    </div>
  );
};
SignUp.propTypes = {
  nameTitle: PropTypes.string.isRequired,
};

SignUp.defaultProps = {
  nameTitle: "Sign up and start learning !",
};
