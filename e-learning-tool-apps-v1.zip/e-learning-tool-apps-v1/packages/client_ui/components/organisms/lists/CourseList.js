import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Box,
  List,
  ListItemButton,
  ListItemText,
  Collapse,
  Typography,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";

import CourseSubList from "./CourseSubList";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  sub_list: {
    width: "100%",
    padding: "0px 30px",
    [theme.breakpoints.down("sm")]: {
      padding: 0,
    },
  },
}));

const CourseLists = ({ course, subList }) => {
  const classes = useStyles();
  const [open, setOpen] = useState(true);
  const handleClick = () => {
    setOpen(!open);
  };
  console.log("sublist", subList);

  return (
    <Box className={classes.root}>
      <ListItemButton onClick={handleClick} sx={{ padding: "20px 0px" }}>
        <ListItemText>
          <Typography variant="title">{course}</Typography>
        </ListItemText>
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItemButton>
      <Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding className={classes.sub_list}>
          {subList?.map((item, index) => {
            return (
              <CourseSubList
                key={index}
                title={item.name}
                quiz={item.quiz}
                assignment={item.assignment}
                time={` `}
              />
            );
          })}
        </List>
      </Collapse>
    </Box>
  );
};

export default CourseLists;

CourseLists.propTypes = {
  course: PropTypes.string,
  subList: PropTypes.array,
};

CourseLists.defaultProps = {};
