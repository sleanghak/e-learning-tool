import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Box,
  Button,
  Card,
  CardActions,
  CardMedia,
  IconButton,
  Paper,
  Grid,
  Divider,
  InputBase,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import LinkRoundedIcon from "@mui/icons-material/LinkRounded";

const useStyles = makeStyles((theme) => ({
  root: {
    boxShadow: "none",
  },
  close_icon_box: {
    display: "flex",
    alignItems: "center",
  },
  close_icon: {
    margin: "10px 10px 0px 0px",
    [theme.breakpoints.down("sm")]: {
      margin: 0,
    },
  },
  content: {
    padding: 20,
    [theme.breakpoints.down("sm")]: {
      padding: 10,
    },
  },
  certificate_image: {
    width: 600,
    maxWidth: "100%",
  },
  card_media: {
    display: "flex",
    flexDirection: "column",
  },
  copy_link_box: {
    display: "flex",
    width: "100%",
    margin: 20,
  },
  copy_link_content: {
    display: "flex",
    alignItems: "center",
    width: "100%",
    boxShadow: "none",
    border: "1px solid #7D7878",
    borderRadius: 0,
  },
  icon_button_copy_link: {
    padding: 10,
  },
  divider: {
    height: "80%",
    backgroundColor: "#7D7878",
    margin: 0.5,
  },
  input: {
    flex: 1,
    marginLeft: 10,
    marginRight: 10,
    fontSize: 15,
    fontWeight: 500,
    color: "#7D7878",
  },
  copy_link_button: {
    boxShadow: "none",
    borderTop: "1px solid #7D7878",
    borderBottom: "1px solid #7D7878",
    borderRight: "1px solid #7D7878",
    borderRadius: 0,
    padding: 0,
    heigh: 50,
    width: 150,
  },
  download_box: {
    width: "100%",
  },
}));

const CertificateDialogCard = ({
  certificateImage,
  certificateLink,
  onClose,
}) => {
  const classes = useStyles();
  return (
    <Card className={classes.root}>
      <Box className={classes.close_icon_box}>
        <Box sx={{ flexGrow: 1 }} />
        <IconButton className={classes.close_icon}>
          <CloseRoundedIcon
            onClick={onClose}
            sx={{ fontSize: 25, color: "#000000" }}
          />
        </IconButton>
      </Box>
      <Box className={classes.content}>
        <CardMedia
          component="img"
          className={classes.certificate_image}
          image={certificateImage}
        />
        <CardActions className={classes.card_media}>
          <Box className={classes.copy_link_box}>
            <Paper component="form" className={classes.copy_link_content}>
              <IconButton className={classes.icon_button_copy_link}>
                <LinkRoundedIcon sx={{ transform: "rotate(45deg)" }} />
              </IconButton>
              <Divider className={classes.divider} orientation="vertical" />
              <InputBase className={classes.input} value={certificateLink} />
            </Paper>
            <Button
              sx={{ ml: 2 }}
              variant="contained"
              className={classes.copy_link_button}
            >
              Copy
            </Button>
          </Box>
          <Box className={classes.download_box}>
            <Grid container columnSpacing={3} rowSpacing={1}>
              <Grid item xs={12} sm={6} md={6} lg={6}>
                <Button variant="outlined" fullWidth>
                  Download Image
                </Button>
              </Grid>
              <Grid item xs={12} sm={6} md={6} lg={6}>
                <Button variant="outlined" fullWidth>
                  Download PDF
                </Button>
              </Grid>
            </Grid>
          </Box>
        </CardActions>
      </Box>
    </Card>
  );
};

export default CertificateDialogCard;

CertificateDialogCard.propTypes = {
  certificateImage: PropTypes.string.isRequired,
  certificateLink: PropTypes.string.isRequired,
  onClose: PropTypes.func.isRequired,
};

CertificateDialogCard.defaultProps = {
  certificateImage: "./images/sample_certificate.png",
  certificateLink: "https://sabaicode.com/Certificate/1014-20311448/jpg/",
};
