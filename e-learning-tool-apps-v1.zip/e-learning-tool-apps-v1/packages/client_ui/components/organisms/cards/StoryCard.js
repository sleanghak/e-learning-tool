import React from "react";
import { makeStyles } from "@mui/styles";
import { Card, Button, Typography, Box } from "@mui/material";
import Image from "next/image";
import { motion } from "framer-motion";

const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 400,
    width: "100%",
    borderRadius: 10,
    position: "relative",
  },
  background: {
    background: "#5DE2E7",
    height: 140,
    width: "100%",
    display: 'flex',
    alignItems: 'end',
    padding: '0 0 10px 20px'
  },
  profile: {
    background: " #FFFFFF",
    boxShadow: "0px 2px 2px #5DE2E7",
    height: 100,
    width: 100,
    borderRadius: 50,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  cover: {
    position: "absolute",
    top: 80,
    right: 20,
    [theme.breakpoints.down("md")]: {
      right: 10,
    },
    [theme.breakpoints.down("sm")]: {
      right: 5,
    },
  },
  number: {
    position: "absolute",
    top: 90,
    right: 40,
    color: "#FFFFFF",
    height: 20,
    width: 20,
    background: "#5DE2E7",
    borderRadius: 10,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
}));

export default function StoryCard({ name, profile, number, title, desc }) {
  const classes = useStyles();
  return (
    <Card className={classes.root}>
      <Box className={classes.background}>
        <Box>
          <Typography
            sx={{ color: "#FFFFFF", fontWeight: 900 }}
            variant="h5"
          >
            {name}
          </Typography>
        </Box>
      </Box>
      <Box className={classes.cover}>
        <Box className={classes.profile}>
          <Box>

            <motion.div whileHover={{ scale: 1.5 }} whileTap={{ scale: 0.9 }}>
              <Image height="60" width="60" src={profile} alt="img" />
            </motion.div>
          </Box>
          <Box className={classes.number}>
            <Typography >{number}</Typography>
          </Box>
        </Box>
      </Box>
      <Box sx={{ p: { xs: '20px 10px 10px 10px', sm: '20px 15px 15px 15px' } }}>
        <Box sx={{ mt: 3, mb: 3 }}>
          <Typography
            sx={{ fontWeight: 900 }}
            variant="h6"
          >
            {title}
          </Typography>
        </Box>
        <Box sx={{ mb: 3 }}>
          <Typography varinat='secondary'>
            {desc}
          </Typography>
        </Box>
        <Box display='flex' justifyContent='end'>
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button variant="contained">Read more</Button>
          </motion.div>
        </Box>
      </Box>
    </Card>
  );
}
