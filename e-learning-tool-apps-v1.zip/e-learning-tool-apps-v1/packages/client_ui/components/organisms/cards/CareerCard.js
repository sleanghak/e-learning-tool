import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    Box,
    Button,
    Grid,
    Stack,
    Typography,
} from '@mui/material';
import { makeStyles } from '@mui/styles';
import Lightbox from 'react-image-lightbox';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        padding: 50,
        [theme.breakpoints.down("md")]: {
            padding: '40px 30px',
        },
        [theme.breakpoints.down("sm")]: {
            padding: '30px 10px',
        },
        backgroundColor: '#F6FAFD',
        display: 'flex',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    cover: {
        width: '100%',
        heihgt: 'auto'
    }
}));

const CareerCard = ({
    title,
    description,
    date,
    cover,
}) => {
    const classes = useStyles();
    const [isOpen, setIsOpen] = useState(false);
    return (
        <Box className={classes.root}>
            <Grid container spacing={5}>
                <Grid item xs={12} sm={7} md={8}>
                    <Stack spacing={{ xs: '30px', sm: '40px', md: '50px' }}>
                        <Box>
                            <Typography variant='title'>
                                {title}
                            </Typography>
                        </Box>
                        <Box>
                            {/* description */}
                            <Typography variant='primary'>
                                We are looking for a passionate programmer to work on new exciting initiatives. The candidate will be mentored by both of our cofounders.
                                <br />
                                Job Duties
                                <ol>
                                    <li>
                                        Write well designed, testable, efficient code by using best software development practices
                                    </li>
                                    <li>
                                        Create web/mobile app using ReactJs/Reactnative by making components based on separation of concerns best practice
                                    </li>
                                    <li>
                                        Integrate data from various back-end services and databases
                                    </li>
                                </ol>
                                <br />
                                Required Skills
                                <ul>
                                    <li>
                                        Excellent organizational skills
                                    </li>
                                    <li>
                                        Knowledge of HTML5, CSS, and JavaScript
                                    </li>
                                    <li>
                                        Experience with Git version control
                                    </li>
                                    <li>
                                        Experience with JavaScript/Nodejs
                                    </li>
                                    <li>
                                        Familiarity with CSS pre-processors such as Sass and/or PostCSS
                                    </li>
                                    <li>
                                        Experience with building tools such as Nextjs Webpack
                                    </li>
                                    <li>
                                        Knowledge of Rest API/ Graphql
                                    </li>
                                </ul>
                                <br />
                                Open to University Students/Fresh Graduates who want to get experience.
                                <br />
                                Salary: Competitive Salary
                            </Typography>
                        </Box>
                    </Stack>
                </Grid>
                <Grid item xs={12} sm={5} md={4}>
                    <Stack spacing={{ xs: '30px', sm: '40px', md: '50px' }}>
                        <Box>
                            <Typography variant='primary'>
                                Date : {date}
                            </Typography>
                        </Box>
                        <Box>
                            <img
                                onClick={() => setIsOpen(true)}
                                className={classes.cover}
                                src={cover}
                            />
                        </Box>
                        <Box>
                            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                                <Button variant='outlined' sx={{ mr: '10px' }}>
                                    Contact
                                </Button>
                                <Button variant='contained'>
                                    Apply
                                </Button>
                            </Box>
                        </Box>
                    </Stack>
                </Grid>
            </Grid>
            {isOpen && (
                <Lightbox
                    mainSrc={cover}
                    onCloseRequest={() => setIsOpen(false)}
                />
            )}
        </Box>
    );
};

export default CareerCard;

CareerCard.propTypes = {
    title: PropTypes.string.isRequired,
    description: PropTypes.string,
    date: PropTypes.string.isRequired,
    cover: PropTypes.string.isRequired,
};

CareerCard.defaultProps = {
};
