import React from "react";
import { makeStyles } from "@mui/styles";
import { useState } from "react";
import PropTypes from "prop-types";
import { Button, IconButton, Typography } from "@mui/material";
import { Box, Rating } from "@mui/material";
import { Card, CardActions, CardContent, CardMedia } from "@mui/material";
import FavoriteBorderRoundedIcon from "@mui/icons-material/FavoriteBorderRounded";
import BookmarkRemoveIcon from "@mui/icons-material/BookmarkRemove";
import { motion } from "framer-motion";
const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 400,
    width: "100%",
    padding: "20px 15px 15px 15px",
    [theme.breakpoints.down("md")]: {
      padding: "15px 10px 10px 10px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "10px 5px 5px 5px",
    },
    boxShadow: "0px 0px 6px rgba(0, 0, 0, 0.25)",
  },
  image: {
    height: 175,
  },
}));

export default function CourseCard({
  coverFileName,
  title,
  name,
  rate,
  amount_video,
  href,
  favoriteFunc,
  isRemove = false,
  removeFavoriteFunc,
}) {
  const classes = useStyles();
  const [value, setValue] = useState(5);

  return (
    <>
      <Card className={classes.root}>
        <motion.div whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}>
          <CardMedia
            component="img"
            className={classes.image}
            alt={title}
            image={coverFileName}
            title={title}
          />
        </motion.div>
        <Box mt={2}>
          <Typography noWrap className={classes.NameTitle}>{name}</Typography>
        </Box>
        <Box display='flex' alignItems='center' flexWrap='wrap'>
          <Box sx={{ display: "flex", alignItems: "center", m: 1 }}>
            <Box sx={{ mr: 1 }}>
              <Typography className={classes.RateText}>{rate}</Typography>
            </Box>
            <Rating
              readOnly
              value={value}
              onChange={(event, newValue) => {
                setValue(newValue);
              }}
            />
          </Box>
          <Box flex={1} />
          <Box sx={{ m: 1, mixWidth: '100px' }}>
            <Typography>{amount_video} Videos</Typography>
          </Box>
        </Box>
        <Box display='flex' alignItems='center' flexWrap='wrap'>
          <Box sx={{ m: 1 }}>
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              {/* TODO:: push extra route e.g course/id -> course/course/id */}

              <Button
                href={href}
                variant="contained"
                size="small"
                className={classes.btn}
              >
                View Lesson
              </Button>
            </motion.div>
          </Box>
          <Box flex={1} />
          <Box sx={{ m: 1 }}>
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              {isRemove ? (
                <IconButton onClick={removeFavoriteFunc} color="secondary">
                  <BookmarkRemoveIcon color="secondary" />
                </IconButton>
              ) : (
                <IconButton onClick={favoriteFunc} sx={{ float: "right" }}>
                  <FavoriteBorderRoundedIcon />
                </IconButton>
              )}
            </motion.div>
          </Box>
        </Box>
      </Card>
    </>
  );
}

CourseCard.propTypes = {
  imageUrl: PropTypes.string.isRequired,
  title: PropTypes.string,
  name: PropTypes.string,
  rate: PropTypes.string,
  amount_video: PropTypes.number,
};

CourseCard.defaultProps = {
  imageUrl: "https://ddi-dev.com/uploads/backend-is.png",
  title: "Back End Development Course",
  name: "Back End Development Course",
  rate: "4.8",
};
