import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Box,
    Card
} from '@mui/material';
import { makeStyles } from '@mui/styles';
import OurstoryCard from '../../molecules/cards/OurstoryCard';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
    },
    card: {
        boxShadow: '0px 0px 6px rgba(0, 0, 0, 0.25)',
        background: '#FFFFFF',
        border: '2px solid #5DE2E7',
        borderRadius: 5,
        maxWidth: 1200,
        width: '100%',
        margin: 'auto',
        [theme.breakpoints.down('sm')]: {
            border: 'none',
            boxShadow: 'none',
        }
    },
    container: {
        display: 'flex',
        justifyContent: 'space-around',
        flexWrap: 'wrap',
        width: '100%',
        height: 250,
        [theme.breakpoints.down("sm")]: {
            height: 'auto',
        },
    },
    parent: {
        position: 'relative',
    },
    child: {
        maxWidth: 300,
        position: 'absolute',
        top: 250,
        transform: 'translate(-50%, -50%)',
        [theme.breakpoints.down("sm")]: {
            position: 'static',
            transform: 'none',
            top: 0,
        },
    },
    imageBottom: {
        width: '100%',
        height: 250,
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundImage: 'url(./images/imageBottom.png)',
        [theme.breakpoints.down("sm")]: {
           height: 0,
        },
    },
}));

const OurstorySection = ({

}) => {
    const classes = useStyles();
    return (
        <Box className={classes.root}>
            <Card className={classes.card}>
                    <Box className={classes.container}>
                        <Box className={classes.parent}>
                            <Box className={classes.child}>
                                <OurstoryCard
                                    imagePath='./images/vision.png'
                                    title='VISION'
                                    description='To develop the next generation of Cambodian leaders in technology and innovation.'
                                />
                            </Box>
                        </Box>
                        <Box className={classes.parent}>
                            <Box className={classes.child}>
                                <OurstoryCard
                                    imagePath='./images/mission.png'
                                    title='MISSION'
                                    description='To empower every Cambodian child with powerful technology skills.'
                                />
                            </Box>
                        </Box>
                    </Box>
                <Box className={classes.imageBottom} />

            </Card>
        </Box>
    );
}

export default OurstorySection;

OurstorySection.propTypes = {

};

OurstorySection.defaultProps = {

};