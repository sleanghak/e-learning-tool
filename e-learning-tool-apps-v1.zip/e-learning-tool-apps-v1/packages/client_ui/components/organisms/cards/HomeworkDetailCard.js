import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import { Avatar, Box, IconButton, Typography } from "@mui/material";
import AssignmentRoundedIcon from "@mui/icons-material/AssignmentRounded";
import MoreVertRoundedIcon from "@mui/icons-material/MoreVertRounded";
import { toDateFormat, toTime } from "../../../utils/func/toDateFormat";
const useStyles = makeStyles((theme) => ({
  root: {
    paddingBottom: 45,
    borderBottom: "1px solid #000000",
    display: "flex",
    width: "100%",
    marginTop: 100,
  },
  assignment_profile: {
    width: 50,
    height: 50,
    background: "#7D7878",
  },
  content: {
    paddingLeft: 50,
    width: "100%",
    [theme.breakpoints.down("md")]: {
      paddingLeft: 25,
    },
    [theme.breakpoints.down("sm")]: {
      paddingLeft: 10,
    },
  },
  head: {
    display: "flex",
  },
  footer: {
    display: "flex",
    marginTop: 35,
  },
}));

const HomeworkDetailCard = ({ title, name, asignDate, score, dueDate }) => {
  const classes = useStyles();
  return (
    <Box className={classes.root}>
      <Box>
        <Avatar className={classes.assignment_profile}>
          <AssignmentRoundedIcon />
        </Avatar>
      </Box>
      <Box className={classes.content}>
        <Box className={classes.head}>
          <Typography sx={{ fontSize: 25 }}>{title}</Typography>
          <Box sx={{ flexGrow: 1 }} />
          <IconButton>
            <MoreVertRoundedIcon />
          </IconButton>
        </Box>
        <Box sx={{ marginTop: "20px" }}>
          <Typography sx={{ fontSize: 15, color: "#7D7878" }}>
            {name} {toDateFormat(asignDate)} {toTime(asignDate)}
          </Typography>
        </Box>
        <Box className={classes.footer}>
          <Typography sx={{ fontSize: 15, fontWeight: 700 }}>
            {score} points
          </Typography>
          <Box sx={{ flexGrow: 1 }} />
          <Typography sx={{ fontSize: 15, mr: "20px" }}>
            Due {toDateFormat(dueDate)} {toTime(dueDate)}
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default HomeworkDetailCard;

HomeworkDetailCard.propTypes = {
  title: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  score: PropTypes.number.isRequired,
  dueDate: PropTypes.string.isRequired,
};

HomeworkDetailCard.defaultProps = {
  title: "Homework",
  name: "Mr .Nak",
  asignDate: "20-Feb-2022",
  score: 100,
  dueDate: "5-Feb-2022, 11:59 pm",
};
