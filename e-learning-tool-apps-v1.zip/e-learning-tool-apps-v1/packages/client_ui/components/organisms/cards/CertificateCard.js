import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Card,
  CardMedia,
  CardContent,
  Typography,
  Dialog,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import SkeletonMadia from "../../atoms/skeletons/SkeletonMadia";
import SkeletonTitle from "../../atoms/skeletons/SkeletonTitle";
import CertificateDialogCard from "./CertificateDialogCard";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 600,
    padding: "20px 15px 15px 15px",
    boxShadow: "0px 0px 6px rgba(0, 0, 0, 0.25)",
  },
  cover: {
    height: 200,
  },
  content: {
    padding: "30px 0px 0px 40px",
  },
}));

const CertificateCard = ({
  cover,
  title,
  certificateImage,
  certificateLink,
  loading,
}) => {
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  return (
    <div>
      {loading ? (
        <Card className={classes.root}>
          <SkeletonMadia height={200} />
          <CardContent className={classes.content}>
            <Typography variant="title">
              <SkeletonTitle />
            </Typography>
          </CardContent>
        </Card>
      ) : (
        <Card className={classes.root} onClick={() => setOpen(true)}>
          <CardMedia
            component="img"
            className={classes.cover}
            alt={title}
            image={cover}
          />
          <CardContent className={classes.content}>
            <Typography variant="title">{title}</Typography>
          </CardContent>
        </Card>
      )}
      <Dialog open={open}>
        <CertificateDialogCard
          onClose={() => setOpen(false)}
          certificateImage={certificateImage}
          certificateLink={certificateLink}
        />
      </Dialog>
    </div>
  );
};

export default CertificateCard;

CertificateCard.propTypes = {
  cover: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
};

CertificateCard.defaultProps = {
  cover: "/images/sample_certificate.png",
  title: "Back End Development Course",
  loading: false,
};
