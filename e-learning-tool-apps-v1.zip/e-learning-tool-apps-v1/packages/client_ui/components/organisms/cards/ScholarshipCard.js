import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    Box,
    Button,
    Divider,
    IconButton,
    Typography,
} from '@mui/material';
import { FacebookShareButton } from "react-share";
import { makeStyles } from '@mui/styles';
import ShareRoundedIcon from '@mui/icons-material/ShareRounded';
import QRCode from "react-qr-code";

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        padding: 50,
        [theme.breakpoints.down('md')]: {
            padding: '40px 30px',
        },
        [theme.breakpoints.down('sm')]: {
            padding: '30px 10px',
        },
        backgroundColor: '#F6FAFD',
        display: 'flex',
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    header: {
        width: '100%',
        display: 'flex',
        alignItems: 'center'
    },
    logo_box: {
        display: 'flex',
        alignItems: 'end',
    },
    title: {
        margin: '30px 0'
    },
    footer: {
        width: '100%',
        display: 'flex',
        flexWrap: 'wrap',
        marginTop: 30,
    }
}));

const ScholarshipCard = ({
    logoImage,
    CompanyName,
    title,
    description,
    date,
    applyURL,
}) => {
    const classes = useStyles();
    return (
        <Box className={classes.root}>
            <Box className={classes.header}>
                <Box className={classes.logo_box}>
                    <Box>
                        <img
                            src={logoImage}
                            style={{ width: '50px', height: 'auto' }}
                        />
                    </Box>
                    <Typography
                        variant='title'
                        sx={{ ml: '30px' }}
                    >
                        {CompanyName}
                    </Typography>
                </Box>
                <Box flexGrow={1} />
                <Box>
                    <FacebookShareButton
                        url='https://www.example.com'
                        hashtag={'#SabaiCode'}
                    >
                        <IconButton>
                            <ShareRoundedIcon />
                        </IconButton>
                    </FacebookShareButton>
                </Box>
            </Box>
            <Divider sx={{ background: '#5DE2E7', width: '100%', mt: '20px' }} />
            <Box>
                <Box className={classes.title}>
                    <Typography
                        variant='title'
                        sx={{ fontSize: '30px', color: '#00767A' }}
                    >
                        {title}
                    </Typography>
                </Box>
                <Box>
                    <Typography variant='primary'>
                        {description}
                    </Typography>
                </Box>
            </Box>
            <Box className={classes.footer}>
                <Box sx={{ maxWidth: '305px', mr: '20px', mb: '20px' }}>
                    <Typography variant='primary' sx={{ fontWeight: 700 }}>
                        Scan QR code for more information and apply for schoolarship
                    </Typography>
                    <Box sx={{ mt: '20px' }}>
                        <QRCode
                            value={applyURL}
                            bgColor='#F6FAFD'
                            size='100'
                        />
                    </Box>
                </Box>
                <Box flex={1} />
                <Box sx={{ maxWidth: '305px', mb: '20px' }}>
                    <Typography variant='primary' sx={{ fontWeight: 700 }}>
                        Applications Deadline: {date}
                    </Typography>
                    <Box sx={{ display: 'flex', justifyContent: 'center', mt: '110px' }}>
                        <Button variant='outlined' sx={{ mr: '10px' }}>
                            Contact
                        </Button>
                        <Button variant='contained' href={applyURL} target='_blank'>
                            Apply
                        </Button>
                    </Box>
                </Box>
            </Box>
        </Box>
    );
};

export default ScholarshipCard;

ScholarshipCard.propTypes = {
    logoImage: PropTypes.string,
    CompanyName: PropTypes.string,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    date: PropTypes.string.isRequired,
    applyURL: PropTypes.string.isRequired,
};

ScholarshipCard.defaultProps = {
};
