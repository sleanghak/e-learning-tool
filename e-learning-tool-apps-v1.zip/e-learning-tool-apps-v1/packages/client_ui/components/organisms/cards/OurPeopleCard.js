import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import {
    Card,
    Stack,
    Box,
    Typography,
    Divider,
    Button
} from "@mui/material";
import ShowMoreText from "react-show-more-text";

import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import ExpandLessRoundedIcon from '@mui/icons-material/ExpandLessRounded';

const useStyles = makeStyles((theme) => ({
    card: {
        maxWidth: 1200,
        margin: '0px auto',
        padding: 20,
        borderRadius: 5,
        boxShadow: '0px 0px 6px #5DE2E7',
        border: 'none',
        [theme.breakpoints.down("sm")]: {
            maxWidth: 350,

        },
    },
    container: {
        [theme.breakpoints.down("sm")]: {
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
        },
    },
    image: {
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        width: 200,
        height: 200,
        marginBottom: 20,
    },
    see_more_button: {
        color: '#5DE2E7',
        padding: 0,
    }
}));

const OurPeopleCard = ({
    imagePath,
    name,
    position,
    description,
}) => {
    const classes = useStyles();
    const [expand, setExpand] = useState(false);
    const onClick = () => {
        setExpand(!expand);
    };
    return (
        <div>
            <Card className={classes.card}>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    divider={<Divider orientation='vertical' flexItem sx={{ background: '#5DE2E7', width: 3, border: 'none' }} />}
                    // 'vertical' 'horizontal'
                    spacing={{ xs: 1, sm: 4, md: 6 }}
                    className={classes.container}
                >
                    <Box>
                        <Box className={classes.image} sx={{ backgroundImage: `url(${imagePath})` }} />
                        <Box>
                            <Typography sx={{ fontSize: '20px', fontWeight: 'bold', mb: { xs: '10px', sm: '20px' }, textAlign: 'center' }}>
                                {name}
                            </Typography>
                            <Typography sx={{ fontSize: '18px', fontWeight: 'bold', color: '#F81818', textAlign: 'center' }}>
                                {position}
                            </Typography>
                        </Box>
                    </Box>
                        <Typography>
                            <ShowMoreText
                                lines={12}
                                more={<span style={{ color: 'blue' }}>Show More</span>}
                                less={<span style={{ color: 'blue' }}>Show Less</span>}
                                onClick={onClick}
                                expanded={expand}
                            >
                                {description}
                            </ShowMoreText>
                        </Typography>
                    
                </Stack>
            </Card>
        </div>
    );
};

export default OurPeopleCard;

OurPeopleCard.propTypes = {
    imagePath: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    position: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
};

OurPeopleCard.defaultProps = {

};
