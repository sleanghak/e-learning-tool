import React from "react";
import PropTypes from "prop-types";
import Link from "next/link";
import { makeStyles } from "@mui/styles";
import {
  Card,
  Box,
  Avatar,
  Typography,
  Button,
  Stack,
  Dialog,
} from "@mui/material";

//icon
import AccessAlarmRoundedIcon from "@mui/icons-material/AccessAlarmRounded";
import AccessTimeRoundedIcon from "@mui/icons-material/AccessTimeRounded";

//component
import { motion } from "framer-motion";

//data
import { toDateFormat } from "../../../utils/func/toDateFormat";
import RegisterForm from "../forms/RegisterForm";

const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 400,
    width: "100%",
    borderRadius: 5,
    padding: "10px 15px 30px 15px",
    position: "relative",
    [theme.breakpoints.down("md")]: {
      padding: "10px",
    },
  },
  ribbon: {
    width: 130,
    height: 130,
    position: "absolute",
    top: -40,
    left: -40,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 999,
  },
  ribbon_content: {
    transform: "rotate(-45deg) translateY(-20px)",
    position: "absolute",
    width: "150%",
    padding: "35px 0px 10px 0px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F81818",
    boxShadow: "0px 5px 10px rgba(0, 0, 0, 0.192)",
    color: "#FFFFFF",
    textShadow: "0px 1px 1px rgba(0,0,0,.2)",
    textTransform: "uppercase",
    textAlign: "center",
  },
  class_head: {
    display: "flex",
    alignItems: "top",
    marginTop: 40,
    [theme.breakpoints.down("sm")]: {
      flexWrap: "wrap",
    },
  },
  cover: {
    width: 80,
    height: 80,
    marginRight: 20,
  },
  title: {
    maxWidth: 270,
    [theme.breakpoints.down("sm")]: {
      maxWidth: "100%",
      marginTop: 20,
    },
  },
  description: {
    marginTop: 30,
    width: "100%",
    [theme.breakpoints.down("sm")]: {
      marginTop: 20,
    },
  },
  time_section: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    marginTop: 10,
  },
  time_box: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    minWidth: 115,
    marginRight: 20,
  },
  time: {
    fontSize: 12,
    marginTop: 10,
  },
}));

export default function UpcomingClassCard({
  coverFileName,
  title,
  description,
  startDate,
  time,
  _id,
}) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  return (
    <>
      <Card className={classes.root}>
        <motion.div
          animate={{ x: 50, x: 0 }}
          transition={{ ease: "easeOut", duration: 1 }}
        >
          <div className={classes.ribbon}>
            <span className={classes.ribbon_content}>new</span>
          </div>
        </motion.div>
        <Box className={classes.class_head}>
          <motion.div whileHover={{ scale: 1.5 }} whileTap={{ scale: 0.9 }}>
            <Avatar
              src={coverFileName}
              variant="rounded"
              className={classes.cover}
            />
          </motion.div>
          <Box className={classes.title}>
            <Typography variant="title">{title}</Typography>
          </Box>
        </Box>
        <Box className={classes.description}>
          <Typography variant="primary">{description}</Typography>
        </Box>
        <Box className={classes.time_section}>
          <Box className={classes.time_box}>
            <AccessAlarmRoundedIcon sx={{ mr: "10px", mt: "10px" }} />
            <Typography variant="secondary" className={classes.time}>
              start:{toDateFormat(startDate)}
            </Typography>
          </Box>
          <Box className={classes.time_box}>
            <AccessTimeRoundedIcon sx={{ mr: "10px", mt: "10px" }} />
            <Typography variant="secondary" className={classes.time}>
              {time} / week
            </Typography>
          </Box>
        </Box>
        <Stack sx={{ mt: 4 }} direction={"row"} justifyContent="space-between" flexWrap='wrap'>
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button onClick={() => setOpen(true)} variant="contained" sx={{ m: { xs: '5px 0' } }}>
              Join
            </Button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Link href={`/courses/post/${_id}`}>
              <Button variant="outlined" sx={{ m: { xs: '5px 0' } }}>View</Button>
            </Link>
          </motion.div>
        </Stack>
        <Dialog open={open} onClose={() => setOpen(false)}>
          <RegisterForm postId={_id} onClose={() => setOpen(false)} />
        </Dialog>
      </Card>
    </>
  );
}

UpcomingClassCard.propTypes = {
  cover: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  startDate: PropTypes.string.isRequired,
  time: PropTypes.string.isRequired,
  onJoinClassFunc: PropTypes.func,
};

UpcomingClassCard.defaultProps = {
  cover: "https://kinsta.com/wp-content/uploads/2021/11/back-end-developer.png",
  title: "Back End Development Course |",
  description:
    "Improve your practical digital literacy skills and enhance your confidence online with this practical course.",
  startDate: "23-April-20220",
  time: "3 hour",
};
