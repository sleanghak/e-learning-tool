import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import {
    Card,
    Avatar,
    Box,
    Typography,
    Stack,
} from "@mui/material";

// icon
import TelegramIcon from '@mui/icons-material/Telegram';
import FacebookRoundedIcon from '@mui/icons-material/FacebookRounded';
import LocalPhoneRoundedIcon from '@mui/icons-material/LocalPhoneRounded';

const useStyles = makeStyles((theme) => ({
    card: {
        width: '100%',
        maxWidth: 270,
        boxShadow: '0px 0px 6px #5DE2E7',
        border: 'none',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    head: {
        width: '100%',
        height: 130,
        position: 'relative',
    },
    profile: {
        width: 130,
        height: 130,
        position: 'absolute',
        top: '75%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
    },
    body: {
        marginTop: 50,
    },
    footer: {
        margin: '20px 0',
    },
    icon: {
        color: '#7D7878',
        '& :hover': {
            color: '#000000',
        }
    }
}));

const CoachCard = ({
    cover,
    profile,
    name,
    position,
}) => {
    const classes = useStyles();
    return (
        <Card className={classes.card}>
            <Box className={classes.head} sx={{ backgroundImage: `url(${cover})` }}>
                <Avatar
                    src={profile}
                    className={classes.profile}
                />
            </Box>
            <Box className={classes.body}>
                <Typography sx={{ fontSize: '20px', fontWeight: 'bold', mb: '20px', textAlign: 'center' }}>
                    {name}
                </Typography>
                <Typography sx={{ fontSize: '18px', fontWeight: 'bold', color: '#F81818', textAlign: 'center' }}>
                    {position}
                </Typography>
            </Box>
            <Box className={classes.footer}>
                <Stack
                    direction="row"
                    spacing={2}
                >
                    <TelegramIcon className={classes.icon} />
                    <FacebookRoundedIcon className={classes.icon} />
                    <LocalPhoneRoundedIcon className={classes.icon} />
                </Stack>
            </Box>
        </Card>
    );
};

export default CoachCard;

CoachCard.propTypes = {
    cover: PropTypes.string.isRequired,
    profile: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    position: PropTypes.string.isRequired,
};

CoachCard.defaultProps = {
    cover: './images/coach_bg.png',
};
