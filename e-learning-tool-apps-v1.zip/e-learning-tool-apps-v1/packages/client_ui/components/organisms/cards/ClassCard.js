import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import {
  Card,
  CardMedia,
  CardContent,
  CardActions,
  Box,
  IconButton,
  Avatar,
  Typography,
  Divider,
  Menu,
  MenuItem,
  Stack,
} from "@mui/material";
import MoreVertRoundedIcon from "@mui/icons-material/MoreVertRounded";
import AssignmentRoundedIcon from "@mui/icons-material/AssignmentRounded";
import FolderOpenRoundedIcon from "@mui/icons-material/FolderOpenRounded";
import { SkeletonMadia } from "../../atoms/skeletons";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import Link from "next/link";
const useStyles = makeStyles((theme) => ({
  card: {
    maxWidth: 400,
    margin: 0,
    padding: 0,
    width: "100%",
    borderRadius: 5,
  },
  cardMedia: {
    width: "100%",
    height: 175,
    display: "flex",
    flexDirection: "column",
  },
  boxIcon: {
    display: "flex",
    padding: "7px 5px 0px 0px",
  },
  buttonIcon: {
    color: "black",
    opacity: 0.5,
    "&:hover ": {
      opacity: 1,
    },
  },
  menuItem: {
    width: "100%",
    marginRight: 20,
  },
  boxAvatar: {
    display: "flex",
    alignItems: "center",
    margin: "auto 0px 17px 17px",
  },
  cardContent: {
    padding: "20px 29px 29px 38px",
  },
  divider: {
    background: "#7D7878",
  },
  cardActions: {
    height: 73,
    display: "flex",
    justifyContent: "center",
  },
}));

const ClassCard = ({
  cover,
  name,
  time,
  href,
  code,
  loading,
  onUnrollFunc,
  onOpenClassFunc,
}) => {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleUnrollFunc = () => {
    onUnrollFunc();
    handleClose();
  };
  return (
      <Card className={classes.card}>
          <Box>
            {loading ? (
              <SkeletonMadia width="100%" height={175} />
            ) : (
              <CardMedia image={cover} className={classes.cardMedia}>
                <Box className={classes.boxIcon}>
                <Box sx={{ flexGrow: 1 }} />
                <IconButton className={classes.buttonIcon} onClick={handleMenu}>
                  <MoreVertRoundedIcon />
                </IconButton>
                <Menu
                  anchorEl={anchorEl}
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "center",
                  }}
                  keepMounted
                  open={Boolean(anchorEl)}
                  onClose={handleClose}
                >
                  <MenuItem
                    onClick={handleUnrollFunc}
                    className={classes.menuItem}
                  >
                    Unenroll
                  </MenuItem>
                </Menu>
              </Box>
              </CardMedia>
            )}
          </Box>
          <Box>
            <CardContent className={classes.cardContent}>
            <Box>
              <Typography noWrap variant="title">
                {name}
              </Typography>
            </Box>
            <Box sx={{ mt: 2 }}>
              <Stack direction={"row"} justifyContent="space-between">
                <Typography variant="secondary">{time}</Typography>
                <Typography color="primary">{code}</Typography>
              </Stack>
            </Box>
          </CardContent>
          </Box>
          <Divider className={classes.divider} />
          <Box className={classes.cardActions}>
          <CardActions>
            <IconButton size="large" className={classes.buttonIcon}>
              <AssignmentRoundedIcon sx={{ fontSize: 25 }} />
            </IconButton>
            <Box sx={{ width: 30 }} />
            <IconButton size="large" className={classes.buttonIcon}>
              <OpenInNewIcon
                color="primary"
                onClick={onOpenClassFunc}
                sx={{ fontSize: 25 }}
              />
            </IconButton>
          </CardActions>
        </Box>
      </Card>
  );
};

export default ClassCard;

ClassCard.propTypes = {
  cover: PropTypes.string.isRequired,
  profile: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  setion: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequires,
};

ClassCard.defaultProps = {
  cover:
    "https://w0.peakpx.com/wallpaper/360/997/HD-wallpaper-techno-2-firefox-theme-technology-blue-lights-arrows.jpg",
  profile:
    "https://i.pinimg.com/originals/82/e7/6c/82e76cb7c2e5fe7a7f0dd795919fed0b.png",
  name: "Mr.Nak",
  title: "Backend Development",
  setion: "Web & Mobile",
  loading: true,
};
