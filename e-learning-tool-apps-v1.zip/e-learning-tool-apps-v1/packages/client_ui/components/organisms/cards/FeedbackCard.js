import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Avatar,
  Typography,
  Box,
  Rating,
  IconButton,
  Link,
  Button,
  Skeleton,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import ThumbUpOutlinedIcon from "@mui/icons-material/ThumbUpOutlined";
import ThumbDownOutlinedIcon from "@mui/icons-material/ThumbDownOutlined";
import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";
import ExpandLessRoundedIcon from "@mui/icons-material/ExpandLessRounded";
import ShowMoreText from "react-show-more-text";
import SkeletonAvatar from "../../atoms/skeletons/SkeletonAvatar";
import SkeletonTitle from "../../atoms/skeletons/SkeletonTitle";
import SkeletonText from "../../atoms/skeletons/SkeletonText";
import SkeletonIcon from "../../atoms/skeletons/SkeletonIcon";
import { toDateFormat, toTime } from "../../../utils/func/toDateFormat";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    // maxWidth: 600,
    width: "100%",
    borderBottom: "1px solid #7D7878",
    // marginTop: 30,
    // paddingBottom: 20,
  },
  avatar_box: {
    margin: "0px 20px",
    [theme.breakpoints.down("sm")]: {
      margin: "0px 20px 0px 0px",
    },
  },
  rate_box: {
    marginTop: 10,
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
  },
  feedback_box: {
    marginTop: 20,
    width: "100%",
  },
  feedback_content: {
    fontSize: 15,
    color: "#787878",
    fontWeight: "400",
  },
  button: {
    color: "blue",
    fontFamily: "Arial",
    padding: 0,
  },
  helpful_box: {
    marginTop: 10,
  },
  helpful_link: {
    textDecoration: "none",
    cursor: "pointer",
    "&:hover": {
      color: "#7D7878",
      textDecoration: "underline",
    },
  },
  react_box: {
    display: "flex",
    alignItems: "center",
    marginTop: 10,
    flexWrap: "wrap",
  },
  icon_button: {
    border: "1px solid #000000",
    color: "#000000",
    margin: "0px 10px 10px 0px",
  },
  link: {
    fontFamily: "Arial",
    cursor: "pointer",
    color: "#000000",
    textDecoration: "underline",
  },
}));

const FeedbackCard = ({ profile, name, rate, date, feedback, loading }) => {
  const classes = useStyles();
  const [expand, setExpand] = useState(false);
  const onClick = () => {
    setExpand(!expand);
  };
  return (
    <div>
      {loading ? (
        <Box className={classes.root}>
          <Box className={classes.avatar_box}>
            <SkeletonAvatar />
          </Box>
          <Box>
            <Box>
              <Typography variant="primary">
                <SkeletonTitle />
              </Typography>
            </Box>
            <Box className={classes.rate_box}>
              <SkeletonTitle width={100} />
              <Box sx={{ ml: 2 }}>
                <Typography variant="secondary">
                  <SkeletonTitle width={80} />
                </Typography>
              </Box>
            </Box>
            <Box className={classes.feedback_box}>
              <SkeletonText />
              <SkeletonText />
              <SkeletonText />
            </Box>
            <Box>
              <Box className={classes.react_box}>
                <Box sx={{ mr: "10px", mt: "20px" }}>
                  <SkeletonIcon />
                </Box>
                <Box sx={{ mr: "10px", mt: "20px" }}>
                  <SkeletonIcon />
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      ) : (
        <Box className={classes.root}>
          <Box className={classes.avatar_box}>
            <Avatar variant="primary" src={profile} />
          </Box>
          <Box>
            <Box>
              <Typography variant="primary">{name}</Typography>
            </Box>
            <Box className={classes.rate_box}>
              <Rating size="small" readOnly value={rate} sx={{ mr: 2 }} />
              <Box>
                <Typography variant="secondary">
                  {toDateFormat(date)} {toTime(date)}
                </Typography>
              </Box>
            </Box>
            <Box className={classes.feedback_box}>
              <ShowMoreText
                sx={{ width: "100%" }}
                className={classes.feedback_content}
                more={
                  <Box sx={{ display: "block" }}>
                    <Button
                      variant="text"
                      className={classes.button}
                      endIcon={<ExpandMoreRoundedIcon />}
                    >
                      See more
                    </Button>
                  </Box>
                }
                less={
                  <Box sx={{ display: "block" }}>
                    <Button
                      variant="text"
                      className={classes.button}
                      endIcon={<ExpandLessRoundedIcon />}
                    >
                      See less
                    </Button>
                  </Box>
                }
                onClick={onClick}
                expanded={expand}
              >
                <Typography variant="secondary">{feedback}</Typography>
              </ShowMoreText>
            </Box>
            <Box>
              <Box className={classes.helpful_box}>
                <Typography variant="secondary">
                  Was this review helpful?
                </Typography>
              </Box>
              <Box className={classes.react_box}>
                <IconButton className={classes.icon_button} size="small">
                  <ThumbUpOutlinedIcon />
                </IconButton>
                <IconButton className={classes.icon_button} size="small">
                  <ThumbDownOutlinedIcon />
                </IconButton>
                <Typography>
                  <Link className={classes.link}>Report</Link>
                </Typography>
              </Box>
            </Box>
          </Box>
        </Box>
      )}
    </div>
  );
};

export default FeedbackCard;

FeedbackCard.propTypes = {
  profile: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  rate: PropTypes.number.isRequired,
  date: PropTypes.string.isRequired,
  feedback: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
};

FeedbackCard.defaultProps = {
  profile:
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxpHvfOaX3EZ5y-Jn5cvIK1XsBJhBkhDB9eQ&usqp=CAU",
  name: "Monika",
  rate: 5,
  date: "a month ago",
  feedback:
    "  incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation",
  loading: false,
};
