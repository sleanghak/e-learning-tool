import {
  Button,
  Stack,
  FormControl,
  InputLabel,
  Typography,
  Input,
  InputAdornment,
} from "@mui/material";
import React from "react";
import ContactPhoneIcon from "@mui/icons-material/ContactPhone";
import unauthPostDataFunc from "../../../utils/func/api/unauthPostFunc";
import { ifPhoneNumberFormat } from "../../../utils/func/regExp";
const RegisterForm = ({ postId, onClose }) => {
  const [message, setMessage] = React.useState("");
  const handleRegister = async (e) => {
    e.preventDefault();
    const form = e.target.elements;
    if (ifPhoneNumberFormat(form.phone.value)) {
      const res = await unauthPostDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/post/addContact/${postId}`,
        {
          phone: form.phone.value,
        }
      );
      console.log(res, postId);
      if (res.statusCode == 200) {
        onClose();
      } else {
        setMessage(res.message);
      }
    }
  };
  return (
    <form onSubmit={handleRegister}>
      <Stack sx={{ p: 3 }} spacing={3}>
        <Typography>
          Enter your phone number,We will contact you soon.
        </Typography>
        <FormControl variant="standard">
          {/* <InputLabel htmlFor="input-with-icon-adornment">
            With a start adornment
          </InputLabel> */}
          <Input
            name="phone"
            required
            type="tel"
            id="input-with-icon-adornment"
            startAdornment={
              <InputAdornment position="start">
                <ContactPhoneIcon />
              </InputAdornment>
            }
          />
        </FormControl>
        <Button type="submit" variant="contained">
          Register
        </Button>
        {message != "" && (
          <Typography color={"secondary"}>{message}</Typography>
        )}
      </Stack>
    </form>
  );
};

export default RegisterForm;
