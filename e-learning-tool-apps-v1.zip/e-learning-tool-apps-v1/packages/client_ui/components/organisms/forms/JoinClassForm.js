import React from "react";
import { makeStyles } from "@mui/styles";
import { TextField, Typography, Button, Stack, Box } from "@mui/material";
import postDataFunc from "../../../utils/func/api/postDataFunc";

const useStyles = makeStyles((theme) => ({
  root: {
    width: 400,
    padding: 16,
  },
}));
const JoinClassForm = ({ onClose }) => {
  const classes = useStyles();
  const [error, setError] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const handleJoinClass = (e) => {
    e.preventDefault();
    setLoading(true);
    const form = e.target.elements;
    const code = form.code.value;
    setError("");
    if (code.length === 6) {
      postDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/class/join`,
        {
          classCode: code,
        }
      )
        .then((res) => {
          onClose();
          setLoading(false);
        })
        .catch((err) => {
          setError(err);
          setLoading(false);
        });
    } else {
      setError("Your class code is unvalid!");
      setLoading(false);
    }
  };
  return (
    <form onSubmit={handleJoinClass} className={classes.root}>
      <Stack spacing={3}>
        <Box>
          <Typography variant="h6">Class code</Typography>
          <Typography>
            Ask your teacher for the class code, then enter it here.
          </Typography>
        </Box>
        <TextField name="code" fullWidth variant="outlined" />
        {error && <Typography color={"secondary"}>{error}</Typography>}
        <Button disabled={loading} type="submit" variant="contained">
          Join
        </Button>
      </Stack>
    </form>
  );
};

export default JoinClassForm;
