import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Paper,
    TableContainer,
    Table,
    Typography,
    Box,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    IconButton
} from '@mui/material';
import { makeStyles } from '@mui/styles';

import SortButton from '../../../components/molecules/buttons/SortButton';
import EditRoundedIcon from '@mui/icons-material/EditRounded';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        overflow: 'hidden',
        padding: '0px 20px',
        [theme.breakpoints.down("md")]: {
            padding: '0px 10px',
        },
        [theme.breakpoints.down("sm")]: {
            padding: '0px 5px',
        },
    },
    container: {
        maxHeight: 300,
    },

}));

const AttendanceCoaches = ({

}) => {
    const classes = useStyles();
    return (
        <Paper
            className={classes.root}
        >
            <TableContainer
                className={classes.container}
            >
                <Table
                    stickyHeader
                    sx={{
                        '& .MuiTableCell-root': {
                            border: 'none'
                        }
                    }}
                >
                    <TableHead>
                        <TableCell sx={{ minWidth: 150 }}>
                            <SortButton title='Class' />
                        </TableCell>
                        <TableCell sx={{ minWidth: 250 }}>
                            <Typography
                                variant='primary'
                            >
                                <SortButton title='Course Name' />
                            </Typography>
                        </TableCell>
                        <TableCell sx={{ minWidth: 100 }}>
                            <Typography
                                variant='primary'
                            >
                                Durations
                            </Typography>
                        </TableCell>
                        <TableCell sx={{ minWidth: 120 }}>
                            <Typography
                                variant='primary'
                            >
                                Date
                            </Typography>
                        </TableCell>
                        <TableCell sx={{ minWidth: 100 }}>
                            <Typography
                                variant='primary'
                            >
                                Students
                            </Typography>
                        </TableCell>
                        <TableCell
                            sx={{ minWidth: 120 }}
                        >
                            <Typography
                                variant='primary'
                            >
                                Action
                            </Typography>
                        </TableCell>
                    </TableHead>
                    <TableBody>
                        <TableRow>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    sabai code
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    Basic Web development
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    3 hour
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    15-Feb-2022
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    10
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Box>
                                    <IconButton sx={{ mr: '10px' }}>
                                        <EditRoundedIcon sx={{ fontSize: 20, color: '#1597BB' }} />
                                    </IconButton>
                                    <IconButton>
                                        <DeleteRoundedIcon sx={{ fontSize: 20, color: '#F70776' }} />
                                    </IconButton>
                                </Box>
                            </TableCell>
                        </TableRow>
                        <TableRow>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    sabai code
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    Basic Web development
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    3 hour
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    15-Feb-2022
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    10
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Box>
                                    <IconButton sx={{ mr: '10px' }}>
                                        <EditRoundedIcon sx={{ fontSize: 20, color: '#1597BB' }} />
                                    </IconButton>
                                    <IconButton>
                                        <DeleteRoundedIcon sx={{ fontSize: 20, color: '#F70776' }} />
                                    </IconButton>
                                </Box>
                            </TableCell>
                        </TableRow>
                        <TableRow>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    sabai code
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    Basic Web development
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    3 hour
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    15-Feb-2022
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    10
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Box>
                                    <IconButton sx={{ mr: '10px' }}>
                                        <EditRoundedIcon sx={{ fontSize: 20, color: '#1597BB' }} />
                                    </IconButton>
                                    <IconButton>
                                        <DeleteRoundedIcon sx={{ fontSize: 20, color: '#F70776' }} />
                                    </IconButton>
                                </Box>
                            </TableCell>
                        </TableRow>
                        <TableRow>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    sabai code
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    Basic Web development
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    3 hour
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    15-Feb-2022
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    10
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Box>
                                    <IconButton sx={{ mr: '10px' }}>
                                        <EditRoundedIcon sx={{ fontSize: 20, color: '#1597BB' }} />
                                    </IconButton>
                                    <IconButton>
                                        <DeleteRoundedIcon sx={{ fontSize: 20, color: '#F70776' }} />
                                    </IconButton>
                                </Box>
                            </TableCell>
                        </TableRow>
                        <TableRow>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    sabai code
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    Basic Web development
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    3 hour
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    15-Feb-2022
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography
                                    variant='primary'
                                >
                                    10
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Box>
                                    <IconButton sx={{ mr: '10px' }}>
                                        <EditRoundedIcon sx={{ fontSize: 20, color: '#1597BB' }} />
                                    </IconButton>
                                    <IconButton>
                                        <DeleteRoundedIcon sx={{ fontSize: 20, color: '#F70776' }} />
                                    </IconButton>
                                </Box>
                            </TableCell>
                        </TableRow>

                    </TableBody>
                </Table>
            </TableContainer>
        </Paper>
    );
}

export default AttendanceCoaches;

AttendanceCoaches.propTypes = {

};

AttendanceCoaches.defaultProps = {

};