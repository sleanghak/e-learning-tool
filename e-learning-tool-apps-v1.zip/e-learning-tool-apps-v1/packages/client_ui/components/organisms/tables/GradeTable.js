import React, { useState, useLayoutEffect, useRef } from "react";
import PropTypes from "prop-types";
import {
  Box,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Avatar,
  Typography,
  TextField,
  MenuItem,
  IconButton,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import PeopleAltRoundedIcon from "@mui/icons-material/PeopleAltRounded";
import ArrowForwardIosRoundedIcon from "@mui/icons-material/ArrowForwardIosRounded";
import ArrowBackIosRoundedIcon from "@mui/icons-material/ArrowBackIosRounded";
const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  content: {
    overflow: "hidden",
    [theme.breakpoints.down("sm")]: {
      overflow: "auto",
    },
  },
  table: {
    background: "#FFFFFF",
    "& .MuiTableCell-root": {
      borderLeft: "0.25px solid #C4C4C4",
    },
  },
  input_fieldset: {
    maxWidth: 300,
    [theme.breakpoints.down("md")]: {
      maxWidth: 200,
    },
    [theme.breakpoints.down("sm")]: {
      maxWidth: 100,
    },
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        border: "none",
      },
    },
  },
  head_score_column: {
    display: "flex",
    flexDirection: "column",
    minWidth: 150,
  },
  class_avarage: {
    display: "flex",
    alignItems: "end",
  },
  avatar_box: {
    display: "flex",
    alignItems: "center",
    maxWidth: 300,
    [theme.breakpoints.down("md")]: {
      maxWidth: 200,
    },
    [theme.breakpoints.down("sm")]: {
      maxWidth: 100,
    },
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        border: "none",
      },
    },
  },
  icon_button: {
    display: "flex",
    flexDirection: "column",
    padding: 10,
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
  },
}));

const GradeTable = ({}) => {
  const classes = useStyles();
  const [sort, setSort] = useState(0);
  const handleChangeSort = (event) => {
    setSort(event.target.value);
  };
  const handleMoveRight = () => {
    var container = document.getElementById("content");
    var scrollAmount = 0;
    var slideTimer = setInterval(function () {
      container.scrollLeft += 18.3;
      scrollAmount += 10;
      if (scrollAmount >= 100) {
        window.clearInterval(slideTimer);
      }
    }, 25);
  };
  const handleMoveLeft = () => {
    var container = document.getElementById("content");
    var scrollAmount = 0;
    var slideTimer = setInterval(function () {
      container.scrollLeft -= 18.3;
      scrollAmount += 10;
      if (scrollAmount >= 100) {
        window.clearInterval(slideTimer);
      }
    }, 25);
  };

  const ref = useRef();
  const [isOverflow, setIsOverflow] = useState(undefined);
  const useIsOverflow = (callback) => {
    useLayoutEffect(() => {
      const { current } = ref;
      const trigger = () => {
        const hasOverflow = current.scrollWidth > current.clientWidth;
        setIsOverflow(hasOverflow);

        if (callback) callback(hasOverflow);
      };

      if (current) {
        if ("ResizeObserver" in window) {
          new ResizeObserver(trigger).observe(current);
        }
      }
    }, [callback, ref]);
    return isOverflow;
  };
  const overflow = useIsOverflow();

  return (
    <Box className={classes.root}>
      <Box className={classes.content} id="content" ref={ref}>
        <Table className={classes.table}>
          <TableHead
            sx={{
              "& .MuiTableCell-root": {
                border: "none",
              },
            }}
          >
            <TableRow sx={{ border: "none" }}>
              <TableCell
                colSpan={2}
                sx={{
                  position: "sticky",
                  left: 0,
                  zIndex: 99,
                  background: "#FFFFFF",
                }}
                className={classes.head_width}
              >
                <Box>
                  <TextField
                    size="small"
                    select
                    value={sort}
                    onChange={handleChangeSort}
                    className={classes.input_fieldset}
                  >
                    <MenuItem value={0}>
                      <Typography variant="primary">students name</Typography>
                    </MenuItem>
                    <MenuItem value={1}>
                      <Typography variant="primary">sort a-z</Typography>
                    </MenuItem>
                    <MenuItem value={2}>
                      <Typography variant="primary">sort z-a</Typography>
                    </MenuItem>
                  </TextField>
                </Box>
              </TableCell>

              {/* start map homework date*/}
              <TableCell>
                <Box className={classes.head_score_column}>
                  <Typography variant="primary">Mar 19</Typography>
                  <Typography variant="primary" sx={{ color: "#5DE2E7" }}>
                    Home Work
                  </Typography>
                  <Typography variant="primary">out of 100</Typography>
                </Box>
              </TableCell>
              <TableCell>
                <Box className={classes.head_score_column}>
                  <Typography variant="primary">Mar 19</Typography>
                  <Typography variant="primary" sx={{ color: "#5DE2E7" }}>
                    Home Work
                  </Typography>
                  <Typography variant="primary">out of 100</Typography>
                </Box>
              </TableCell>
              <TableCell>
                <Box className={classes.head_score_column}>
                  <Typography variant="primary">Mar 19</Typography>
                  <Typography variant="primary" sx={{ color: "#5DE2E7" }}>
                    Home Work
                  </Typography>
                  <Typography variant="primary">out of 100</Typography>
                </Box>
              </TableCell>
              <TableCell>
                <Box className={classes.head_score_column}>
                  <Typography variant="primary">Mar 19</Typography>
                  <Typography variant="primary" sx={{ color: "#5DE2E7" }}>
                    Home Work
                  </Typography>
                  <Typography variant="primary">out of 100</Typography>
                </Box>
              </TableCell>
              <TableCell>
                <Box className={classes.head_score_column}>
                  <Typography variant="primary">Mar 19</Typography>
                  <Typography variant="primary" sx={{ color: "#5DE2E7" }}>
                    Home Work
                  </Typography>
                  <Typography variant="primary">out of 100</Typography>
                </Box>
              </TableCell>
              <TableCell>
                <Box className={classes.head_score_column}>
                  <Typography variant="primary">Mar 19</Typography>
                  <Typography variant="primary" sx={{ color: "#5DE2E7" }}>
                    Home Work
                  </Typography>
                  <Typography variant="primary">out of 100</Typography>
                </Box>
              </TableCell>
              {/* end map homework date*/}
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow
              sx={{
                background: "#F8F8F8",
                "& .MuiTableCell-root": {
                  border: "none",
                },
              }}
            >
              <TableCell
                colSpan={2}
                align="left"
                sx={{
                  position: "sticky",
                  left: 0,
                  zIndex: 99,
                  background: "#F8F8F8",
                  "& .MuiTableCell-root": {
                    borderBottom: "none",
                  },
                }}
              >
                <Box className={classes.class_avarage}>
                  <PeopleAltRoundedIcon
                    sx={{
                      color: "#7D7878",
                      fontSize: 25,
                      mr: "10px",
                      display: { xs: "none", md: "block" },
                    }}
                  />
                  <Typography variant="primary">Class Average</Typography>
                </Box>
              </TableCell>

              {/* start map score average*/}
              <TableCell align="left">80</TableCell>
              <TableCell align="left">80</TableCell>
              <TableCell align="left">80</TableCell>
              <TableCell align="left">80</TableCell>
              <TableCell align="left">80</TableCell>
              <TableCell align="left">80</TableCell>
              {/* end map score average*/}
            </TableRow>

            {/* start map user*/}
            <TableRow>
              <TableCell
                colSpan={2}
                align="left"
                sx={{
                  position: "sticky",
                  left: 0,
                  zIndex: 99,
                  background: "#FFFFFF",
                }}
              >
                <Box className={classes.avatar_box}>
                  <Avatar
                    variant="primary"
                    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRWOdZJlzGgsaxupEmN1jGhRIn41F0Y-0ZR7A&usqp=CAU"
                    sx={{ mr: "20px", display: { xs: "none", md: "block" } }}
                  />
                  <Typography variant="primary" width="100%">
                    Dyna
                  </Typography>
                </Box>
              </TableCell>

              {/* start map user score*/}
              <TableCell
                align="left"
                sx={{
                  "& .MuiTableCell-root": {
                    borderBottom: "0.25px solid #C4C4C4",
                  },
                }}
              >
                80
              </TableCell>
              <TableCell
                align="left"
                sx={{
                  "& .MuiTableCell-root": {
                    borderBottom: "0.25px solid #C4C4C4",
                  },
                }}
              >
                80
              </TableCell>
              <TableCell
                align="left"
                sx={{
                  "& .MuiTableCell-root": {
                    borderBottom: "0.25px solid #C4C4C4",
                  },
                }}
              >
                80
              </TableCell>
              <TableCell
                align="left"
                sx={{
                  "& .MuiTableCell-root": {
                    borderBottom: "0.25px solid #C4C4C4",
                  },
                }}
              >
                80
              </TableCell>
              <TableCell
                align="left"
                sx={{
                  "& .MuiTableCell-root": {
                    borderBottom: "0.25px solid #C4C4C4",
                  },
                }}
              >
                80
              </TableCell>
              <TableCell
                align="left"
                sx={{
                  "& .MuiTableCell-root": {
                    borderBottom: "0.25px solid #C4C4C4",
                  },
                }}
              >
                80
              </TableCell>
              {/* end map user score*/}
            </TableRow>
            {/* end map user*/}
          </TableBody>
        </Table>
      </Box>
      {overflow ? (
        <Box className={classes.icon_button}>
          <IconButton onClick={handleMoveRight}>
            <ArrowForwardIosRoundedIcon />
          </IconButton>
          <IconButton sx={{ mt: "10px" }} onClick={handleMoveLeft}>
            <ArrowBackIosRoundedIcon />
          </IconButton>
        </Box>
      ) : null}
    </Box>
  );
};

export default GradeTable;

GradeTable.propTypes = {};

GradeTable.defaultProps = {};
