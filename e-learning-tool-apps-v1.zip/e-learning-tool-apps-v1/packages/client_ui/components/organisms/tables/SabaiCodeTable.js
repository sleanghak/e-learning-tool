import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Typography,
  Paper,
  TableRow,
  TableHead,
  TableCell,
  TableBody,
  Table,
  Box,
  Avatar,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import { toDateFormat, UTCToCambodia } from "../../../utils/func/toDateFormat";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    overflowX: "auto",
    margin: "0px auto",
  },
  container: {
    "& .MuiTableCell-root": {
      borderBottom: "0.5px solid #7D7878",
    },
  },
  toolBar: {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "center",
    padding: "20px",
  },
  tableHead: {
    "& .MuiTableCell-head": {
      minWidth: 150,
      borderTop: "0.5px solid #7D7878",
      fontFamily: "Arial",
      fontWeight: "700",
      fontSize: 18,
      [theme.breakpoints.down("md")]: {
        fontSize: 15,
      },
      [theme.breakpoints.down("sm")]: {
        fontSize: 15,
      },
    },
  },
  tableBody: {
    "& .MuiTableCell-body": {
      fontFamily: "Arial",
      fontWeight: "400",
      fontSize: 18,
      [theme.breakpoints.down("md")]: {
        fontSize: 15,
      },
      [theme.breakpoints.down("sm")]: {
        fontSize: 15,
      },
    },
  },
}));

const SabaiCodeTable = ({ data }) => {
  console.log(data);
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Box className={classes.container}>
        <Box className={classes.toolBar}>
          <Typography variant="title" sx={{ mt: "10px" }}>
            Teachers
          </Typography>
        </Box>
        <Table>
          <TableHead>
            <TableRow className={classes.tableHead}>
              <TableCell colSpan={2}>Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Phone Number</TableCell>
            </TableRow>
          </TableHead>
          <TableBody className={classes.tableBody}>
            {data.coachIds.map((item, index) => {
              return (
                <TableRow
                  key={index}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell sx={{ width: 80 }} align="left">
                    <Avatar variant="primary" src={item.profile} />
                  </TableCell>
                  <TableCell align="left">{item.name}</TableCell>
                  <TableCell align="left">{item.email}</TableCell>
                  <TableCell align="left">{item.tels[0]}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
        <Box className={classes.toolBar}>
          <Typography variant="title" sx={{ mt: "10px" }}>
            Students
          </Typography>
          <Box sx={{ flexGrow: 1 }} />
          <Typography variant="primary" sx={{ fontSize: 15, mt: "10px" }}>
            {data.studentIds.length} Students
          </Typography>
        </Box>
        <Table>
          <TableHead>
            <TableRow className={classes.tableHead}>
              <TableCell colSpan={2}>Name</TableCell>
              <TableCell>Age</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Phone Number</TableCell>
            </TableRow>
          </TableHead>
          <TableBody className={classes.tableBody}>
            {data.studentIds.map((item, index) => {
              return (
                <TableRow
                  key={index}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell sx={{ width: 80 }} align="left">
                    <Avatar variant="primary" src={item.profile} />
                  </TableCell>
                  <TableCell align="left">{item.name}</TableCell>
                  <TableCell align="left">
                    {toDateFormat(UTCToCambodia(item.dateOfBirth)).toString()}
                  </TableCell>
                  <TableCell align="left">{item.email}</TableCell>
                  <TableCell align="left">{item.tels[0]}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Box>
    </div>
  );
};

export default SabaiCodeTable;

SabaiCodeTable.propTypes = {
  data: PropTypes.array.isRequired,
};

SabaiCodeTable.defaultProps = {};
