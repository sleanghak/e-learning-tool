import React from "react";
import { Avatar, IconButton, Stack, Typography } from "@mui/material";
import { convertFilePathToURL } from "../../../utils/func/s3";
import DeleteIcon from "@mui/icons-material/Delete";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  container: {
    position: "relative",
    "& .icon": {
      display: "none",
    },
    "& :hover": {
      "& .icon": {
        display: "inline-block",
      },
    },
  },
}));
const Message = ({
  message,
  user,
  senderProfile,
  receiverProfile,
  divRef,
  deleteMsg,
}) => {
  // console.log(deleteMsg);
  const [data, setData] = React.useState(message);
  const classes = useStyles();
  const ifSender = message.sender === user._id;
  console.log("Message", message);
  React.useEffect(() => {
    convertFilePathToURL(message).then((data) => {
      // console.log("Cover", data);
      setData(data);
    });
  }, []);
  return (
    <Stack
      className={classes.container}
      sx={{ m: 0.5 }}
      spacing={2}
      direction={ifSender ? "row-reverse" : "row"}
      ref={divRef}
    >
      <Avatar src={ifSender ? senderProfile : receiverProfile} />
      <Typography
        sx={{
          backgroundColor: ifSender ? "lightcoral" : "lightblue",
          borderRadius: 1,
          p: 1,
          maxWidth: "75%",
        }}
      >
        {data.msg}

        {ifSender && (
          <IconButton className="icon" onClick={deleteMsg}>
            <DeleteIcon color={"warm"} />
          </IconButton>
        )}
      </Typography>
    </Stack>
  );
};

export default Message;
