import { Alert, Stack } from "@mui/material";
const NoMessage = ({ message }) => {
  return (
    <Stack>
      <Alert sx={{ width: "100%" }} severity="info">
        {message}
      </Alert>
    </Stack>
  );
};

export default NoMessage;
