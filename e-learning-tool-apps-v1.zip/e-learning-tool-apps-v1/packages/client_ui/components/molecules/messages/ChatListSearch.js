import React, { useCallback, useRef, useState } from "react";
import { makeStyles } from "@mui/styles";
import { Scrollbars } from "react-custom-scrollbars";
import PropTypes from "prop-types";
import { green } from "@mui/material/colors";
import {
  Typography,
  IconButton,
  Paper,
  Box,
  Stack,
  CircularProgress,
  ButtonBase,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import fetcher from "./../../../utils/func/api/fetcher";
import { convertFilePathToURL } from "./../../../utils/func/s3";
import { useRouter } from "next/router";
const useStyles = makeStyles((theme) => ({
  searchInput: {
    height: 40,
    margin: 6,
    border: " 1px solid #ccc",
    borderRadius: 20,
    backgroundColor: "#ffffff",
    zIndex: 10,
  },
  input: {
    border: 0,
    width: "75%",
    height: 35,
    outline: "none",
    marginLeft: 8,
  },
}));

export default function ChatListSearch({ chats, setChats }) {
  const classes = useStyles();
  const searchRef = useRef(null);
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(false);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const onChange = useCallback(async (e) => {
    const query = e.target.value;
    setQuery(query);
    let data;
    setLoading(true);
    try {
      if (query.length) {
        data = await fetcher(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/search/${query}`
        );
        data = await convertFilePathToURL(data);
        // console.log(data);
        setResults(data);
        setLoading(false);
      } else {
        setResults([]);
        setLoading(false);
      }
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  }, []);
  const onFocus = useCallback(() => {
    console.log("Active");
    setActive(true);

    window.addEventListener("click", onClick);
  }, []);
  const onClick = useCallback((e) => {
    if (searchRef.current && !searchRef.current.contains(e.target)) {
      setActive(false);
      window.removeEventListener("click", onClick);
    }
  }, []);
  const addChat = (result) => {
    const alreadyInChat =
      chats.length > 0 &&
      chats.filter((chat) => chat.messageWith === result._id).length > 0;

    if (alreadyInChat) {
      return router.push(`/messages?message=${result._id}`);
    }
    //
    else {
      const newChat = {
        messageWith: result._id,
        name: result.name,
        coverFileName: result.coverFileName,
        lastMessage: "",
        date: Date.now(),
      };

      setChats((prev) => [newChat, ...prev]);

      return router.push(`/messages?message=${result._id}`);
    }
  };
  return (
    <>
      <div className={classes.searchInput}>
        <Stack direction={"row"} alignItems="center">
          <Box sx={{ position: "relative" }}>
            <IconButton aria-label="save" color="primary">
              <SearchIcon />
            </IconButton>
            {loading && (
              <CircularProgress
                size={30}
                sx={{
                  color: green[500],
                  position: "absolute",
                  top: 3,
                  left: 5,
                  zIndex: 1,
                }}
              />
            )}
          </Box>
          <input
            className={classes.input}
            ref={searchRef}
            type="text"
            name="data-map"
            placeholder="search connector"
            onChange={onChange}
            onFocus={onFocus}
            value={query}
          />
        </Stack>
      </div>

      {active && results.length > 0 && (
        <Scrollbars style={{ height: "25vh" }}>
          <List>
            {results.map((item, ind) => {
              return (
                <ListItem key={ind} onClick={() => addChat(item)}>
                  <ListItemAvatar>
                    <Avatar src={item.coverFileName} alt={item.email} />
                  </ListItemAvatar>
                  <ListItemText primary={item.name} />
                </ListItem>
              );
            })}
          </List>
        </Scrollbars>
      )}
    </>
  );
}
