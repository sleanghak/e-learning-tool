import { Avatar, IconButton, InputBase, Stack, TextField } from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import React from "react";
const InputMessage = ({ profile, sendMsg }) => {
  const [text, setText] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const sendMsgToUser = async (e) => {
    setLoading(true);
    e.preventDefault();
    try {
      await sendMsg(text);
      setLoading(false);
      e.target.reset();
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };
  return (
    <form onSubmit={sendMsgToUser}>
      <Stack sx={{ m: 1 }} spacing={1} direction={"row"} alignItems="center">
        <Avatar src={profile} />
        <InputBase
          placeholder="Write the message"
          multiline
          maxRows={3}
          sx={{ pl: 1, borderRadius: 1, backgroundColor: "lightblue" }}
          fullWidth
          onChange={(e) => setText(e.target.value)}
        />
        <IconButton type="submit">
          {loading ? <>Loading...</> : <SendIcon />}
        </IconButton>
      </Stack>
    </form>
  );
};

export default InputMessage;
