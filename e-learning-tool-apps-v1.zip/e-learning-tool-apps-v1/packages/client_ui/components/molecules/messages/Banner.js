import { Avatar, Box, Stack, Typography } from "@mui/material";
import React from "react";
import { convertFilePathToURL } from "./../../../utils/func/s3";
const BannerChat = ({ user }) => {
  // console.log(user);
  const [profile, setProfile] = React.useState({});
  React.useEffect(() => {
    if (user) {
      convertFilePathToURL(user).then((data) => {
        setProfile(data);
      });
    }
  }, [user]);
  return (
    <Stack direction={"row"} spacing={2} alignItems="center">
      <Avatar src={profile.coverFileName} />
      <Stack>
        <Typography sx={{ fontWeight: "bold" }}>{profile.name}</Typography>
        <Typography sx={{ fontWeight: "bold" }}>{profile.email}</Typography>
      </Stack>
    </Stack>
  );
};

export default BannerChat;
