import { Avatar, Box, Stack, Typography } from "@mui/material";
import React from "react";
const ProfileChat = ({ user }) => {
  return (
    <Stack direction={"row"} spacing={2} alignItems="center">
      <Avatar sx={{ width: 50, height: 50 }} src={user.coverFileName} />
      <Stack>
        <Typography sx={{ fontWeight: "bold" }}>{user.name}</Typography>
        <Typography sx={{ fontWeight: "bold" }}>{user.email}</Typography>
      </Stack>
    </Stack>
  );
};

export default ProfileChat;
