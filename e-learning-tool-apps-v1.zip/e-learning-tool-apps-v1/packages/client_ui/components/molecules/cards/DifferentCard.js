import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Box,
    Typography,

} from '@mui/material';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        display: 'flex',
        justifyContent: 'center'
    },
    card: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        maxWidth: 1200,
        width: '100%',
        [theme.breakpoints.down("sm")]: {
            flexWrap: 'wrap',
            justifyContent: 'center',
        },
    },
    different_title: {
        maxWidth: 500,
        [theme.breakpoints.down("sm")]: {
            margin: 10,
        },
    },
    different_image: {
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minWidth: 300,
        minHeight: 300,
        [theme.breakpoints.down("md")]: {
            minWidth: 250,
            minHeight: 250,
            margin: 20,
        },
        [theme.breakpoints.down("sm")]: {
            minWidth: 200,
            minHeight: 200,
            margin: 10,
        },
    }
}));

const DifferentCard = ({
    flip,
    title,
    description,
    imagePath,
}) => {
    const classes = useStyles();
    return (
        <Box className={classes.root}>
            {
                flip ?
                    <Box className={classes.card}>
                        <Box className={classes.different_title} order={{ xs: 1, sm: 2 }}>
                            <Typography sx={{ fontSize: '25px', fontWeight: 'blod', mb: { xs: '10px', md: '20px' } }}>
                               {title} 
                            </Typography>
                            <Typography sx={{ fontSize: '18px' }}>
                                {description}
                            </Typography>
                        </Box>
                        <Box className={classes.different_image} sx={{ backgroundImage: `url(${imagePath})` }} order={{ xs: 2, sm: 1 }} />
                    </Box>
                    :
                    <Box className={classes.card} >
                        <Box className={classes.different_title}>
                            <Typography sx={{ fontSize: '25px', fontWeight: 'blod', mb: { xs: '10px', md: '20px' } }}>
                                {title}
                            </Typography>
                            <Typography sx={{ fontSize: '18px' }}>
                                {description}
                            </Typography>
                        </Box>
                        <Box className={classes.different_image} sx={{ backgroundImage: `url(${imagePath})` }} />
                    </Box >
            }
        </Box>
    );
}

export default DifferentCard;

DifferentCard.propTypes = {
    flip: PropTypes.bool,
    title: PropTypes.string.isRequired,
    description:  PropTypes.string.isRequired,
    imagePath:  PropTypes.string.isRequired,
};

DifferentCard.defaultProps = {
    flip: false,
    title: 'We only teach the latest',
    description: 'We only teach the latest, most relevant technologies. Leveraging our network, we connect our talented students with future employers.',
    imagePath: './images/personal_attention.png',
};