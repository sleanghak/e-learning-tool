import React, { useState } from "react";
import { useRouter } from "next/router";
import PropTypes from "prop-types";
import {
  Avatar,
  AvatarGroup,
  Box,
  Card,
  Stack,
  Typography,
} from "@mui/material";
import convertFilePathToURL from "../../../utils/func/s3/convertFilePathToURL";
import { makeStyles } from "@mui/styles";
import Link from "next/link";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    borderRadius: 5,
    cursor: "pointer",
  },
  cover: {
    width: "100%",
    height: 180,
    backgroundPosition: "center",
    backgroundSize: "cover",
    boxShadow: "none",
  },
  content: {
    padding: 25,
  },
  team_avatar: {
    justifyContent: "center",
  },
}));

const StudentProjectCard = ({ cover, title, team, projectId, isDynamic }) => {
  const classes = useStyles();
  const router = useRouter();
  const [data, setData] = React.useState({});
  React.useEffect(async () => {
    // console.log(team);
    convertFilePathToURL({
      coverFileName: cover,
      title: title,
      team: await convertFilePathToURL(team),
    }).then((data) => {
      setData(data);
    });
  }, []);
  return (
    <Box>
      <a href={`/student-work/${projectId}`}>
        <Card className={classes.root}>
          <Box
            className={classes.cover}
            sx={{ backgroundImage: `url('${data.coverFileName}')` }}
          />
          <Box className={classes.content}>
            <Stack spacing="25px" direction="column">
              <Typography variant="title">{title}</Typography>
              <Typography variant="secondary" textAlign="center">
                Team
              </Typography>
              <AvatarGroup max={4} className={classes.team_avatar}>
                {data?.team?.map((student, index) => {
                  return (
                    <Avatar
                      key={index}
                      alt={student.name}
                      src={student.coverFileName}
                    />
                  );
                })}
              </AvatarGroup>
            </Stack>
          </Box>
        </Card>
      </a>
    </Box>
  );
};

export default StudentProjectCard;

StudentProjectCard.propTypes = {
  cover: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  team: PropTypes.array.isRequired,
  projectId: PropTypes.string.isRequired,
};

StudentProjectCard.defaultProps = {};
