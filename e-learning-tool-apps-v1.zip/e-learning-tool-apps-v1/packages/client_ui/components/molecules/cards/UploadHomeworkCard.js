import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import { Box, Card, Typography } from "@mui/material";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    paddingBottom: 50,
    borderBottom: "1px solid #000000",
    marginTop: 50,
  },
  card: {
    padding: 25,
    borderRadius: 5,
    boxShadow: "none",
    width: "100%",
    width: "100%",
    display: "flex",
  },
  upload_image: {
    height: 80,
    width: 300,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "cover",
    marginRight: 35,
  },
}));

const UplaodHomeworkCard = ({ title, instruction, url }) => {
  const classes = useStyles();

  return (
    <Box className={classes.root}>
      <Card className={classes.card}>
        <Box
          sx={{ backgroundImage: `url(${url})` }}
          className={classes.upload_image}
        />
        <Box>
          <Typography sx={{ fontSize: 25 }}>{title}</Typography>
          <Typography sx={{ fontSize: 15, color: "#7D7878" }}>
            {instruction}
          </Typography>
        </Box>
      </Card>
    </Box>
  );
};

export default UplaodHomeworkCard;

UplaodHomeworkCard.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
};

UplaodHomeworkCard.defaultProps = {
  title: "Homework",
  description: "Word",
  url: "http://mrsspeers.weebly.com/uploads/1/7/4/2/17429923/829166_orig.png",
};
