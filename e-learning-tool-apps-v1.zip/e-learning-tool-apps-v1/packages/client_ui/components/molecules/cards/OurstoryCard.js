import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Box,
    Card,
    Typography,
} from '@mui/material';
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        background: '#FFFFFF',
        boxShadow: '0px 0px 4px rgba(0, 0, 0, 0.25)',
        minWidth: 270,
        height: 320,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '40px 25px',
        [theme.breakpoints.down('sm')]: {
            minWidth: '100%',
            height: 'auto',
            margin: '10px 0px'
        }
    },
    image: {
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        width: 70,
        height: 70,
        // [theme.breakpoints.down('sm')]: {
        //     width: 50,
        //     height: 50,
        // }
    },
    title: {
        marginTop: 30,
        fontSize: 25,
    },
    description: {
        marginTop: 30,
        textAlign: 'center'
    }
}));

const OurstoryCard = ({
    imagePath,
    title,
    description,
}) => {
    const classes = useStyles();
    return (
        <Box>
            <Card className={classes.root}>
                <Box className={classes.image} sx={{ backgroundImage: `url(${imagePath})` }} />
                <Typography className={classes.title}>
                    {title}
                </Typography>
                <Typography className={classes.description}>
                    {description}
                </Typography>
            </Card>
        </Box>
    );
}

export default OurstoryCard;

OurstoryCard.propTypes = {
    imagePath: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
};

OurstoryCard.defaultProps = {
    imagePath: './images/vision.png',
    title: 'VISION',
    description: 'To develop the next generation of Cambodian leaders in technology and innovation.',
};