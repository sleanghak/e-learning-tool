import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import { Box, Card, Typography, Button, ButtonBase } from "@mui/material";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import { uploadFile } from "../../../utils/func/s3";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import { Files } from "../../atoms/files";
import {
  findFileExtension,
  convertFilePathToURL,
} from "./../../../utils/func/s3";
import deleteDataFunc from "./../../../utils/func/api/deleteDataFunc";
import Link from "next/link";
const useStyles = makeStyles((theme) => ({
  root: {
    padding: 22.5,
    borderRadius: 5,
    boxShadow: "none",
    maxWidth: 350,
    width: "100%",
    marginTop: 100,
  },
  head: {
    display: "flex",
    alignItems: "center",
  },
  btn_outline: {
    marginTop: 20,
    border: "0.5px solid #000000",
    width: "100%",
    borderRadius: 5,
  },
  btn_contain: {
    marginTop: 20,
    width: "100%",
  },
}));

const StudentWorkCard = ({ homework }) => {
  const classes = useStyles();
  const [progress, setProgress] = React.useState(0);
  const [file, setFile] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const [submission, setSubmission] = React.useState({});
  const [msg, setMsg] = React.useState("");
  // /api/v1/student/classwork/:classworkId/submission/:submissionId
  const handleSubmitHomework = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const form = e.target.elements;
      const res = await uploadFile(
        "submission",
        form.fileName.files[0],
        setProgress,
        setMsg
      );
      const data = await postDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/student/classwork/${homework._id}`,
        {
          fileName: res.key,
        }
      );
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.log(error);
    }
  };
  const handleRemoveSubmission = async () => {
    try {
      const res = await deleteDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/student/classwork/${homework._id}/submission/${submission._id}`
      );
      setSubmission({});
      console.log(res);
    } catch (error) {
      console.log(error);
    }
  };
  React.useEffect(() => {
    console.log(homework);
    convertFilePathToURL(homework.submissions).then((data) => {
      setSubmission(data);
      console.log(data);
    });
  }, []);

  return (
    <Box sx={{ minWidth: 250 }}>
      <form onSubmit={handleSubmitHomework}>
        <Card className={classes.root}>
          <Box className={classes.head}>
            <Typography sx={{ fontSize: "17px" }}>Your Work</Typography>
            <Box sx={{ flexGrow: 1 }} />
            <Typography sx={{ fontSize: "15px", color: "primary" }}>
              Assigned
            </Typography>
          </Box>
          <input
            onChange={(e) => setFile(e.target.files[0])}
            id="fileName"
            name="fileName"
            type={"file"}
            hidden
            required
          />
          {file && (
            <Files icon={findFileExtension(file.name)}>
              <Typography>file name</Typography>
            </Files>
          )}

          {Object.keys(submission).length > 0 ? (
            <>
              <Box>
                <Button
                  sx={{
                    width: "100%",
                    mt: 1,
                    mb: 1,
                    borderRadius: 1,
                    border: "1px solid #000000",
                    p: 4,
                  }}
                  href={submission.fileName}
                >
                  Preview
                </Button>
              </Box>
              <ButtonBase onClick={handleRemoveSubmission}>
                <Typography color="error">Unsubmit </Typography>
              </ButtonBase>
            </>
          ) : (
            <Box>
              <Button
                variant="outlined"
                startIcon={<AddRoundedIcon />}
                className={classes.btn_outline}
              >
                <label htmlFor="fileName">
                  <Typography sx={{ fontSize: "15px", minWidth: 110 }}>
                    Add or Create
                  </Typography>
                </label>
              </Button>
              <Button
                type="submit"
                variant="contained"
                className={classes.btn_contain}
                disabled={loading}
              >
                <Typography sx={{ fontSize: "15px" }}>
                  {loading ? `Uploading ... ${progress}%` : "Mark as done"}
                </Typography>
              </Button>
            </Box>
          )}
        </Card>
      </form>
    </Box>
  );
};

export default StudentWorkCard;

StudentWorkCard.propTypes = {};

StudentWorkCard.defaultProps = {};
