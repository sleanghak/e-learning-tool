import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Card,
  Box,
  Avatar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Stack,
  Divider,
  ButtonBase,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import AssignmentRoundedIcon from "@mui/icons-material/AssignmentRounded";
import MoreVertRoundedIcon from "@mui/icons-material/MoreVertRounded";
import SkeletonTitle from "../../atoms/skeletons/SkeletonTitle";
import SkeletonText from "../../atoms/skeletons/SkeletonText";
import SkeletonIcon from "../../atoms/skeletons/SkeletonIcon";
import { toDateFormat, toTime } from "../../../utils/func/toDateFormat";
import { Accordion, AccordionSummary, AccordionDetails } from "@mui/material";
import Link from "next/link";
import { compareCurrentDate } from "../../../utils/func/toDateFormat";
const useStyles = makeStyles((theme) => ({
  root: {
    margin: "0 auto",
    maxWidth: 1200,
    width: "100%",
  },
  container: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
  },
  avatar: {
    width: 45,
    height: 45,
    backgroundColor: "#7D7878",
  },
  title_box: {
    marginLeft: 50,
    [theme.breakpoints.down("md")]: {
      marginLeft: 5,
    },
  },

  button_icon: {
    color: "black",
    opacity: 0.5,
    "&:hover ": {
      opacity: 1,
    },
  },
  menuItem: {
    width: "100%",
    marginRight: 20,
  },
}));

const ClassWorkCard = ({ data, loading, editFunc, deleteFunc }) => {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
  return (
    <div className={classes.root}>
      {loading ? (
        <Card>
          <Box className={classes.container}>
            <Box>
              <SkeletonIcon size={55} />
            </Box>
            <Box className={classes.title_box}>
              <Typography variant="title">
                <SkeletonTitle width={150} />
              </Typography>
            </Box>
          </Box>
        </Card>
      ) : (
        <Accordion
          expanded={expanded == "panel1"}
          onChange={handleChange("panel1")}
        >
          <AccordionSummary
            sx={{ display: "block", p: { xs: "10px 15px", sm: "15px" } }}
          >
            <Box sx={{ display: "flex", alignItems: "center", width: "100%" }}>
              <Avatar
                className={classes.avatar}
                sx={{ display: { xs: "none", sm: "flex" }, mr: "20px" }}
              >
                <AssignmentRoundedIcon sx={{ fontSize: 25 }} />
              </Avatar>
              <Typography
                variant="title"
                noWrap
                sx={{ fontSize: { xs: "16px", sm: "20px" } }}
              >
                {data?.name}
              </Typography>
              <Box flex={1} />
              <Typography
                color={
                  compareCurrentDate(data?.deadline) ? "secondary" : "primary"
                }
                sx={{ minWidth: 170, textAlign: "right", ml: '10px' }}
              >
                Due {toDateFormat(data?.deadline)} {toTime(data?.deadline)}
              </Typography>
            </Box>
          </AccordionSummary>
          <AccordionDetails>
            <Divider />
            <Typography sx={{ p: 2 }}>{data?.instruction}</Typography>
            <Divider />
            <ButtonBase sx={{ p: 1 }}>
              <Link href={`/classes/homework/${data?._id}`}>
                <Typography color="primary">View Assignment </Typography>
              </Link>
            </ButtonBase>
          </AccordionDetails>
        </Accordion>
      )}
    </div>
  );
};

export default ClassWorkCard;

ClassWorkCard.propTypes = {
  title: PropTypes.string.isRequired,
  date: PropTypes.string.isRequired,
  loading: PropTypes.bool.isRequired,
};

ClassWorkCard.defaultProps = {
  title: "Homework",
  date: "02 Feb 2022",
  loading: false,
};
