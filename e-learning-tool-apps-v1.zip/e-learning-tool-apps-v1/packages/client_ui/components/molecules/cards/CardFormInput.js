import React, { Children } from "react";
import PropTypes from "prop-types";
import {
    Box,
    Card,

} from "@mui/material";
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        display: 'flex',
        justifyContent: 'center'
    },
    card: {
        boxShadow: '0px 0px 4px rgba(0, 0, 0, 0.25)',
        border: 'none',
        borderRadius: 20,
        padding: 40,
        width: '100%',
        [theme.breakpoints.down("md")]: {
            padding: 30,
        },
        [theme.breakpoints.down("sm")]: {
            padding: 25,
        },
    }

}));

const CardFormInput = ({
    children,
 }) => {

    const classes = useStyles();

    return (
        <Box className={classes.root}>
            <Card className={classes.card}>
                {children}
            </Card>
        </Box>
    );
};

export default CardFormInput;

CardFormInput.propTypes = {
    
};

CardFormInput.defaultProps = {
};
