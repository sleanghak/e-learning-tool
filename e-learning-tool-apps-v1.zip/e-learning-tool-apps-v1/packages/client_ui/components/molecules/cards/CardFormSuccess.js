import React from "react";
import PropTypes from "prop-types";
import { Box, Card, Divider, Stack, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  card: {
    boxShadow: "0px 0px 4px rgba(0, 0, 0, 0.25)",
    border: "none",
    borderRadius: 20,
    padding: 40,
    textAlign: "center",
  },
}));

const CardFormSuccess = ({}) => {
  const classes = useStyles();

  return (
    <Box className={classes.root}>
      <Card className={classes.card}>
        <Stack spacing={3} direction="column">
          {/* sponsor */}
          <Typography
            sx={{
              fontSize: 30,
              fontWeight: 700,
              color: "#F8A01A",
            }}
          >
            Application for SabaiCode Bootcamp
          </Typography>
          <Divider />
          {/* title */}
          <Box>
            <img
              src="/images/form-sucess.png"
              alt="sucess-image"
              style={{
                width: 80,
                height: "auto",
              }}
            />
          </Box>
          <Typography
            sx={{
              fontSize: 25,
              fontWeight: 700,
            }}
          >
            Thanks You!
          </Typography>
          <Typography sx={{ fontSize: 20 }}>
            Your application was successfully submitted.
          </Typography>
          <Typography>
            We&apos;ll contact you when a decision is made.
          </Typography>
        </Stack>
      </Card>
    </Box>
  );
};

export default CardFormSuccess;

CardFormSuccess.propTypes = {};

CardFormSuccess.defaultProps = {};
