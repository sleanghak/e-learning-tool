import React from "react";
import Link from 'next/link'
import PropTypes from "prop-types";
import {
    Box,
    Card,
    Divider,
    Stack,
    Typography,

} from "@mui/material";
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
    },
    card: {
        boxShadow: '0px 0px 4px rgba(0, 0, 0, 0.25)',
        border: 'none',
        borderRadius: 20,
        padding: 40,
        textAlign: 'center'

    }

}));

const CardFormHeader = ({ }) => {

    const classes = useStyles();

    return (
        <Box className={classes.root}>
            <Card className={classes.card}>
                <Stack
                    spacing={3}
                    direction='column'
                >
                    {/* sponsor */}
                    <Typography
                        sx={{
                            fontSize: 30,
                            fontWeight: 700,
                            color: '#F8A01A'
                        }}
                    >
                        Applicaton period ends on 17 July 2021
                    </Typography>
                    <Divider />
                    {/* title */}
                    <Typography
                        sx={{
                            fontSize: 25,
                            fontWeight: 700,
                            color: '#F81818'
                        }}
                    >
                        SabaiCode Full Stack Developer Bootcamp
                    </Typography>
                    <Typography
                        sx={{
                            fontSize: 20,
                            color: '#00A3FF'
                        }}
                    >
                        <Link href='https://docs.google.com/document/d/1Q8XBu1XUc5scqFB4jS-ZK6iAaSdM4dBT/edit?usp=sharing&ouid=112453956126356188001&rtpof=true&sd=true'>
                            <a target="_blank"> check here for Frequently Asked Question </a>
                        </Link>
                    </Typography>
                </Stack>
            </Card>
        </Box>
    );
};

export default CardFormHeader;

CardFormHeader.propTypes = {
};

CardFormHeader.defaultProps = {
};
