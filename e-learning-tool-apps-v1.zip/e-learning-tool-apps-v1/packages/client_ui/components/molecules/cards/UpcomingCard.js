import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import { Box, Stack, Typography, Button } from "@mui/material";
import Image from "next/image";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    borderRadius: 5,
    border: "0.5px solid #000000",
    boxShadow: "none",
    padding: 18,
  },
}));

const UpcomingCard = ({ onClick }) => {
  const classes = useStyles();
  return (
    <Box className={classes.root}>
      <Stack sx direction={"row"} justifyContent={"space-between"} flexWrap='wrap'>

        <Typography variant="h6">Certificate</Typography>

        <Button onClick={onClick} size="small" variant="contained">
          Claim
        </Button>
      </Stack>

      <Box sx={{ width: 55, margin: "0px auto", mt: 3 }}>
        <Image
          alt="certificate"
          src="/icons/certificate_icon_active.png"
          width={55}
          height={55}
        />
      </Box>
      <Typography align="center">
        We are happy to present your certificate to <br />
        you for this course.
      </Typography>
    </Box>
  );
};

export default UpcomingCard;

UpcomingCard.propTypes = {
  title: PropTypes.string.isRequired,
  setion: PropTypes.string.isRequired,
  titleButton: PropTypes.string.isRequired,
};

UpcomingCard.defaultProps = {
  title: "Upcoming",
  setion: "no work due soon!",
  titleButton: "Veiw all",
};
