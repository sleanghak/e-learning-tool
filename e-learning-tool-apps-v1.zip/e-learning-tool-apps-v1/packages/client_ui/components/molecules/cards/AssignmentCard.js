
import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import PropTypes from "prop-types";
import { Card, CardHeader } from '@mui/material';
import { IconButton, Button, Avatar } from '@mui/material';
import { Menu, MenuItem } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import AssignmentIcon from '@mui/icons-material/Assignment';

const useStyles = makeStyles((them) => ({
    card: {
        width: '100%',
        border: '0.5px solid #000000',
    },
    avatar: {
        background: '#7D7878',
    },

}));


export default function AssignmentCard({
    title,
    subheader,
    submission
}) {
    const classes = useStyles();
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    return (
        <>
            <Card className={classes.card} >
                <div>
                    <Menu
                        id="basic-menu"
                        anchorEl={anchorEl}
                        open={open}
                        onClose={handleClose}
                        MenuListProps={{
                            'aria-labelledby': 'basic-button',
                        }}
                    >
                        <MenuItem onClick={handleClose}>Copy link</MenuItem>
                        <MenuItem onClick={handleClose}>Edit</MenuItem>
                    </Menu>
                </div>
                <CardHeader
                    avatar={
                        <Avatar className={classes.avatar}>
                            {submission}
                        </Avatar>
                    }
                    action={
                        <IconButton
                            aria-controls={open ? 'basic-menu' : undefined}
                            aria-haspopup="true"
                            aria-expanded={open ? 'true' : undefined}
                            onClick={handleClick}
                        >
                            <MoreVertIcon />
                        </IconButton>
                    }
                    // title="Mr.Nak posted a new assigment : Homework"
                    title={title}
                    // subheader="02 Feb 2022"
                    subheader={subheader}
                />
            </Card>
        </>
    );

};

AssignmentCard.propTypes = {
    title: PropTypes.string.isRequired,
    subheader: PropTypes.string.isRequired,
};
AssignmentCard.defaultProps = {
    title: "Mr.Nak posted a new assigment : Homework",
    subheader: "02 Feb 2022",
};
