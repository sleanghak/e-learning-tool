import React, { useState } from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import {
    Card,
    Box,
    Typography,
} from "@mui/material";

const useStyles = makeStyles((theme) => ({
    root: {
        maxWidth: 300,
        width: '100%',
        border: 'none',
        boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
        padding: '20px 50px',
        marginBottom: 30,
        [theme.breakpoints.down("md")]: {
            maxWidth: 250,
            padding: '20px 30px',
        },
        [theme.breakpoints.down("sm")]: {
            minWidth: 200,
            padding: '20px 20px',

        },
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',

    },
    text: {
        textAlign: 'center',
    }
}));

const NumStuCard = ({
    icon,
    title,
    num,
}) => {
    const classes = useStyles();
    return (
        <Card
            className={classes.root}
        >
            <Box>
                {icon}
            </Box>
            <Box sx={{ flexGrow: 1 }} />
            <Box
                className={classes.text}
            >
                <Typography
                    variant='primary'
                >
                    {title}
                    <br />
                    {num}
                </Typography>
            </Box>
        </Card>
    );
};

export default NumStuCard;

NumStuCard.propTypes = {
    icon: PropTypes.any,
    title: PropTypes.string.isRequired,
    num: PropTypes.number.isRequired,
};

NumStuCard.defaultProps = {
    title: 'all students',
    num: 100,
};
