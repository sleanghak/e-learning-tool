import React from "react";
import { makeStyles } from "@mui/styles";
import PropTypes from "prop-types";
import { Box, Typography } from "@mui/material";
import Image from "next/image";
const useStyles = makeStyles((theme) => ({
  root: {
    position: "relative",
  },
  title: ({isNoBackground})=>({
    fontWeight: "bold",
    color: isNoBackground? "#FFFFFF":theme.palette.primary.main,
    textShadow: "-45px -15px 1px rgba(0, 0, 0, 0.25)",
    position: "absolute",
    right: 75,
    top: 150,
  }),
  background: ({isNoBackground})=>({
      background: isNoBackground?theme.palette.primary.main:theme.palette.white.main,
      height: 250,
      width: "100%",
      position: "absolute",
      top: 50,
  })
  
}));

export default function HeaderTitle({ url, name, isNoBackground = true }) {
  const classes = useStyles({isNoBackground});
  return (
    <>
      <Box className={classes.root}>
         <Box className={classes.background}></Box>
        <Box sx={{ml:8}}>
          <Image
            width={400}
            height={350}
            src={url}
            alt="img_course"
            sx={{ ml: 5 }}
          />
        </Box>
        <Typography
          align="center"
          sx={{ fontSize: 60 }}
          className={classes.title}
        >
          {name}
        </Typography>
      </Box>
    </>
  );
}

HeaderTitle.propTypes = {
  url: PropTypes.string.isRequired,
  name: PropTypes.string,
};

HeaderTitle.defaultProps = {
  url: "https://www.imgacademy.com/themes/custom/imgacademy/images/helpbox-contact.jpg",
  name: "Leanghak",
};
