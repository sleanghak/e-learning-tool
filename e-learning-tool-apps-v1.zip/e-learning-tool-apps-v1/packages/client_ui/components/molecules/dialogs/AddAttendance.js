import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Card,
    Box,
    TextField,
    Typography,
    MenuItem,
    Button
} from '@mui/material';
import { makeStyles } from '@mui/styles';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import DesktopDatePicker from '@mui/lab/DesktopDatePicker';

const useStyles = makeStyles((theme) => ({
    root: {
        boxShadow: "none",
        padding: '30px 40px',
        [theme.breakpoints.down("md")]: {
            padding: '20px 30px',
        },
        [theme.breakpoints.down("sm")]: {
            padding: '10px 20px',
        },
    },
    title: {
        width: '100%',
        marginBottom: 30,
        [theme.breakpoints.down("md")]: {
            marginBottom: 20,
        },
    },
    input: {
        marginBottom: 20,
        color: '#7D7878',
        [theme.breakpoints.down("md")]: {
            marginBottom: 10,
        },
    },
    button: {
        diplay: 'flex',
        alignItems: 'center',
        textAlign: 'right',
        marginTop: 40,
        [theme.breakpoints.down("md")]: {
            marginTop: 30,
        },
        [theme.breakpoints.down("sm")]: {
            marginTop: 20,
        },
    }
}));

const AddAttendance = ({
    onClose,
}) => {
    const classes = useStyles();
    const [course, setCourse] = useState(null);
    const handleChangeCourse = (event) => {
        setCourse(event.target.value);
    };
    const [date, setDate] = useState(new Date());
    return (
        <Card
            className={classes.root}
        >
            <Box
                className={classes.title}
            >
                <Typography
                    variant='title'
                >
                    Attendance
                </Typography>
            </Box>
            <Box
                className={classes.body}
            >
                <form>
                    <TextField
                        className={classes.input}
                        fullWidth
                        variant='standard'
                        size='large'
                        type='text'
                        label='Class'
                        name='class'
                    />
                    <TextField
                        className={classes.input}
                        fullWidth
                        variant='standard'
                        size='large'
                        select
                        label='course'
                        name='course'
                        value={course}
                        onChange={handleChangeCourse}
                    >
                        <MenuItem value={1}>Course 1</MenuItem>
                        <MenuItem value={2}>Course 2</MenuItem>
                        <MenuItem value={3}>Course 3</MenuItem>
                        <MenuItem value={4}>Course 4</MenuItem>
                    </TextField>
                    <TextField
                        className={classes.input}
                        fullWidth
                        variant='standard'
                        size='large'
                        type='text'
                        label='Durations'
                        name='durations'
                    />
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                        <DesktopDatePicker
                            label="For desktop"
                            value={date}
                            minDate={new Date('2017-01-01')}
                            onChange={(newValue) => {
                                setDate(newValue);
                            }}
                            renderInput={(params) =>
                                <TextField
                                    className={classes.input}
                                    fullWidth
                                    variant='standard'
                                    size='large'
                                    type='text'
                                    label='Date'
                                    name='date'
                                    {...params}
                                />}
                        />
                    </LocalizationProvider>
                </form>
            </Box>
            <Box
                className={classes.button}
            >
                <Box>
                    <Button
                        variant='text'
                        onClick={onClose}
                        sx={{ fontFamily: 'Arial' }}
                    >
                        Cancel
                    </Button>
                    <Button
                        variant='text'
                        sx={{ fontFamily: 'Arial' }}
                    >
                        Submit
                    </Button>
                </Box>

            </Box>
        </Card>
    );
}

export default AddAttendance;

AddAttendance.propTypes = {

};

AddAttendance.defaultProps = {

};