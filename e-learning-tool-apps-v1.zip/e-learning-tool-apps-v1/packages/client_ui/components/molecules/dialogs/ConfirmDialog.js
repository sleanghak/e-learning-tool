import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Slide from "@material-ui/core/Slide";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import deleteDataFunc from "../../../utils/func/api/deleteDataFunc";
import PropTypes from 'prop-types'
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function ConfirmDialog({
  _id,
  open,
  onClose,
  message,
  desc,
  module,
  disable
}) {
  const handleDisableCourse = async () => {
    if (disable) {
      deleteDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/${module}/${_id}`
      ).then((res) => {
        console.log(res);
       
      });
    } else {
      updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/${module}/disable/${_id}`
      ).then((res) => {
        console.log(res);
        
      });
    }
  };
  return (
    <div>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={onClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">{message}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
           {desc}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose} color="secondary">
            Cancel
          </Button>
          <Button onClick={handleDisableCourse} color="primary">
            Ok
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

ConfirmDialog.propTypes={
  _id:PropTypes.string.isRequired,
  open:PropTypes.bool.isRequired,
  onClose:PropTypes.func,
  message:PropTypes.string.isRequired,
  desc:PropTypes.string,
  module:PropTypes.string.isRequired,
  disable:PropTypes.bool
}

ConfirmDialog.defaultProps={
  _id:'#$35q345',
  open:false,
  onClose:undefined,
  message:'message here',
  desc:'',
  module:'courses',
  disable:false
}
