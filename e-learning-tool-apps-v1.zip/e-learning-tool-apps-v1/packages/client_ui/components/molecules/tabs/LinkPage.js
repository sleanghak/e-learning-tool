import React from "react";
import {
    Box,
    Stack,  
} from "@mui/material";
import { makeStyles } from '@mui/styles';

// icon
import SignleLink from "./SignleLink";

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
    },

}));
const LinkPage = ({
    data,
}) => {
    const classes = useStyles();
    return (
        <Box className={classes.root}>
            <Stack direction='row' spacing={1} >
                {
                    data.map((item, index) => {
                        return (
                            <Box key={index}>
                                <SignleLink
                                    label={item.label}
                                    path={item.path}
                                    sublist={item.sublist}
                                />
                            </Box>
                        )
                    })
                }
            </Stack>
        </Box>
    );
};

export default LinkPage;
