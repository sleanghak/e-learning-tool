import HorizontalTabs from "./HorizontalTabs";

export {
    HorizontalTabs
}