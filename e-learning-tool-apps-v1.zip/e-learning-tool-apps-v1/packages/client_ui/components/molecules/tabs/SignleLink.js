import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from 'next/router';
import {
    Box,
    Menu,
    MenuItem,
    Typography,
} from "@mui/material";
import { makeStyles } from '@mui/styles';
import Fade from '@mui/material/Fade';

// icon
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';

const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
        justifyContent: 'center',
        cursor: 'pointer',
        borderRadius: 5,
        '&:hover': {
            background: '#f2f2f2',
        }
    },
    dropdown_content: {
        position: 'absolute',
        width: '100%',
        height: 500,
        background: 'red',
        left: 0,
        top: 135,
    },
    menu: {
        padding: 20
    }

}));
const SingleLink = ({
    label,
    path,
    sublist,
}) => {
    const router = useRouter();
    const classes = useStyles();
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    return (
        <Box>
            {
                sublist ?
                    <Box>
                        <Box
                            className={classes.root}
                            sx={{ p: '5px 5px 5px 10px', }}
                            aria-controls={open ? 'fade-menu' : undefined}
                            aria-haspopup="true"
                            aria-expanded={open ? 'true' : undefined}
                            onClick={handleClick}
                        >
                            <Typography>
                                {label}
                            </Typography>
                            <Box sx={{ ml: 1, display: 'flex' }}>
                                {open ? <ExpandLess sx={{ color: '#999999' }} /> : <ExpandMore sx={{ color: '#999999' }} />}
                            </Box>
                        </Box>
                        <Menu
                            MenuListProps={{
                                'aria-labelledby': 'fade-button',
                            }}
                            anchorEl={anchorEl}
                            open={open}
                            onClose={handleClose}
                            TransitionComponent={Fade}
                        >
                            {
                                sublist.map((item, index) => {
                                    return (
                                        <Link href={item.path} key={index}>
                                            <MenuItem onClick={handleClose} sx={{ m: '5px', borderRadius: '5px' }}>{item.label}</MenuItem>
                                        </Link>
                                    )
                                })
                            }
                        </Menu>
                    </Box>
                    :
                    <Box
                        className={classes.root}
                        sx={{ p: '5px 10px' }}
                        aria-controls={open ? 'fade-menu' : undefined}
                        aria-haspopup="true"
                        aria-expanded={open ? 'true' : undefined}
                        onClick={handleClick}
                    >
                        <Link href={path}>
                            <Typography>
                                {label}
                            </Typography>
                        </Link>
                    </Box>

            }

        </Box>
    );
};

export default SingleLink;
