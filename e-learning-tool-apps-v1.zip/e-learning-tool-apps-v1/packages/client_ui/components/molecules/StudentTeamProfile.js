import React from "react";
import PropTypes from "prop-types";
import { Avatar, Box, IconButton, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";
import FacebookIcon from "@mui/icons-material/Facebook";
import TelegramIcon from "@mui/icons-material/Telegram";
import EmailRoundedIcon from "@mui/icons-material/EmailRounded";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: "0px 20px 50px 20px",
  },
  profile: {
    display: "flex",
    alignItems: "center",
  },
  info: {
    marginLeft: 20,
    justifyContent: "left",
  },
  contact: {
    marginTop: 20,
  },
  icon_button: {
    opacity: 0.5,
    "&:hover": {
      opacity: 1,
    },
  },
}));

const StudentTeamProfile = ({ profileImage, name, position }) => {
  const classes = useStyles();
  return (
    <Box className={classes.root}>
      <Box className={classes.profile}>
        <Avatar src={profileImage} sx={{ width: "56px", height: "56px" }} />
        <Box className={classes.info}>
          <Box>
            <Typography variant="primary">{name}</Typography>
          </Box>
          <Box>
            <Typography variant="secondary">{position}</Typography>
          </Box>
        </Box>
      </Box>
      <Box className={classes.contact}>
        <IconButton className={classes.icon_button}>
          <EmailRoundedIcon />
        </IconButton>
        <IconButton className={classes.icon_button}>
          <FacebookIcon />
        </IconButton>
        <IconButton className={classes.icon_button}>
          <TelegramIcon />
        </IconButton>
      </Box>
    </Box>
  );
};

export default StudentTeamProfile;

StudentTeamProfile.propTypes = {
  profileImage: PropTypes.string,
  name: PropTypes.string.isRequired,
  position: PropTypes.string.isRequired,
};

StudentTeamProfile.defaultProps = {};
