import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Box,
  IconButton,
  Typography,
  Menu,
  MenuItem,
  TextField,
  Button,
  Stack,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import DateRangeRoundedIcon from "@mui/icons-material/DateRangeRounded";
import StaticDatePicker from "@mui/lab/StaticDatePicker";
import AddIcon from "@mui/icons-material/Add";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    // backgroundColor: "lightcyan",
    // padding: 8,
    // borderRadius: 8,
  },
  buttonIcon: {
    color: theme.palette.black.main,
    opacity: 0.5,
    "&:hover ": {
      opacity: 1,
    },
  },
  menuItem: {
    padding: 0,
  },
}));

const CourseTitles = ({ title, onOpenFunc }) => {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const [value, setValue] = useState(new Date());

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <div>
      <Box className={classes.root}>
        <Typography variant="title" className={classes.title}>
          {title}
        </Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Button
          startIcon={<AddIcon />}
          variant="outlined"
          onClick={onOpenFunc}
        >
          Join Class
        </Button>
        <Menu
          anchorEl={anchorEl}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "center",
          }}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleClose}
        >
          <MenuItem className={classes.menuItem}>
            <StaticDatePicker
              displayStaticWrapperAs="mobile"
              value={value}
              onChange={(newValue) => {
                setValue(newValue);
              }}
              renderInput={(params) => <TextField {...params} />}
            />
          </MenuItem>
        </Menu>
      </Box>
    </div>
  );
};

export default CourseTitles;

CourseTitles.propTypes = {
  title: PropTypes.string.isRequired,
};

CourseTitles.defaultProps = {
  title: "Classroom",
};
