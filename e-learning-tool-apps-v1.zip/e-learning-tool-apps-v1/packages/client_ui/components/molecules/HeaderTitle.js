import React from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@mui/styles";
import Image from "next/image";
import { Box, Typography, Stack, Button, Divider } from "@mui/material";
const useStyles = makeStyles((theme) => ({
  header_container: {
    height: "calc(100vh - 80px)",
    width: "100%",
    backgroundImage: `url('./images/header_tr.png'), url('./images/header_bl.png')`,
    backgroundPosition: "top right, bottom left",
    backgroundRepeat: "no-repeat",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  header_image: {
    width: "100%",
    height: "auto",
  },
  container: {
    maxWidth: 1400,
    width: "100%",
    display: "flex",
    flexDirection: "row",
  },
  content: {
    maxWidth: 500,
    width: "100%",
  },
  title: {
    color: "#5DE2E7",
    fontSize: 45,
    fontWeight: "bold",
    textTransform: "uppercase",
  },
  des: {
    color: "#433F3F",
  },
  header_img: {
    width: "100%",
    height: "auto",
  },
  button: {
    display: "flex",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  button_item: {
    marginBottom: 10,
  },
  divider: {
    height: 200,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
}));

export default function HeaderTitle({ text }) {
  const classes = useStyles();
  return (
    <Box>
      <Box className={classes.header_container}>
        <Box
          className={classes.container}
          sx={{ p: { xs: "0 20px", sm: "0 30px", md: "0 40px", lg: "0 50px" } }}
        >
          <Box className={classes.content}>
            <Stack spacing={{ xs: "20px", sm: "30px", md: "40px", lg: "50px" }}>
              <Box>
                <Typography className={classes.title}>SabaiCode</Typography>
              </Box>
              <Box>
                <Typography
                  className={classes.des}
                  sx={{ fontSize: { xs: "20px", sm: "25px" } }}
                >
                  {text}
                </Typography>
              </Box>
              <Box className={classes.button}>
                <Button variant="contained" className={classes.button_item}>
                  Get Start
                </Button>
                <Button variant="outlined" className={classes.button_item}>
                  Learn more
                </Button>
              </Box>
            </Stack>
          </Box>
          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: { xs: "none", md: "block" } }}>
            <Box sx={{ width: { md: "400px", lg: "500px" }, ml: "20px" }}>
              <img
                src="/images/header_img.png"
                className={classes.header_image}
              />
            </Box>
          </Box>
        </Box>
      </Box>
      <Box className={classes.divider}>
        <Divider sx={{ width: "50%", height: 4, background: "#5DE2E7" }} />
      </Box>
    </Box>
  );
}

HeaderTitle.propTypes = {};

HeaderTitle.defaultProps = {};
