import React from "react";
import { makeStyles } from "@mui/styles";
import { Box, Stack } from "@mui/material";

import { motion } from "framer-motion";

const useStyles = makeStyles((theme) => ({
    root: {
    },
    background: {
        height: 300,
        width: "100%",
    },
    container: {
        position: "absolute",
        left: '25%',
        top: 105,
    },
}));

export default function Collaboration() {
    const classes = useStyles();
    return (
        <Box className={classes.root}>
            <Box sx={{ backgroundImage: `url('/images/Background.jpg')`, backgroundPosition: 'center', backgroundSize: 'cover', width: '100%', padding: '20px 0' }}>

                <Stack alignItems="center" direction="row" flexWrap='wrap' justifyContent='center'>
                    <Box sx={{ m: '10px' }}>
                        <motion.div whileHover={{ scale: 1.5 }} whileTap={{ scale: 0.9 }}>
                            <img
                                width='auto'
                                height={100}
                                src="/images/Cellcard-Cambodia-Logo.png"
                                alt="img_cellcard"
                            />
                        </motion.div>
                    </Box>
                    <Box sx={{ m: { xs: '10px', md: '20px' } }}>
                        <motion.div whileHover={{ scale: 1.5 }} whileTap={{ scale: 0.9 }}>
                            <img
                                width='auto'
                                height={100}
                                src="/images/CFC.png"
                                alt="img_cfc"
                            />
                        </motion.div>
                    </Box>
                    <Box sx={{ m: '10px' }}>
                        <motion.div whileHover={{ scale: 1.5 }} whileTap={{ scale: 0.9 }}>
                            <img
                                width='auto'
                                height={100}
                                src="/images/Back End Development .jpg"
                                alt="img_backEndDevelopment"
                            />
                        </motion.div>
                    </Box>
                </Stack>
            </Box>

        </Box>
    );
}
