import { Box, ListItemIcon, MenuItem, MenuList,ListItemText,Typography, IconButton } from "@mui/material";
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import MoreVertIcon from '@mui/icons-material/MoreVert';
const LessonMenu = ({name,data,playVideoFunc}) => {
  return (
    <Box>
      <Box>
        <Typography variant="h6">{name}</Typography>
      </Box>
      <MenuList>
        {data?.map((item, index) => {
          return (
            <MenuItem onClick={()=>playVideoFunc(item._id)} key={index}>
              <ListItemIcon><PlayCircleOutlineIcon/></ListItemIcon>
              <ListItemText>{item.name}</ListItemText>
              <Typography variant="body2" color="text.secondary">
                {item.duration} min
              </Typography>
              <Box sx={{ml:3}}><IconButton><MoreVertIcon/></IconButton></Box>
            </MenuItem>
          );
        })}
      </MenuList>
    </Box>
  );
};

export default LessonMenu;
