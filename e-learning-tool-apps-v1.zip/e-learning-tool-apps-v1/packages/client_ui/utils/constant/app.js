const app_name= "SabaiCode Education";

export {
    app_name
}


// Layout ( ) : create new page
// Create a component (atomic design)
// app contants 
// functionality ()
// theme (custom theme ) 


