const ourStory = {
    title: 'OUR STORY',
    description: [
        {
            paragraph: 'We founded the company because we saw a huge mismatch between where the future is going and where our Cambodian children are headed. The world is in growing needs for people with high creativity, problem solving and leadership skills. These skills are embedded in the field of computer science. Cambodia is way behind. So SabaiCode was born.'
        },
        {
            paragraph: 'Our goal is not to produce future computer scientists (although we would not be surprised if it happens). Our goal is to introduce computer science fundamentals to students at a young age. So that they do not grow up intimidated by computer science field. So that our girls do not think that computer science is just for boys. So that our kids know that learning computer science can be fun. So that they will become creators, and not just users of technology. And so that they grow creativity, problem solving ability and mental toughness at a young age.'
        },
        {
            paragraph: 'We know we have ambitious goals. But trust us, together we can achieve them. We make it fun to learn. Each class size is small, usually 10 students or less. So the learning is personalized and engaging.'
        },
    ]
};

const different = {
    title: 'HOW SABAICODE IS DIFFERENT',
    description: 'We decided to open the school because we think we can do a better job than what is out there. We want to leverage our knowledge and connections in Silicon Valley to bring the best coding and robotics equipment. We want to provide our Cambodian students the U.S. quality of education.'
};

const differentCard = [
    {
        flip: false,
        title: 'Personal Attention',
        description: 'Each class size is small of 10 students or less. Each student gets full attention from the coach. Maximum 16 students in each class. Each student gets full attention from the coach.',
        imagePath: './images/personal_attention.png'
    },
    {
        flip: true,
        title: 'Extensive Connections',
        description: 'We only teach the latest, most relevant technologies. Leveraging our network, we connect our talented students with future employers.',
        imagePath: './images/extensive_connections.png'
    },
    {
        flip: false,
        title: 'Our Vision',
        description: 'Profit is important for every business. But that is not our primary goal. We want to make an impact. We want to help produce future leaders and entrepreneurs.',
        imagePath: './images/our_vision.png'
    }
];

const ourPeopleCard = [
    {
        imagePath: './images/PISETH_LENG.PNG',
        name: 'PISETH LENG',
        position: 'Founder',
        description: 'Piseth loves STEM since he was a kid. Growing up, his favorite subject was Mathematics. Through hard work, he passed the college entrance exam on a full scholarship to pursue a Bachelor of Science in Mathematics at the Royal University of Phnom Penh. To challenge himself further, a year later he also obtained a full scholarship to pursue a Bachelor of Science in Economics at the Royal University of Law and Economics. Soon after graduation, he made a big leap in life and decided to pursue an MBA in the United States. Then he went on to start a career in one of the largest commercial banks in California',
    },
    {
        imagePath: './images/SAREUON_SOUM.png',
        name: 'SAREUON SOUM',
        position: 'Co-Founder and Director',
        description: 'Sareuon is a computer engineer by training. Currently, he is Vice President of Platform at MangoMap, a Software as a Service company specializing in interactive web maps serving clients around the world. Sareuon leads the software development team and has over a decade of experience in Ruby on Rail and JavaScript programming. Sareuon earned a Bachelor of Science in Mathematics and a Bachelor of Science in Computer Science from the Royal University of Phnom Penh, both on full scholarships. Sareuon lives in Phnom Penh with his wife, son, and daughter. He is in charge of the daily operations of the school. In his free',
    },
];

const ourPeople = {
    title: 'OUR PEOPLE',
    description: 'We are a team of passionate people. We love STEM. We believe in computer science. We love sharing our knowledge with our students. We aspire to make a difference.'
};

const ourCoaches = {
    title: 'OUR COACHES',
    description: 'Our teachers, we call them coaches. Because they act as a coach rather than a teacher. They don not tell the students what to do. Rather, they help the students figure things out. The class is for the students. So the students will do most of the work and gain the most benefits. The coaches are just there to guide, facilitate, and coach. Each coach will be responsible for a small class size of 10 students or less allowing for personalized and attentive learning. We want to provide high quality education. So we pick our coaches carefully. Our coaches are professionally trained in computer science. More importantly, they love to teach, and are fun to be with.',
};

const ourCoachesCard =[
    {
        cover: './images/coach_bg.png',
        profile: './images/SEIREY_CHHUNHENG.png',
        name: 'SEIREY CHHUNHENG',
        posiotion: 'Principal',
    },
    {
        cover: './images/coach_bg.png',
        profile: './images/SEIREY_CHHUNHENG.png',
        name: 'SEIREY CHHUNHENG',
        posiotion: 'Principal',
    },
    {
        cover: './images/coach_bg.png',
        profile: './images/SEIREY_CHHUNHENG.png',
        name: 'SEIREY CHHUNHENG',
        posiotion: 'Principal',
    },
    {
        cover: './images/coach_bg.png',
        profile: './images/SEIREY_CHHUNHENG.png',
        name: 'SEIREY CHHUNHENG',
        posiotion: 'Principal',
    },
    {
        cover: './images/coach_bg.png',
        profile: './images/SEIREY_CHHUNHENG.png',
        name: 'SEIREY CHHUNHENG',
        posiotion: 'Principal',
    }
];

export {
    ourStory,
    different,
    differentCard,
    ourPeople,
    ourCoaches,
    ourPeopleCard,
    ourCoachesCard,
}

