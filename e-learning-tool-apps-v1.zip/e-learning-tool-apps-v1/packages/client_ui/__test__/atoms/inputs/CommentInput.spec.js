import CommentInput from "./../../../components/atoms/inputs/CommentInput";
import { shallow } from "enzyme";
import toJson from "enzyme-to-json";
import { Avatar, Box, Paper, Stack, TextField } from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
describe("CommentInput", () => {
  let wrapper;
  beforeAll(() => {
    wrapper = shallow(<CommentInput />);
  });
  it("snapshot", () => {
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  it("render ui", () => {
    expect(wrapper.find("form").length).toBe(1);
    expect(wrapper.find(Box).exists()).toBeTruthy();
    expect(wrapper.find(Stack).exists()).toBeTruthy();
    expect(wrapper.find(Paper).exists()).toBeTruthy();
    expect(wrapper.find(Avatar).exists()).toBeTruthy();
    expect(wrapper.find(SendIcon).exists()).toBeTruthy();
  });
  it("render content of textfield", () => {
    const textField = wrapper.find(TextField);
    expect(textField.prop("placeholder")).toEqual(
      "Announce something in your class ..."
    );
    expect(textField.prop("name")).toEqual("text");
  });
  it("form action", () => {
    const handleSubmit = jest.fn();
    const submitBtn = wrapper.find("#submit");
    // console.log(toJson(submitBtn));
    submitBtn.simulate("click");
    // expect(handleSubmit).toHaveBeenCalled();
  });
});
