import { createTheme } from "@mui/material/styles";
import { red } from "@mui/material/colors";

// Create a theme instance.
const theme = createTheme({
  typography: {
    fontFamily: "Maven Pro",
  },
  palette: {
    primary: {
      main: "#06BCC1",
      contrastText: "#ffffff",
    },
    secondary: {
      main: "#F45B69",
    },
    error: {
      main: red.A400,
    },
    white: {
      main: "#ffffff",
    },
    black: {
      main: "#12263A",
    },
    blue: {
      main: "#4062BB",
    },
    background: {
      default: "#c5DBD1",
    },
  },
  props: {
    MuiButtonBase: {
      disableRipple: true,
    },
  },
  transitions: {
    create: () => "none",
  },
  overrides: {
    MuiCssBaseline: {
      "@global": {
        "*, *::before, *::after": {
          transition: "none !important",
          animation: "none !important",
        },
      },
    },
  },
});

export default theme;
