

export default function About (){
    function handleOnclick (){
        alert('Submit Form')
    }
    return (
        <div>
            <h1>Hello , About page</h1>
         
        </div>
    )
}