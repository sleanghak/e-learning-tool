import React from "react";
import Image from "next/image";
import { Button, Dialog } from "@mui/material";
import AddBoxOutlinedIcon from "@mui/icons-material/AddBoxOutlined";
import {
  Stack,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import { SubjectForm } from "../components/containers/forms";
import { convertFilePathToURL } from "../utils/func/s3";
import { ConfirmDialog } from "../components/presentations/dialogs";
import useSWR from "swr";
import fetcher from "../utils/func/api/getDataFunc";
import SabaiCodeLoading from "../components/presentations/loading";
import SabaiCodeTable from "components/presentations/tables/SabaiCodeTable";
import { Box } from "@mui/system";
import useSocket from "utils/func/socket/useSocket";
const Subjects = ({ user }) => {
  const [open, setOpen] = React.useState(false);
  const [allSubjects, setAllSubjects] = React.useState([]);
  const [updateData, setUpdateData] = React.useState(null);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [disable, setDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [id, setID] = React.useState();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/department?disable=${disable}&page=${page}`,
    fetcher
  );
  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data.data).then((res) => {
        setAllSubjects(res);
      });
    }
  }, [data]);
  // realtime with socket
  React.useEffect(() => {
    if (socket) {
      socket.on("department", (data) => {
        convertFilePathToURL(data).then((res) => {
          setAllSubjects(res);
        });
      });
    }
  }, [socket]);
  if (error) return "Error is occurred.";
  if (!data) return <SabaiCodeLoading />;

  return (
    <Box>
      <Stack
        sx={{
          borderRadius: 2,
          p: 2,
          mb: 3,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
        direction={"row"}
        alignItems={"center"}
        justifyContent="space-between"
      >
        <Button
          color="secondary"
          startIcon={<AddBoxOutlinedIcon />}
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
        >
          Add Subject
        </Button>
        <FormControl variant="standard" style={{ minWidth: 100 }}>
          <InputLabel id="status">Status</InputLabel>
          <Select
            labelId="statusl"
            id="status"
            value={disable}
            onChange={(e) => {
              setDisable(e.target.value);
              setPage(1);
            }}
          >
            <MenuItem value={false}>Active</MenuItem>
            <MenuItem value={true}>Inactive</MenuItem>
          </Select>
        </FormControl>
      </Stack>

      <SabaiCodeTable
        editFunc={(data) => {
          setOpen(true);
          setUpdateData(data);
          setAnchorEl(null);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setOpenDelete(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        columns={columns}
        disable={disable}
        data={allSubjects}
        page={page}
        setPage={setPage}
        pages={data.pages}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
      />

      <Dialog open={open} maxWidth="sm">
        <SubjectForm
          query={{ page, disable }}
          socket={socket}
          onClose={() => setOpen(false)}
          updateData={updateData}
        />
      </Dialog>
      <ConfirmDialog
        open={openDisable}
        onClose={() => setOpenDisable(false)}
        module={"department"}
        status={disable}
        disable={false}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <ConfirmDialog
        module={"department"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
    </Box>
  );
};

export default Subjects;

const columns = [
  {
    coverFileName: true,
    width: 200,
    name: "Name",
    align: "left",
    attribute: "name",
  },
  {
    width: 100,
    name: "Course",
    align: "center",
    attribute: "courseIds",
    array: true,
  },
  {
    width: 150,
    name: "Description",
    align: "left",
    attribute: "desc",
  },
  {
    width: 100,
    name: "CreatedAt",
    align: "center",
    attribute: "createdAt",
  },
  {
    width: 75,
    name: "Status",
    align: "right",
    attribute: "disable",
  },
];
