import React, { useState } from "react";
import {
  Button,
  Dialog,
  Stack,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
} from "@mui/material";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/styles";
import AddBoxOutlinedIcon from "@mui/icons-material/AddBoxOutlined";
import { CourseForm } from "./../../components/containers/forms";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import useSWR from "swr";
import { convertFilePathToURL } from "../../utils/func/s3";
import fetcher from "../../utils/func/api/getDataFunc";
import useSocket from "./../../utils/func/socket/useSocket";
import SabaiCodeLoading from "../../components/presentations/loading";
import SabaiCodeTable from "components/presentations/tables/SabaiCodeTable";

export default function CoursePage() {
  const [updateData, setUpdateData] = React.useState(null);
  const [disable, setDisable] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  const [allCourses, setAllCourses] = React.useState([]);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("xs"));
  const [id, setID] = React.useState();
  const [openDisable, setOpenDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course?disable=${disable}&page=${page}`,
    fetcher
  );

  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data?.data).then((res) => {
        setAllCourses(res);
        console.log(res);
      });
    }
  }, [data]);
  // realtime with socket
  React.useEffect(() => {
    if (socket) {
      socket.on("course", (data) => {
        console.log("===Course Socket===", data);
        convertFilePathToURL(data).then((res) => {
          setAllCourses(res);
        });
      });
    }
  }, [socket]);

  React.useEffect(() => {
    document.title = "Courses";
  }, []);

  if (error) return "An error has occurred.";
  if (!data) return <SabaiCodeLoading />;
  return (
    <Box>
      <Stack
        sx={{
          borderRadius: 2,
          p: 2,
          mb: 3,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
        direction={"row"}
        alignItems="center"
        justifyContent={"space-between"}
      >
        <Button
          color="secondary"
          startIcon={<AddBoxOutlinedIcon />}
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
        >
          Add Course
        </Button>
        <FormControl variant="standard" style={{ minWidth: 100 }}>
          <InputLabel id="status">Status</InputLabel>
          <Select
            labelId="statusl"
            id="status"
            value={disable}
            onChange={(e) => {
              setDisable(e.target.value);
              setPage(1);
            }}
          >
            <MenuItem value={false}>Active</MenuItem>
            <MenuItem value={true}>Inactive</MenuItem>
          </Select>
        </FormControl>
      </Stack>
      <SabaiCodeTable
        editFunc={(data) => {
          setOpen(true);
          setUpdateData(data);
          setAnchorEl(null);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setOpenDelete(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        columns={columns}
        disable={disable}
        data={allCourses}
        page={page}
        setPage={setPage}
        pages={data?.pages}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        view="courses"
      />

      <Dialog fullScreen={fullScreen} open={open}>
        <CourseForm
          query={{ page, disable }}
          onClose={() => setOpen(false)}
          socket={socket}
          updateData={updateData}
        />
      </Dialog>

      <ConfirmDialog
        module={"course"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <ConfirmDialog
        module={"course"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
    </Box>
  );
}

const columns = [
  {
    coverFileName: true,
    width: 200,
    name: "Name",
    align: "left",
    attribute: "name",
  },
  {
    width: 100,
    name: "Lesson",
    align: "center",
    attribute: "lessonIds",
    array: true,
  },
  {
    width: 150,
    name: "Description",
    align: "left",
    attribute: "desc",
  },
  {
    width: 150,
    name: "CreatedAt",
    align: "left",
    attribute: "createdAt",
  },
  {
    width: 150,
    name: "Status",
    align: "right",
    attribute: "disable",
  },
];
