import React from "react";

import { Dialog, Stack, Box } from "@mui/material";

import { convertFilePathToURL } from "./../../utils/func/s3";
import { LessonForm, ResourceForm } from "../../components/containers/forms";
import useSWR from "swr";
import fetcher from "./../../utils/func/api/getDataFunc";
import Paper from "@mui/material/Paper";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import { useRouter } from "next/router";

import {
  Curriculum,
  Resource,
  Video,
} from "../../components/containers/course";
import SabaiCodeLoading from "../../components/presentations/loading";
import useSocket from "utils/func/socket/useSocket";
export const getServerSideProps = async (ctx) => {
  const courseId = ctx.query.id;
  return {
    props: {
      courseId,
    },
  };
};

const DetailCourse = ({ courseId, token }) => {
  const [video, setVideo] = React.useState({});
  const [lessons, setLessons] = React.useState([]);
  const [resources, setResources] = React.useState([]);
  const [open, setOpen] = React.useState(false);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const router = useRouter();
  const [tab, setTab] = React.useState(router.query.tab || "video");
  const handleChange = (event, newValue) => {
    setTab(newValue);
    router.push(`/courses/${courseId}?tab=${newValue}`);
  };
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course?id=${courseId}`,
    fetcher
  );

  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data.data.lessonIds).then((res) => {
        setLessons(res);
      });
      setResources(data.data.resources);
    }
  }, [data]);

  React.useEffect(() => {
    if (socket) {
      socket.on("courseId", (data) => {
        console.log(data);
        convertFilePathToURL(data.lessonIds).then((res) => {
          setLessons(res);
        });
      });
    }
  }, [socket]);

  if (error) return "error has occurred.";
  if (!data) return <SabaiCodeLoading />;

  return (
    <Stack direction="row">
      <Box sx={{ flexGrow: 1 }}>
        {tab === "video" && (
          <Video
            courseId={courseId}
            lessons={lessons}
            video={video}
            setVideo={setVideo}
            token={token}
            setOpen={setOpen}
            socket={socket}
          />
        )}

        {tab === "material" && (
          <Resource
            socket={socket}
            setOpen={setOpen}
            courseId={courseId}
            resources={resources}
          />
        )}

        {tab === "curriculum" && (
          <Curriculum
            name={data?.data?.name}
            curriculum={data?.data?.curriculum}
            courseId={courseId}
            socket={socket}
          />
        )}
      </Box>
      <Paper square sx={{ pt: 12 }}>
        <Tabs
          orientation="vertical"
          value={tab}
          indicatorColor="primary"
          textColor="primary"
          onChange={handleChange}
          aria-label="disabled tabs example"
        >
          <Tab value={"video"} label="Lesson" />
          <Tab value={"material"} label="Material" />
          <Tab value={"curriculum"} label="Curriculum" />
        </Tabs>
      </Paper>
      <Dialog open={open}>
        {tab === "video" && (
          <LessonForm
            socket={socket}
            onClose={() => setOpen(false)}
            courseId={courseId}
          />
        )}
        {tab === "material" && (
          <ResourceForm
            socket={socket}
            lessons={lessons}
            onClose={() => setOpen(false)}
            courseId={courseId}
          />
        )}
      </Dialog>
    </Stack>
  );
};
// TODO : Add Resource Form

export default DetailCourse;
