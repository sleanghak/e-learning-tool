import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Stack,
  TextField,
  IconButton,
} from "@mui/material";
import TableInvoice from "../../components/presentations/tables/TableInvoice";
import { Dialog } from "@mui/material";
import InvoiceForm from "../../components/containers/forms/InvoiceForm";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import React from "react";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import DatePicker from "@mui/lab/DatePicker";
import Clear from "@mui/icons-material/Clear";
import useSocket from "../../utils/func/socket/useSocket";
import fetcher from "../../utils/func/api/getDataFunc";
import InvoiceDetail from "../../components/containers/invoice/InvoiceDetail";
import useSWR from "swr";
import { convertFilePathToURL } from "../../utils/func/s3";
import SabaiCodeLoading from "../../components/presentations/loading";

const InvoicePage = ({ user }) => {
  const [open, setOpen] = React.useState(false);
  const [invoices, setInvoices] = React.useState([]);
  const [updateData, setUpdateData] = React.useState(null);
  const [disable, setDisable] = React.useState(false);
  const [id, setID] = React.useState(null);
  const [status, setStatus] = React.useState();
  const [openDisable, setOpenDisable] = React.useState(false);
  const [startDate, setStartDate] = React.useState();
  const [endDate, setEndDate] = React.useState();
  const [page, setPage] = React.useState(1);
  const [isAddPayment, setIsAddPayment] = React.useState(false);

  const { data, error } = useSWR(
    startDate && endDate
      ? `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/invoices?page=${page}&status=${status}&startDate=${startDate}&endDate=${endDate}`
      : `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/invoices?page=${page}&status=${status}`,
    fetcher
  );

  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);

  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data.data).then((res) => {
        setInvoices(res);
      });
    }
  }, [data]);
  React.useEffect(() => {
    if (socket) {
      socket.on("invoice", (data) => {
        convertFilePathToURL(data).then((res) => {
          setInvoices(res);
        });
      });
    }
  }, [socket]);
  if (error) return `${error}`;
  if (!data) return <SabaiCodeLoading />;
  return (
    <Box>
      <Stack
        direction={"row"}
        alignItems={"center"}
        justifyContent="space-between"
        sx={{
          p: 2,
          borderRadius: 1.5,
          mb: 3,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
      >
        <Button
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
          startIcon={<AddCircleIcon />}
          variant="contained"
        >
          Invoice
        </Button>
        <Stack direction={"row"} alignItems="center" spacing={3}>
          <DatePicker
            renderInput={(props) => <TextField {...props} variant="standard" />}
            label="From Date"
            required
            value={startDate}
            onChange={(newValue) => {
              setStartDate(newValue);
            }}
          />

          <DatePicker
            renderInput={(props) => <TextField {...props} variant="standard" />}
            label="To Date"
            required
            value={endDate}
            onChange={(newValue) => {
              setEndDate(newValue);
            }}
          />
          {startDate && endDate && (
            <IconButton
              size="small"
              onClick={() => {
                setStartDate(undefined);
                setEndDate(undefined);
              }}
            >
              <Clear size="small" color="secondary" />
            </IconButton>
          )}
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Status</InputLabel>
            <Select
              labelId="statusl"
              id="status"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <MenuItem>Unselected</MenuItem>
              <MenuItem value={"sent"}>sent</MenuItem>
              <MenuItem value={"paid"}>Paid</MenuItem>
            </Select>
          </FormControl>
        </Stack>
      </Stack>
      <TableInvoice
        editFunc={(data) => {
          setUpdateData(data);
          setOpen(true);
          setIsAddPayment(false);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setDisable(false);
        }}
        previewFunc={(data) => {
          setOpen(true);
          setIsAddPayment(true);
          setUpdateData(data);
        }}
        data={invoices}
        status={status}
        startDate={startDate}
        endDate={endDate}
        page={page}
        setPage={setPage}
      />

      <Dialog
        fullScreen={true}
        scroll="body"
        open={open}
        onClose={() => setOpen(false)}
      >
        {isAddPayment ? (
          <InvoiceDetail data={updateData} onClose={() => setOpen(false)} />
        ) : (
          <InvoiceForm
            updateData={updateData}
            onClose={() => setOpen(false)}
            socket={socket}
            query={{ page, disable: false }}
          />
        )}
      </Dialog>

      <ConfirmDialog
        message={
          disable
            ? "Do you want to delete invoice?"
            : "Do you want to disable invoice?"
        }
        module={"invoice"}
        open={openDisable}
        onClose={() => setOpenDisable(false)}
        disable={disable}
        _id={id}
      />
    </Box>
  );
};

export default InvoicePage;
