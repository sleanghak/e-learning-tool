import { Box } from "@mui/material";

const InvoiceId = () => {
  return <Box></Box>;
};

export default InvoiceId;
