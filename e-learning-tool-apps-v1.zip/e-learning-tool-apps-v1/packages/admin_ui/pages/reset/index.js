import React from "react";
import {
  Box,
  Stack,
  Typography,
  TextField,
  Button,
  Paper,
} from "@mui/material";

const ResetPage = () => {
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const sendEmailToResetPassword = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const form = e.target.elements;
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/reset`,
        {
          method: "post",
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
          body: JSON.stringify({
            email: form.email.value,
          }),
        }
      );
      const data = await res.json();
      if (data.statusCode == 200) {
        e.target.reset();
      } else {
        setError(data.message);
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      setError(error);
      setLoading(false);
    }
  };
  return (
    <Paper sx={{ width: 400, p: 3, margin: "0px auto" }}>
      <form onSubmit={sendEmailToResetPassword}>
        <Stack spacing={2}>
          <TextField
            name="email"
            required
            label="Enter User Email"
            type={"email"}
          />

          <Button disabled={loading} variant="outlined" type="submit">
            Submit
          </Button>
          <Typography color={"error"}>{error}</Typography>
        </Stack>
      </form>
    </Paper>
  );
};

export default ResetPage;
