import React from "react";
import { Box, Typography, TextField, Button } from "@mui/material";
import { useRouter } from "next/router";
import { Paper } from "@mui/material";
const TokenPage = () => {
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const router = useRouter();
  const sendEmailToResetPassword = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const form = e.target.elements;
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/reset/token`,
        {
          method: "post",
          headers: {
            "Content-Type": "application/json; charset=UTF-8",
          },
          body: JSON.stringify({
            password: form.password.value,
            token: router.query.token,
          }),
        }
      );
      const data = await res.json();
      if (data.statusCode == 200) {
        e.target.reset();
        router.push("/");
      } else {
        setError(data.message);
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      setError(error);
      setLoading(false);
    }
  };
  return (
    <Paper style={{ width: 400, padding: 24, margin: "0px auto" }}>
      <form onSubmit={sendEmailToResetPassword}>
        <Box display={"flex"} flexDirection={"column"} spacing={2}>
          <TextField
            name="password"
            required
            label="Enter New Password"
            type={"password"}
            style={{ marginBottom: 20, marginTop: 50 }}
          />

          <Button
            disabled={loading}
            variant="contained"
            color="primary"
            type="submit"
          >
            Submit
          </Button>
          <Typography color={"error"}>{error}</Typography>
        </Box>
      </form>
    </Paper>
  );
};

export default TokenPage;
