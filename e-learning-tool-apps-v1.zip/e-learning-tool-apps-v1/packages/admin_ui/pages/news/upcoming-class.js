import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import { Dialog } from "@mui/material";
import PostForm from "../../components/containers/forms/PostForm";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import React from "react";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import PostToClassForm from "../../components/containers/forms/PostToClassForm";
import SabaiCodeTable from "../../components/presentations/tables/SabaiCodeTable";
import useSWR from "swr";
import fetcher from "../../utils/func/api/getDataFunc";
import useSocket from "../../utils/func/socket/useSocket";
import SabaiCodeLoading from "../../components/presentations/loading";
import { convertFilePathToURL } from "../../utils/func/s3";
const Post = ({ user }) => {
  const [open, setOpen] = React.useState(false);
  const [openPost, setOpenPost] = React.useState(false);
  const [updateData, setUpdateData] = React.useState(null);
  const [disable, setDisable] = React.useState(false);
  const [id, setID] = React.useState(null);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [posts, setPosts] = React.useState([]);
  const [page, setPage] = React.useState(1);

  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/post?page=${page}&&disable=${disable}`,
    fetcher
  );
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);

  React.useEffect(() => {
    if (data?.data) {
      console.log(data);
      convertFilePathToURL(data?.data).then((res) => {
        setPosts(res);
      });
    }
  }, [data]);

  React.useEffect(() => {
    if (socket) {
      socket.on("post", (data) => {
        convertFilePathToURL(data).then((res) => {
          setPosts(res);
        });
      });
    }
  }, [socket]);

  if (error) return `${error}`;
  if (!data) return <SabaiCodeLoading />;
  return (
    <Box>
      <Box
        style={{
          padding: 16,
          borderRadius: 16,
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 8,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
      >
        <Button
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
          startIcon={<AddCircleIcon />}
          variant="contained"
        >
          Post
        </Button>
        <FormControl variant="standard" style={{ minWidth: 100 }}>
          <InputLabel id="status">Status</InputLabel>
          <Select
            labelId="statusl"
            id="status"
            value={disable}
            onChange={(e) => setDisable(e.target.value)}
          >
            <MenuItem value={false}>Active</MenuItem>
            <MenuItem value={true}>Unactive</MenuItem>
          </Select>
        </FormControl>
      </Box>

      <SabaiCodeTable
        createClassByPostFunc={(data) => {
          setOpenPost(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        editFunc={(data) => {
          setUpdateData(data);
          setOpen(true);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setID(data._id);
          setOpenDelete(true);
          setAnchorEl(null);
        }}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        disable={disable}
        columns={columns}
        data={posts}
        page={page}
        setPage={setPage}
        pages={data.pages}
      />
      <Dialog scroll="body" open={open} onClose={() => setOpen(false)}>
        <PostForm
          socket={socket}
          query={{ page, disable }}
          updateData={updateData}
          onClose={() => setOpen(false)}
        />
      </Dialog>
      <ConfirmDialog
        module={"post"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <ConfirmDialog
        module={"post"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <Dialog open={openPost} scroll="paper" onClose={() => setOpenPost(false)}>
        <PostToClassForm postId={id} onClose={() => setOpenPost(false)} />
      </Dialog>
    </Box>
  );
};

export default Post;

const columns = [
  {
    coverFileName: true,
    width: 200,
    name: "Name",
    align: "left",
    attribute: "name",
  },
  {
    width: 100,
    name: "Course",
    align: "left",
    attribute: "course",
    isName: true,
  },
  {
    width: 100,
    name: "Description",
    align: "left",
    attribute: "description",
  },
  {
    width: 100,
    name: "Time",
    align: "left",
    attribute: "startDate",
  },
  {
    width: 150,
    name: "Date",
    align: "center",
    attribute: "startDate",
  },
  {
    width: 150,
    name: "Status",
    align: "right",
    attribute: "disable",
  },
];
