import React from "react";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Stack,
  Dialog,
} from "@mui/material";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import SabaiCodeTable from "../../components/presentations/tables/SabaiCodeTable";
import useSWR from "swr";
import SabaiCodeLoading from "../../components/presentations/loading";
import fetcher from "../../utils/func/api/getDataFunc";
import { convertFilePathToURL } from "../../utils/func/s3";
import NewsForm from "../../components/containers/forms/NewsForm";
import ConfirmDialog from "../../components/presentations/dialogs/ConfirmDialog";
import useSocket from "utils/func/socket/useSocket";
const CareerPage = () => {
  const [type, setType] = React.useState();
  const [open, setOpen] = React.useState(false);
  const [news, setNews] = React.useState([]);
  const [page, setPage] = React.useState(1);
  const [id, setID] = React.useState(null);
  const [updateData, setUpdateData] = React.useState(null);
  const [disable, setDisable] = React.useState(false);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/news?disable=${disable}&page=${page}&type=${type}`,
    fetcher
  );
  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data.data).then((res) => {
        setNews(res);
      });
    }
  }, [data]);

  React.useEffect(() => {
    if (socket) {
      socket.on("news", (data) => {
        console.log("socket news", data);
        convertFilePathToURL(data).then((res) => {
          setNews(res);
        });
      });
    }
  }, [socket]);
  if (error) return <div>failed to load</div>;
  if (!data) return <SabaiCodeLoading />;

  return (
    <Box>
      <Stack
        direction={"row"}
        justifyContent={"space-between"}
        alignItems={"center"}
        sx={{
          p: 1.5,
          borderRadius: 1.5,
          mb: 2,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
      >
        <Button
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
          startIcon={<AddCircleIcon />}
          variant="contained"
        >
          Career
        </Button>
        <Stack direction={"row"} spacing={3}>
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Type</InputLabel>
            <Select
              labelId="statusl"
              id="status"
              value={type}
              onChange={(e) => setType(e.target.value)}
            >
              <MenuItem>Unselected</MenuItem>
              <MenuItem value={"job"}>Career</MenuItem>
              <MenuItem value={"scholarship"}>Scholarship</MenuItem>
            </Select>
          </FormControl>
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Status</InputLabel>
            <Select
              labelId="statusl"
              id="status"
              value={disable}
              onChange={(e) => setDisable(e.target.value)}
            >
              <MenuItem value={false}>Active</MenuItem>
              <MenuItem value={true}>Unactive</MenuItem>
            </Select>
          </FormControl>
        </Stack>
      </Stack>
      <SabaiCodeTable
        editFunc={(data) => {
          setUpdateData(data);
          console.log(data);
          setOpen(true);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setOpenDelete(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        columns={columns}
        disable={disable}
        data={news}
        page={page}
        setPage={setPage}
        pages={data.pages}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
      />
      <Dialog
        fullScreen={true}
        scroll="body"
        open={open}
        onClose={() => setOpen(false)}
      >
        <NewsForm
          socket={socket}
          query={{ page, disable, type }}
          updateData={updateData}
          onClose={() => setOpen(false)}
        />
      </Dialog>
      <ConfirmDialog
        module={"news"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable, type }}
        socket={socket}
      />
      <ConfirmDialog
        module={"news"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable, type }}
        socket={socket}
      />
    </Box>
  );
};

export default CareerPage;

const columns = [
  {
    coverFileName: true,
    name: "Name",
    align: "left",
    attribute: "name",
  },
  {
    name: "Type",
    align: "left",
    attribute: "type",
  },

  {
    name: "Sumissions",
    align: "left",
    attribute: "submissions",
    array: true,
  },
  {
    name: "Description",
    align: "left",
    attribute: "description",
  },
  {
    name: "Created At",
    align: "left",
    attribute: "createdAt",
  },
  {
    name: "Due Date",
    align: "left",
    attribute: "dueDate",
  },
  {
    name: "Status",
    align: "left",
    attribute: "disable",
  },
];
