import "../styles/globals.css";
import { ThemeProvider } from "@mui/material/styles";
import { Layout } from "./../components/containers/layouts";
import theme from "../styles/theme";
import { navBarItems } from "../utils/constants/apps/navBarItems";
import { useRouter } from "next/router";
import NextNprogress from "nextjs-progressbar";
import awsmobile from "../aws-exports";
import Amplify from "aws-amplify";
import isPublicRoute from "./../utils/func/isPublicRoute";
import { Header } from "./../components/containers/layouts";
import { parseCookies, destroyCookie } from "nookies";
import axios from "axios";
import { redirectUser } from "./../utils/func/auth/authUser";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";

Amplify.configure(awsmobile);
function MyApp({ Component, pageProps, token }) {
  const router = useRouter();

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <ThemeProvider theme={theme}>
        <Header title={"Admin"} />
        <ToastContainer />
        <NextNprogress
          color="#fff"
          startPosition={0.3}
          stopDelayMs={200}
          height={3}
        />

        {isPublicRoute(router.pathname) ? (
          <Component {...pageProps} />
        ) : (
          <>
            <Layout
              {...pageProps}
              navBarItems={navBarItems}
              user={pageProps.user}
              title="Admin"
            >
              <Component {...pageProps} user={pageProps.user} />
            </Layout>
          </>
        )}
      </ThemeProvider>
    </LocalizationProvider>
  );
}

// Protected Route
MyApp.getInitialProps = async ({ Component, ctx }) => {
  let pageProps = {};
  let authorize = {};
  const token = parseCookies(ctx)?.token_admin;
  const protectedRoute =
    ctx.pathname === "/dashboard" ||
    ctx.pathname === "/about" ||
    ctx.pathname === "/coaches" ||
    ctx.pathname === "/coaches/[id]" ||
    ctx.pathname === "/setting" ||
    ctx.pathname === "/students" ||
    ctx.pathname === "/people/partners" ||
    ctx.pathname === "/students/student-work" ||
    ctx.pathname === "/departments" ||
    ctx.pathname === "/courses" ||
    ctx.pathname === "/courses/[id]" ||
    ctx.pathname === "/classes" ||
    ctx.pathname === "/classes/[id]" ||
    ctx.pathname === "/inventory" ||
    ctx.pathname === "/inventory/[id]" ||
    ctx.pathname === "/contact/contact_history" ||
    ctx.pathname === "/news/upcoming-class" ||
    ctx.pathname === "/news" ||
    ctx.pathname === "/contact/contact_us" ||
    ctx.pathname === "/invoice" ||
    ctx.pathname === "/invoice/[invoiceId]" ||
    ctx.pathname === "/media";

  if (!token) {
    protectedRoute && redirectUser(ctx, "/");
  } else {
    try {
      authorize = JSON.parse(token);
    } catch (error) {
      destroyCookie(ctx, "token_admin");
      redirectUser("/");
    }

    if (Component.getInitialProps) {
      pageProps = await Component.getInitialProps(ctx);
    }
    try {
      const res = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/user/current_user`,
        {
          headers: {
            "x-access-token": authorize.accessToken,
          },
        }
      );
      const user = res.data;
      if (user) !protectedRoute && redirectUser(ctx, "/dashboard");
      pageProps.user = user;
      pageProps.token = authorize;
    } catch (error) {
      console.error(error);
      destroyCookie(ctx, "token_admin");
      redirectUser("/");
    }
  }

  return { pageProps, token };
};
export default MyApp;
