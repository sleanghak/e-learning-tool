const InventoryDetail = () => {
    return ( 
        <div>
            
        </div>
     );
}
 
export default InventoryDetail;