import React from "react";
import {
  Paper,
  Button,
  Dialog,
  Stack,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from "@mui/material";

import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
import Image from "next/image";
import AddIcon from "@mui/icons-material/Add";
import { useTheme } from "@mui/material";
import { useMediaQuery } from "@mui/material";
import { InventoryForm } from "../../components/containers/forms";
import { convertFilePathToURL } from "../../utils/func/s3";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import useSWR from "swr";
import fetcher from "../../utils/func/api/getDataFunc";
import SabaiCodeLoading from "../../components/presentations/loading";
import SabaiCodeTable from "../../components/presentations/tables/SabaiCodeTable";
import useSocket from "utils/func/socket/useSocket";

const Inventory = () => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("xs"));
  const [open, setOpen] = React.useState(false);
  const [inventories, setInventories] = React.useState([]);
  const [updateData, setUpdateData] = React.useState(null);
  const [id, setID] = React.useState();
  const [disable, setDisable] = React.useState(false);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/inventory?page=${page}&disable=${disable}`,
    fetcher
  );
  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data.data).then((res) => {
        setInventories(res);
        console.log(res);
      });
    }
  }, [data]);

  const exportDataToExcel = () => {};
  if (error) return "Error is occured.";
  if (!data) return <SabaiCodeLoading />;
  return (
    <Paper sx={{ p: 2 }}>
      <Stack
        direction={"row"}
        justifyContent="space-between"
        alignItems={"center"}
        sx={{ pb: 2 }}
      >
        <Button
          onClick={() => setOpen(true)}
          variant="contained"
          color="primary"
          endIcon={<AddIcon />}
        >
          Create
        </Button>
        <Stack direction={"row"} spacing={3} alignItems="center">
          {inventories.length !== 0 && (
            <Button
              onClick={exportDataToExcel}
              variant="contained"
              color="primary"
              className="btns"
              startIcon={<PictureAsPdfIcon />}
            >
              Excel
            </Button>
          )}
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Status</InputLabel>
            <Select
              labelId="status"
              id="status"
              value={disable}
              onChange={(e) => {
                setDisable(e.target.value);
                setPage(1);
              }}
            >
              <MenuItem value={false}>Active</MenuItem>
              <MenuItem value={true}>Inactive</MenuItem>
            </Select>
          </FormControl>
        </Stack>
      </Stack>

      <SabaiCodeTable
        disableFunc={(inv) => {
          setOpenDisable(true);
          setID(inv._id);
        }}
        editFunc={(inv) => {
          setOpen(true);
          setUpdateData(inv);
        }}
        deleteFunc={(inv) => {
          setOpenDisable(true);
          setID(inv._id);
        }}
        disable={disable}
        columns={columns}
        data={inventories}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        page={page}
        setPage={setPage}
        pages={data.pages}
      />

      <Dialog fullScreen={fullScreen} open={open}>
        <InventoryForm onClose={() => setOpen(false)} updateData={updateData} />
      </Dialog>
      <ConfirmDialog
        module={"inventory"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <ConfirmDialog
        module={"inventory"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
    </Paper>
  );
};

const columns = [
  {
    coverFileName: true,
    width: 100,
    name: "Inventory",
    align: "left",
    attribute: "name",
  },
  {
    width: 100,
    name: "Serial Code",
    align: "left",
    attribute: "serialCode",
  },
  {
    width: 100,
    name: "Amount",
    align: "left",
    attribute: "amount",
  },
  {
    width: 100,
    name: "Available Amount",
    align: "left",
    attribute: "availableAmount",
  },

  {
    width: 100,
    name: "Created At",
    align: "left",
    attribute: "createdAt",
  },
];

export default Inventory;
