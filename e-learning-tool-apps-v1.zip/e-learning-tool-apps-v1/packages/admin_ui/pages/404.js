import React from "react";
import { makeStyles } from "@mui/styles";
import Image from "next/image";
const useStyles = makeStyles((theme) => ({
  root: {
    width: 400,
    margin: "0px auto",
    textAlign: "center",
  },
}));
const NotFounded = ({}) => {
  const classes = useStyles();
  return (
    <div>
      <div className={classes.root}>
        <Image src="/404.svg" alt="unknow page" width={400} height={400} />
        <h1>Not Founded Page </h1>
      </div>
    </div>
  );
};

export default NotFounded;
