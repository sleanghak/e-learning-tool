import React, { useEffect } from "react";
import {
  Paper,
  Grid,
  ButtonGroup,
  Button,
  IconButton,
  Typography,
  Avatar,
} from "@mui/material";
import { makeStyles, withStyles } from "@mui/styles";
import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
import Image from "next/image";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import Link from "next/link";

import DoubleArrowIcon from "@mui/icons-material/DoubleArrow";
import PersonAddAltIcon from "@mui/icons-material/PersonAddAlt";
import { CoachForm } from "./../../components/containers/forms";
import { Dialog } from "@mui/material";
import { convertFilePathToURL } from "../../utils/func/s3";
import useSWR from "swr";
import fetcher from "utils/func/api/getDataFunc";
import SabaiCodeLoading from "./../../components/presentations/loading";
import exportToExcel from "../../utils/func/exportToExcel";
import useSocket from "../../utils/func/socket/useSocket";
const useStyles = makeStyles((theme) => ({
  calendar: {},
  paper: {
    padding: 8,
  },
  choose: {
    float: "right",
    marginTop: 15,
    marginBottom: 15,
    "& .btns": {
      marginLeft: 8,
    },
  },
}));
const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: "#1eae98",
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
    paddingLeft: 16,
    paddingRight: 8,
    paddingTop: 4,
    paddingBottom: 4,
  },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
  root: {
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
  },
}))(TableRow);

const Caoches = () => {
  const [open, setOpen] = React.useState(false);
  const classes = useStyles();
  const [coaches, setCoaches] = React.useState([]);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/coaches`,
    fetcher
  );
  const exportFileToXcel = (e) => {
    e.preventDefault();
    const tabName = "Coaches";
    exportToExcel(
      ["name", "email", "bank", "total_hours", "default_salary", "salary"],
      coaches,
      tabName
    );
  };
  React.useEffect(() => {
    if (data) {
      convertFilePathToURL(data).then((data) => {
        setCoaches(data);
      });
    }
  }, [data]);

  React.useEffect(() => {
    if (socket) {
      socket.on("user", (data) => {
        convertFilePathToURL(data).then((data) => {
          setCoaches(data);
        });
      });
    }
  }, [socket]);

  if (error) return "Error is occured!";
  if (!data) return <SabaiCodeLoading />;

  return (
    <Paper sx={{ p: 2 }}>
      <Grid container justifyContent="center">
        <Grid item xs={12}>
          <div className={classes.choose}>
            <Button
              variant="outlined"
              startIcon={<PersonAddAltIcon />}
              onClick={() => setOpen(true)}
            >
              Coach
            </Button>
            <Button
              onClick={exportFileToXcel}
              variant="contained"
              color="primary"
              className="btns"
              startIcon={<PictureAsPdfIcon />}
            >
              Excel
            </Button>
          </div>
          {coaches?.length === 0 ? (
            <div style={{ width: 400, height: 450, margin: "0 auto" }}>
              <Image
                src="/images/co-worker.svg"
                width={400}
                height={450}
                alt="unknown"
              />
            </div>
          ) : (
            <>
              <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="customized table">
                  <TableHead>
                    <TableRow>
                      <StyledTableCell align="left">Coach</StyledTableCell>
                      <StyledTableCell align="left">Email</StyledTableCell>
                      <StyledTableCell align="left">
                        ABA Account
                      </StyledTableCell>
                      <StyledTableCell align="left">Major</StyledTableCell>
                      <StyledTableCell align="left">Hours</StyledTableCell>
                      <StyledTableCell align="left">Def Salary</StyledTableCell>
                      <StyledTableCell align="left">Salary</StyledTableCell>
                      <StyledTableCell align="center">Action</StyledTableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {coaches?.map((data, index) => (
                      <StyledTableRow key={`row${index}`}>
                        <StyledTableCell component="th" scope="row">
                          <div style={{ display: "flex" }}>
                            <Avatar
                              style={{ marginRight: 16 }}
                              src={data.coverFileName}
                            />
                            <div style={{ marginTop: 8 }}>{data.name}</div>
                          </div>
                        </StyledTableCell>
                        <StyledTableCell align="left">
                          {data.email}
                        </StyledTableCell>
                        <StyledTableCell align="left">
                          <b></b>
                          {data.bank}
                        </StyledTableCell>
                        <StyledTableCell align="left">
                          {data.major?.name}
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          {data.total_hours}
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          {data.default_salary}
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          {data.default_salary +
                            data.total_hours * data.price_per_hour}
                        </StyledTableCell>
                        <StyledTableCell align="center">
                          <ButtonGroup
                            variant="contained"
                            color="inherit"
                            aria-label="contained primary button group"
                          >
                            <Link href={`/coaches/${data._id}`}>
                              <IconButton>
                                <DoubleArrowIcon />
                              </IconButton>
                            </Link>
                          </ButtonGroup>
                        </StyledTableCell>
                      </StyledTableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          )}
        </Grid>
      </Grid>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <CoachForm socket={socket} onClose={() => setOpen(false)} />
      </Dialog>
    </Paper>
  );
};

export default Caoches;
