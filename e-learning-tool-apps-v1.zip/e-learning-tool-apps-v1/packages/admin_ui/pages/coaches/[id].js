import React, { useState } from "react";
import {
  Box,
  Typography,
  Button,
  TextField,
  MenuItem,
  Dialog,
  Paper,
  Stack,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import AttendanceCoaches from "../../components/presentations/tables/AttendanceCoaches";
import { months } from "./../../utils/constants/date";
import AddRoundedIcon from "@mui/icons-material/AddRounded";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    padding: 16,
  },
  num_students: {
    width: "100%",
    display: "flex",
    justifyContent: "space-around",
    flexWrap: "wrap",
    marginBottom: 30,
  },
  header: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    marginBottom: 30,
    padding: "0px 20px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 10px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 5px",
    },
  },
  add_button: {
    marginRight: 30,
    [theme.breakpoints.down("md")]: {
      padding: "5px 25px",
      marginRight: 20,
    },
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
  },
  add_button_sm: {
    marginRight: 10,
    paddingLeft: 20,
    paddingRight: 20,
    [theme.breakpoints.up("sm")]: {
      display: "none",
    },
  },
  select_year: {
    width: 200,
    [theme.breakpoints.down("md")]: {
      width: 150,
    },
    [theme.breakpoints.down("sm")]: {
      width: 100,
    },
  },
  input_text: {
    fontFamily: "Arial",
  },

  select_month_box: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 30,
    padding: "0px 20px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 10px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 5px",
    },
  },
}));

const Coaches = ({}) => {
  const classes = useStyles();
  const d = new Date();
  const [open, setOpen] = useState(false);
  const [year, setYear] = useState(d.getFullYear());
  const [month, setMonth] = useState(d.getMonth());
  const [totalHours, setTotalHours] = useState(0);
  const [coach, setCoach] = useState({});
  const handleChangeYear = (event) => {
    setYear(event.target.value);
  };

  const handleChangeMonth = (event) => {
    setMonth(event.target.value);
  };

  return (
    <Paper className={classes.root}>
      <Stack
        direction={"row"}
        justifyContent={"space-between"}
        alignItems="center"
      >
        <Typography>{coach.name}</Typography>
        <Typography>ABA Account: {coach.bank}</Typography>
        <Typography>{coach.email}</Typography>
      </Stack>
      <Box className={classes.header}>
        <Box sx={{ display: "flex", alignItems: "end", mb: "20px" }}>
          <Box>
            <Button
              variant="outlined"
              onClick={() => setOpen(true)}
              className={classes.add_button_sm}
            >
              <AddRoundedIcon />
            </Button>
          </Box>
        </Box>
      </Box>
      <Box className={classes.select_month_box}>
        <TextField
          style={{ width: 200 }}
          size="small"
          fullWidth
          select
          value={month}
          onChange={handleChangeMonth}
          InputProps={{
            classes: {
              root: classes.input_text,
            },
          }}
        >
          {months.map((item, index) => {
            return (
              <MenuItem key={index} value={index}>
                <Typography>{item}</Typography>
              </MenuItem>
            );
          })}
        </TextField>

        <Typography
          style={{ padding: 8, width: 200, backgroundColor: "lightgreen" }}
        >
          $$ {totalHours * coach.price_per_hour + coach.default_salary}
        </Typography>
        <Typography
          style={{ padding: 8, width: 200, backgroundColor: "lightgreen" }}
        >
          {coach.price_per_hour}$/hour
        </Typography>
        <Box className={classes.select_year}>
          <TextField
            size="small"
            fullWidth
            select
            value={year}
            onChange={handleChangeYear}
            InputProps={{
              classes: {
                root: classes.input_text,
              },
            }}
            className={classes.input_fieldset}
          >
            <MenuItem value={d.getFullYear() - 2}>
              {d.getFullYear() - 2}
            </MenuItem>
            <MenuItem value={d.getFullYear() - 1}>
              {d.getFullYear() - 1}
            </MenuItem>
            <MenuItem value={d.getFullYear()}>{d.getFullYear()}</MenuItem>
          </TextField>
        </Box>
      </Box>
      <Box>
        <AttendanceCoaches
          year={year}
          month={month}
          setTotalHours={setTotalHours}
          setCoach={setCoach}
        />
      </Box>
    </Paper>
  );
};

export default Coaches;
