import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import SabaiCodeTable from "../../components/presentations/tables/SabaiCodeTable";
import { Dialog } from "@mui/material";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import React from "react";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import PartnerForm from "../../components/containers/forms/PartnerForm";
import useSWR from "swr";
import unauthFetcher from "utils/func/api/unauthFetch";
import SabaiCodeLoading from "./../../components/presentations/loading";
import { convertFilePathToURL } from "utils/func/s3";
import useSocket from "utils/func/socket/useSocket";
const PartnerPage = ({ user }) => {
  const [open, setOpen] = React.useState(false);
  const [updateData, setUpdateData] = React.useState(null);
  const [disable, setDisable] = React.useState(false);
  const [id, setID] = React.useState(null);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [partners, setPartners] = React.useState([]);
  const [page, setPage] = React.useState(1);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/partner?page=${page}&disable=${disable}`,
    unauthFetcher
  );

  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data.data).then((res) => {
        setPartners(res);
        console.log(res);
      });
    }
  }, [data]);

  React.useEffect(() => {
    if (socket) {
      socket.on("partner", (data) => {
        convertFilePathToURL(data).then((res) => {
          setPartners(res);
          console.log(res);
        });
      });
    }
  }, [socket]);

  if (error) return "Error is occured.";
  if (!data) return <SabaiCodeLoading />;
  return (
    <Box>
      <Box
        style={{
          padding: 16,
          borderRadius: 16,
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 8,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
      >
        <Button
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
          startIcon={<AddCircleIcon />}
          variant="contained"
        >
          Partner
        </Button>
        <FormControl variant="standard" style={{ minWidth: 100 }}>
          <InputLabel id="status">Status</InputLabel>
          <Select
            labelId="statusl"
            id="status"
            value={disable}
            onChange={(e) => setDisable(e.target.value)}
          >
            <MenuItem value={false}>Active</MenuItem>
            <MenuItem value={true}>Unactive</MenuItem>
          </Select>
        </FormControl>
      </Box>
      <SabaiCodeTable
        columns={columns}
        editFunc={(data) => {
          setUpdateData(data);
          setOpen(true);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setOpenDelete(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        disable={disable}
        page={page}
        pages={data?.pages}
        setPage={setPage}
        data={partners}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
      />
      <Dialog open={open} onClose={() => setOpen(false)}>
        <PartnerForm
          query={{ page, disable }}
          socket={socket}
          updateData={updateData}
          onClose={() => setOpen(false)}
        />
      </Dialog>
      <ConfirmDialog
        module={"partner"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <ConfirmDialog
        module={"partner"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
    </Box>
  );
};
const columns = [
  {
    coverFileName: true,
    width: 100,
    name: "Organization",
    align: "left",
    attribute: "name",
  },
  {
    width: 300,
    name: "Description",
    align: "left",
    attribute: "description",
  },
];
export default PartnerPage;
