import React from "react";
import { Grid, Paper, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";
import {
  TableDashboard,
  LineChart,
  PieChart,
  HorizontalBarChart,
} from "./../components/containers/dashboards";
import {
  pieData,
  horizontalBarData,
  singleLineData,
  doubleData,
} from "./../utils/constants/staticData";
import { parseCookies } from "nookies";
import { InfoCard } from "./../components/presentations/cards";
const useStyles = makeStyles((theme) => ({
  chart: {
    height: 300,
  },
  charts: {
    padding: 15,
    [theme.breakpoints.up("sm")]: {
      padding: 0,
    },
  },
}));

export const getServerSideProps = async (ctx) => {
  let dashboard = {};
  const token = parseCookies(ctx)?.token_admin;
  if (token) {
    const authorize = JSON.parse(token);
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/dashboard`,
      {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      }
    );
    dashboard = await res.json();
  }
  return {
    props: {
      dashboard,
    },
  };
};
const Dashboard = ({ dashboard, user }) => {
  const classes = useStyles();
  return (
    <>
      <Grid container spacing={3} justifyContent="space-evenly">
        <Grid item xs={12} sm={6} md={2}>
          <InfoCard
            label={"Coach"}
            amount={dashboard?.coaches}
            color={"#307de3"}
            url={"/coaches"}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={2}>
          <InfoCard
            label={"Past Student"}
            amount={dashboard?.past_students}
            color={"#03fcc2"}
            url={"/students?status=false"}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={2}>
          <InfoCard
            label={"Student"}
            amount={dashboard?.users}
            color={"#c91c7e"}
            url={"/students?status=true"}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={2}>
          <InfoCard
            label={"Upcoming Class"}
            amount={dashboard?.posts}
            color={"#098209"}
            url={"/post"}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={2}>
          <InfoCard
            label={"Present Class"}
            amount={dashboard?.presentClasses}
            color={"#c91c7e"}
            url={"/classes"}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={2}>
          <InfoCard
            label={"Past Class"}
            amount={dashboard?.pastClasses}
            color={"#c91c7e"}
            url={"/classes?active=false"}
          />
        </Grid>
      </Grid>
      <Grid
        container
        className={classes.charts}
        justifyContent="space-evenly"
        spacing={3}
      >
        <Grid item xs={12} sm={12} md={6}>
          <Paper>
            <Typography align="center" variant="h6">
              Subject & Course
            </Typography>
            <div className={classes.chart}>
              <PieChart data={pieData} />
            </div>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <Paper>
            <Typography align="center" variant="h6">
              Income & Expences
            </Typography>
            <div className={classes.chart}>
              <LineChart data={singleLineData} />
            </div>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <Paper>
            <Typography align="center" variant="h6">
              Class
            </Typography>
            <div className={classes.chart}>
              <LineChart data={doubleData} />
            </div>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <Paper>
            <Typography align="center" variant="h6">
              Resource
            </Typography>
            <div className={classes.chart}>
              <HorizontalBarChart
                data={horizontalBarData(
                  dashboard?.videos,
                  dashboard?.lessons,
                  dashboard?.courses,
                  dashboard?.subjects
                )}
              />
            </div>
          </Paper>
        </Grid>
      </Grid>
    </>
  );
};

export default Dashboard;
