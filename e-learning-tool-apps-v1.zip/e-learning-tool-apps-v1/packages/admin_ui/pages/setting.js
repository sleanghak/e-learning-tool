import React from "react";
import { PersonalInfo, SettingMenu } from "../components/containers/settings";
import { Paper, Grid } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { ChangePassword } from "../components/containers/settings";
import { useRouter } from "next/router";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: 16,
  },
}));
const Setting = ({ user }) => {
  const router = useRouter();
  const classes = useStyles();
  const active = router.query.tab || "info";
  return (
    <Paper className={classes.root}>
      <Grid container>
        <Grid item xs={5}>
          <SettingMenu active={active} />
        </Grid>
        <Grid item xs={7}>
          {active === "info" && <PersonalInfo user={user.data} />}
          {active === "password" && <ChangePassword />}
        </Grid>
      </Grid>
    </Paper>
  );
};

export default Setting;
