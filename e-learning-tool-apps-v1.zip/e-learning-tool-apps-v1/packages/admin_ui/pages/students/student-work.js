import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import { Dialog } from "@mui/material";
import StudentWorkForm from "../../components/containers/forms/StudentWorkForm";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import React from "react";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import useSWR from "swr";
import fetcher from "../../utils/func/api/getDataFunc";
import SabaiCodeLoading from "../../components/presentations/loading";
import SabaiCodeTable from "components/presentations/tables/SabaiCodeTable";
import unauthFetcher from "utils/func/api/unauthFetch";
import useSocket from "utils/func/socket/useSocket";
const StudentWork = ({ user }) => {
  const [open, setOpen] = React.useState(false);
  const [studentWorks, setStudentWorks] = React.useState([]);
  const [updateData, setUpdateData] = React.useState(null);
  // const [disable, setDisable] = React.useState(false);
  const [id, setID] = React.useState(null);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [page, setPage] = React.useState(1);
  const [query, setQuery] = React.useState({
    status: false,
  });
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course`,
    fetcher
  );
  const student_works = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/student_work?status=${query.status}&&courseId=${query.course}&&page=${page}`,
    unauthFetcher
  );
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);

  // realtime with socket
  React.useEffect(() => {
    if (socket) {
      socket.on("student_work", (data) => {
        setStudentWorks(data);
      });
    }
  }, [socket]);
  React.useEffect(() => {
    if (student_works?.data) {
      setStudentWorks(student_works?.data?.data);
    }
  }, [student_works?.data]);

  React.useEffect(() => {
    document.title = `Student Work `;
  }, []);
  if (error) return `It has error.`;
  if (!student_works?.data) return <SabaiCodeLoading />;
  console.log(student_works.data);
  return (
    <Box>
      <Box
        style={{
          padding: 16,
          borderRadius: 16,
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 8,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
      >
        <Button
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
          startIcon={<AddCircleIcon />}
          variant="contained"
        >
          Create
        </Button>
        <div style={{ display: "flex", gap: 20 }}>
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Course</InputLabel>
            <Select
              labelId="statusl"
              id="status"
              value={query.type}
              onChange={(e) => {
                setQuery((prev) => ({ ...prev, course: e.target.value }));
              }}
            >
              <MenuItem value={null}>unselected</MenuItem>
              {data?.data?.map((item, index) => {
                return (
                  <MenuItem key={index} value={item._id}>
                    {item.name}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>

          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Status</InputLabel>
            <Select
              labelId="statusl"
              id="status"
              value={query.status}
              onChange={(e) => {
                setQuery((prev) => ({ ...prev, status: e.target.value }));
              }}
            >
              <MenuItem value={false}>Active</MenuItem>
              <MenuItem value={true}>Unactive</MenuItem>
            </Select>
          </FormControl>
        </div>
      </Box>

      <SabaiCodeTable
        editFunc={(data) => {
          setUpdateData(data);
          setOpen(true);
        }}
        disableFunc={(data) => {
          console.log(data);
          setOpenDisable(true);
          setID(data._id);
          // setDisable(false);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setOpenDelete(true);
          setID(data._id);
          // setDisable(true);
          setAnchorEl(null);
        }}
        disable={query?.status}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        columns={columns}
        data={studentWorks}
        page={page}
        setPage={setPage}
        pages={student_works?.data?.pages}
      />
      <Dialog
        scroll="body"
        fullScreen={true}
        open={open}
        onClose={() => setOpen(false)}
      >
        <StudentWorkForm
          query={{ page, disable: query?.status }}
          socket={socket}
          updateData={updateData}
          onClose={() => setOpen(false)}
        />
      </Dialog>
      <ConfirmDialog
        module={"student_work"}
        open={openDisable}
        status={query?.status}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable: query?.status }}
        socket={socket}
      />
      <ConfirmDialog
        module={"student_work"}
        open={openDelete}
        status={query?.status}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable: query?.status }}
        socket={socket}
      />
    </Box>
  );
};

export default StudentWork;

const columns = [
  {
    coverFileName: false,
    width: 150,
    name: "Name",
    align: "left",
    attribute: "name",
  },
  {
    width: 200,
    name: "Course",
    align: "left",
    attribute: "course",
    isName: true,
  },
  {
    width: 75,
    name: "Student",
    align: "left",
    attribute: "students",
    array: true,
  },
  {
    width: 125,
    name: "created At",
    align: "center",
    attribute: "createdAt",
  },
  {
    width: 200,
    name: "Description",
    align: "center",
    attribute: "description",
  },
  {
    width: 150,
    name: "Link",
    align: "left",
    attribute: "link",
  },
];
