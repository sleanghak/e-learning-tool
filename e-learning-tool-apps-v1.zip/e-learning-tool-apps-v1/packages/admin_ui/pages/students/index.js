import React, { useEffect } from "react";
import {
  Paper,
  Grid,
  InputLabel,
  FormControl,
  MenuItem,
  Select,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import Image from "next/image";
import { StudentList } from "../../components/containers/students";
import { SearchBox } from "../../components/presentations/searchBox";
import { parseCookies } from "nookies";
import { convertFilePathToURL } from "../../utils/func/s3";
import useSWR from "swr";
import fetcher from "../../utils/func/api/getDataFunc";
import SabaiCodeLoading from "../../components/presentations/loading";
const useStyles = makeStyles((theme) => ({
  root: {
    marginTop: 0,
    padding: 8,
  },
  tool: {
    marginBottom: 16,
  },
  paper: {
    padding: 8,
  },
  choose: {
    float: "right",
    marginTop: 15,
    marginBottom: 15,
    "& .btns": {
      marginLeft: 8,
    },
  },
}));

export async function getServerSideProps(ctx) {
  let coaches = {};

  const token = parseCookies(ctx)?.token_admin;
  if (token) {
    const authorize = JSON.parse(token);

    const coachRes = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/coaches`,
      {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      }
    );
    coaches = await coachRes.json();
  }
  return {
    props: {
      coaches,
    },
  };
}
const Students = ({ coaches }) => {
  const classes = useStyles();
  const [query, setQuery] = React.useState("");
  const [page, setPage] = React.useState(1);
  const [classId, setClassId] = React.useState();
  const [coachId, setCoachId] = React.useState();
  const [allStudents, setAllStudents] = React.useState([]);

  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/students?page=${page}&name=${query}&classId=${classId}&coachId=${coachId}`,
    fetcher
  );
  const allClasses = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/class?coachId=${coachId}`,
    fetcher
  ).data;

  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data.data).then((data) => {
        setAllStudents(data);
      });
    }
  }, [data]);
  if (error) return "Error occured.";
  console.log(data);
  return (
    <Paper className={classes.root}>
      <div className={classes.tool}>
        <Grid container spacing={1}>
          <Grid item xs={12} sm={4}>
            <SearchBox query={query} setQuery={setQuery} />
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl
              fullWidth
              size="small"
              variant="filled"
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-filled-label">
                Coach
              </InputLabel>
              <Select
                labelId="demo-simple-select-filled-label"
                id="demo-simple-select-filled"
                value={coachId}
                onChange={(e) => setCoachId(e.target.value)}
              >
                <MenuItem>Unselected</MenuItem>
                {coaches?.map((coach, index) => {
                  return (
                    <MenuItem key={index} value={coach._id}>
                      {coach.name}
                    </MenuItem>
                  );
                })}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl
              fullWidth
              size="small"
              variant="filled"
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-filled-label">
                Class
              </InputLabel>
              <Select
                labelId="demo-simple-select-filled-label"
                id="demo-simple-select-filled"
                value={classId}
                onChange={(e) => setClassId(e.target.value)}
              >
                <MenuItem>Unselected</MenuItem>
                {allClasses?.data?.map((coach, index) => {
                  return (
                    <MenuItem key={index} value={coach._id}>
                      {coach.name}
                    </MenuItem>
                  );
                })}
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </div>
      <Grid container justifyContent="center">
        <Grid item xs={12}>
          {allStudents?.length === 0 ? (
            <div style={{ width: 400, height: 450, margin: "0 auto" }}>
              <Image
                src="/images/co-worker.svg"
                width={400}
                height={450}
                alt="unknown"
              />
            </div>
          ) : (
            <>
              {data ? (
                <StudentList
                  students={allStudents}
                  pages={data?.pages}
                  page={page}
                  setPage={setPage}
                />
              ) : (
                <SabaiCodeLoading />
              )}
            </>
          )}
        </Grid>
      </Grid>
    </Paper>
  );
};

export default Students;
