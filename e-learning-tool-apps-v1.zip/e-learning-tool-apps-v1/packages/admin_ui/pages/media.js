import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import { Dialog } from "@mui/material";
import MediaForm from "../components/containers/forms/MediaForm";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import React from "react";
import { ConfirmDialog } from "../components/presentations/dialogs";
import { types, subTypes } from "../utils/constants/media";
import SabaiCodeTable from "../components/presentations/tables/SabaiCodeTable";
import SabaiCodeLoading from "../components/presentations/loading";
import useSWR from "swr";
import unauthFetcher from "../utils/func/api/unauthFetch";
import { convertFilePathToURL } from "../utils/func/s3";
import useSocket from "../utils/func/socket/useSocket";
const MediaPage = ({ user }) => {
  const [open, setOpen] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [updateData, setUpdateData] = React.useState(null);
  const [disable, setDisable] = React.useState(false);
  const [id, setID] = React.useState(null);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [medias, setMedias] = React.useState([]);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [query, setQuery] = React.useState({});
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/media?page=${page}&&disable=${disable}&&type=${query.type}&&subType=${query.subType}`,
    unauthFetcher
  );
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  React.useEffect(() => {
    console.log(data);
    const getPostBySocket = async () => {
      if (data?.data) {
        convertFilePathToURL(data.data).then((res) => {
          setMedias(res);
        });
      }
    };
    getPostBySocket();
  }, [data]);
  React.useEffect(() => {
    if (socket) {
      socket.on("media", (data) => {
        convertFilePathToURL(data).then((res) => {
          setMedias(res);
        });
      });
    }
  }, [socket]);
  React.useEffect(() => {
    document.title = `Media `;
  }, []);
  if (error) return `${error}`;
  if (!data) return <SabaiCodeLoading />;

  return (
    <Box>
      <Box
        style={{
          padding: 16,
          borderRadius: 16,
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 8,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
      >
        <Button
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
          startIcon={<AddCircleIcon />}
          variant="contained"
        >
          Upload
        </Button>
        <div style={{ display: "flex", gap: 20 }}>
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Type</InputLabel>
            <Select
              labelId="statusl"
              id="status"
              value={query.type}
              onChange={(e) => {
                setQuery((prev) => ({ ...prev, type: e.target.value }));
              }}
            >
              <MenuItem value={null}>unselected</MenuItem>
              {types.map((type) => {
                return (
                  <MenuItem key={type} value={type}>
                    {type}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Sub-Type</InputLabel>
            <Select
              labelId="statusl"
              id="subType"
              value={query.subType}
              onChange={(e) => {
                setQuery((prev) => ({ ...prev, subType: e.target.value }));
              }}
            >
              <MenuItem value={null}>unselected</MenuItem>
              {subTypes.map((type) => {
                return (
                  <MenuItem key={type} value={type}>
                    {type}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Status</InputLabel>
            <Select
              labelId="statusl"
              id="status"
              value={disable}
              onChange={(e) => {
                setDisable(e.target.value);
              }}
            >
              <MenuItem value={false}>Active</MenuItem>
              <MenuItem value={true}>Unactive</MenuItem>
            </Select>
          </FormControl>
        </div>
      </Box>

      <SabaiCodeTable
        editFunc={(data) => {
          setUpdateData(data);
          setOpen(true);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setID(data._id);
          setOpenDelete(true);
          setAnchorEl(null);
        }}
        disable={disable}
        columns={columns}
        data={medias}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        page={page}
        setPage={setPage}
        pages={data?.pages}
      />
      <Dialog scroll="body" open={open} onClose={() => setOpen(false)}>
        <MediaForm
          query={{ page, disable }}
          socket={socket}
          updateData={updateData}
          onClose={() => setOpen(false)}
        />
      </Dialog>
      <ConfirmDialog
        module={"media"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <ConfirmDialog
        module={"media"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
    </Box>
  );
};

export default MediaPage;

const columns = [
  {
    coverFileName: true,
    width: 150,
    name: "Name",
    align: "left",
    attribute: "name",
  },
  {
    width: 75,
    name: "Type",
    align: "center",
    attribute: "type",
  },
  {
    width: 100,
    name: "Sub-Type",
    align: "left",
    attribute: "subType",
  },
  {
    width: 100,
    name: "Date",
    align: "center",
    attribute: "date",
  },
  {
    width: 200,
    name: "Description",
    align: "right",
    attribute: "description",
  },
  {
    width: 200,
    name: "Link",
    align: "right",
    attribute: "link",
  },
];
