import React from "react";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";

import useSWR from "swr";
import useSocket from "../../utils/func/socket/useSocket";
import fetcher from "../../utils/func/api/getDataFunc";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import updateDataFunc from "../../utils/func/api/updateDataFunc";
import SabaiCodeTable from "../../components/presentations/tables/SabaiCodeTable";
import SabaiCodeLoading from "../../components/presentations/loading";
const MessagePage = ({ user }) => {
  const [disable, setDisable] = React.useState(false);
  const [id, setID] = React.useState(null);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [status, setStatus] = React.useState(false);
  const [contacts, setContacts] = React.useState([]);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/contact_us?page=${page}&status=${status}&disable=${disable}`,
    fetcher
  );
  const handleChangeStatus = async (contact) => {
    try {
      await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/contact_us/${contact._id}`,
        {
          status: !contact.status,
        }
      );
      socket.emit("meta-contact_us", { page, disable, status });
    } catch (error) {
      console.log(error);
    }
  };

  React.useEffect(() => {
    // console.log(data);
    const getPostBySocket = async () => {
      if (data?.data) {
        setContacts(data.data);
      }
    };
    getPostBySocket();
  }, [data]);
  React.useEffect(() => {
    if (socket) {
      socket.on("contact_us", (data) => {
        setContacts(data);
      });
    }
  }, [socket]);
  if (error) return `${error}`;
  if (!data) return <SabaiCodeLoading />;

  return (
    <Box>
      <Box
        style={{
          padding: 16,
          borderRadius: 16,
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 8,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
      >
        <FormControl variant="standard" style={{ minWidth: 100 }}>
          <InputLabel id="status">Contact Status</InputLabel>
          <Select value={status} onChange={(e) => setStatus(e.target.value)}>
            <MenuItem>unslected</MenuItem>
            <MenuItem value={true}>Contacted</MenuItem>
            <MenuItem value={false}>Uncontacted</MenuItem>
          </Select>
        </FormControl>
        <FormControl variant="standard" style={{ minWidth: 100 }}>
          <InputLabel id="status">Status</InputLabel>
          <Select
            labelId="statusl"
            id="status"
            value={disable}
            onChange={(e) => {
              setDisable(e.target.value);
              setPage(1);
            }}
          >
            <MenuItem value={false}>Active</MenuItem>
            <MenuItem value={true}>Inactive</MenuItem>
          </Select>
        </FormControl>
      </Box>
      <SabaiCodeTable
        changeStatusFunc={(data) => {
          handleChangeStatus(data);
          setAnchorEl(null);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setOpenDelete(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        disable={disable}
        status={status}
        page={page}
        setPage={setPage}
        columns={columns}
        data={contacts}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
      />

      <ConfirmDialog
        module={"contact_us"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable, status }}
        socket={socket}
      />
      <ConfirmDialog
        module={"contact_us"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable, status }}
        socket={socket}
      />
    </Box>
  );
};

export default MessagePage;
const columns = [
  {
    width: 150,
    name: "Name",
    align: "left",
    attribute: "name",
  },

  {
    width: 100,
    name: "Subject",
    align: "left",
    attribute: "subject",
    isName: true,
  },
  {
    width: 150,
    name: "Email",
    align: "left",
    attribute: "email",
  },

  {
    width: 200,
    name: "Message",
    align: "left",
    attribute: "message",
  },

  {
    width: 100,
    name: "created At",
    align: "left",
    attribute: "createdAt",
  },
  {
    width: 100,
    name: "Time",
    align: "left",
    attribute: "createdAt",
  },
  {
    width: 75,
    name: "Status",
    align: "left",
    attribute: "status",
  },
];
