import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Stack,
} from "@mui/material";
import { Dialog } from "@mui/material";
import ContactHistoryForm from "../../components/containers/forms/ContactHistoryForm";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import React from "react";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import updateDataFunc from "../../utils/func/api/updateDataFunc";
import SabaiCodeTable from "components/presentations/tables/SabaiCodeTable";
import useSWR from "swr";
import fetcher from "utils/func/api/getDataFunc";
import SabaiCodeLoading from "components/presentations/loading";
import useSocket from "utils/func/socket/useSocket";
const ContactHistory = () => {
  const [open, setOpen] = React.useState(false);
  const [updateData, setUpdateData] = React.useState(null);
  const [disable, setDisable] = React.useState(false);
  const [id, setID] = React.useState(null);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const [status, setStatus] = React.useState();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [page, setPage] = React.useState(1);
  const [contacts, setContacts] = React.useState([]);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);

  const changeStatusFunc = async (data) => {
    const status = !data.status;
    await updateDataFunc(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/contact_history/status/${status}/${data._id}`
    );
    setAnchorEl(null);
    socket.emit("meta-contact_history", { page, status, disable });
  };

  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/contact_history?page=${page}&status=${status}&disable=${disable}`,
    fetcher
  );

  React.useEffect(() => {
    if (data?.data) {
      console.log(data);
      setContacts(data.data);
    }
  }, [data]);
  React.useEffect(() => {
    if (socket) {
      socket.on("contact_history", (data) => {
        setContacts(data);
      });
    }
  }, [socket]);
  if (error) return `${error}`;
  if (!data) return <SabaiCodeLoading />;

  return (
    <Box>
      <Box
        style={{
          padding: 16,
          borderRadius: 16,
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 8,
          background: "linear-gradient(to right,#12c2e9,#5DE7)",
        }}
      >
        <Button
          onClick={() => {
            setOpen(true);
            setUpdateData(null);
          }}
          startIcon={<AddCircleIcon />}
          variant="contained"
        >
          Contact
        </Button>
        <Stack direction={"row"} alignItems="center" spacing={2}>
          <FormControl variant="standard" style={{ minWidth: 150 }}>
            <InputLabel id="status">Contact Status</InputLabel>
            <Select value={status} onChange={(e) => setStatus(e.target.value)}>
              <MenuItem>unslected</MenuItem>
              <MenuItem value={true}>Contacted</MenuItem>
              <MenuItem value={false}>Uncontacted</MenuItem>
            </Select>
          </FormControl>
          <FormControl variant="standard" style={{ minWidth: 100 }}>
            <InputLabel id="status">Status</InputLabel>
            <Select
              value={disable}
              onChange={(e) => setDisable(e.target.value)}
            >
              <MenuItem value={false}>Active</MenuItem>
              <MenuItem value={true}>Inactive</MenuItem>
            </Select>
          </FormControl>
        </Stack>
      </Box>

      <SabaiCodeTable
        editFunc={(data) => {
          setUpdateData(data);
          setOpen(true);
        }}
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);

          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setOpenDelete(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        changeStatusFunc={(data) => changeStatusFunc(data)}
        columns={columns}
        data={contacts}
        disable={disable}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        page={page}
        setPage={setPage}
        pages={data.pages}
      />

      <Dialog open={open} onClose={() => setOpen(false)}>
        <ContactHistoryForm
          query={{ page, disable }}
          socket={socket}
          updateData={updateData}
          onClose={() => setOpen(false)}
        />
      </Dialog>
      <ConfirmDialog
        module={"contact_history"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <ConfirmDialog
        module={"contact_history"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
    </Box>
  );
};

export default ContactHistory;
const columns = [
  {
    width: 150,
    name: "Name",
    align: "left",
    attribute: "name",
  },

  {
    width: 100,
    name: "Tel",
    align: "left",
    attribute: "tel",
  },
  {
    width: 150,
    name: "Email",
    align: "left",
    attribute: "email",
  },
  {
    width: 100,
    name: "Know by",
    align: "left",
    attribute: "knownBy",
  },
  {
    width: 100,
    name: "Course",
    align: "left",
    attribute: "courseId",
    isName: true,
  },

  {
    width: 200,
    name: "Description",
    align: "left",
    attribute: "description",
  },
  {
    width: 75,
    name: "Status",
    align: "left",
    attribute: "status",
  },
  {
    width: 125,
    name: "created At",
    align: "right",
    attribute: "createdAt",
  },
];
