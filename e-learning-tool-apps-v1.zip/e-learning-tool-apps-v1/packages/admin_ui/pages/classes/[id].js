import React from "react";
import { Box, Grid, Paper } from "@mui/material";
import { TabNavigation } from "../../components/presentations/tabs";
import { Message } from "../../components/presentations/feedback";
import { BackgroundCard } from "../../components/presentations/cards";
import { makeStyles } from "@mui/styles";
import AllLessons from "../../components/containers/classes/AllLessons";
import { parseCookies } from "nookies";
import { useRouter } from "next/router";
export const getServerSideProps = async (ctx) => {
  let allClass = {};
  const id = ctx.query.id;
  const token = parseCookies(ctx)?.token_admin;
  if (token) {
    const authorize = JSON.parse(token || "{}");
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/class?id=${id}`,
      {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      }
    );

    allClass = await res.json();
  }

  return {
    props: {
      allClass,
      classId: id,
    },
  };
};
const useStyles = makeStyles((theme) => ({
  content: {
    marginTop: 30,
  },
}));
const ClassDetail = ({ allClass, token, classId }) => {
  const classes = useStyles();
  const router = useRouter();
  const tab = router.query.tab || "invoices";

  return (
    <div>
      <Message open={true} />
      <TabNavigation classId={classId} tab={tab} />
      {tab === "invoices" && <Box> Invoices</Box>}
      {tab == "lessons" && <AllLessons course={allClass.data} token={token} />}
      <Grid container justifyContent="center">
        <Grid item xs={11}>
          {tab === "stream" && (
            <div className={classes.content}>
              <BackgroundCard src="/404.svg" title="SabaiCode Boot Camp" />
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  );
};

export default ClassDetail;
