import React, { useState } from "react";
import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Box,
} from "@mui/material";
import { ConfirmDialog } from "../../components/presentations/dialogs";
import { convertFilePathToURL } from "../../utils/func/s3";
import useSWR from "swr";
import fetcher from "../../utils/func/api/getDataFunc";
import SabaiCodeLoading from "../../components/presentations/loading";
import SabaiCodeTable from "components/presentations/tables/SabaiCodeTable";
import useSocket from "utils/func/socket/useSocket";
export default function ClassesPage() {
  const [allClasses, setAllClasses] = React.useState([]);
  const [status, setStatus] = React.useState(true);
  const [page, setPage] = React.useState(1);
  const [id, setID] = React.useState();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [disable, setDisable] = React.useState(false);
  const [openDisable, setOpenDisable] = React.useState(false);
  const [openDelete, setOpenDelete] = React.useState(false);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/class?status=${status}&page=${page}&disable=${disable}`,
    fetcher
  );

  React.useEffect(() => {
    if (data?.data) {
      convertFilePathToURL(data?.data).then((res) => {
        if (res) {
          setAllClasses(res);
        }
      });
    }
  }, [data]);

  React.useEffect(() => {
    if (socket) {
      socket.on("class", (data) => {
        console.log("===Class Socket===", data);
        convertFilePathToURL(data).then((res) => {
          setAllClasses(res);
        });
      });
    }
  }, [socket]);

  React.useEffect(() => {
    document.title = "Class";
  }, []);
  if (error) return "Error has occurred.";
  if (!data) return <SabaiCodeLoading />;
  return (
    <Box>
      <Stack
        sx={{
          borderRadius: 2,
          p: 2,
          mb: 3,
          background: "linear-gradient(to right, #12c2e9,#5DE7)",
        }}
        direction={"row"}
        alignItems="center"
        justifyContent={"space-between"}
      >
        <FormControl variant="standard" style={{ minWidth: 100 }}>
          <InputLabel id="status">Status</InputLabel>
          <Select
            labelId="status"
            id="status"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
          >
            <MenuItem value={true}>Present</MenuItem>
            <MenuItem value={false}>Past</MenuItem>
          </Select>
        </FormControl>
        <FormControl variant="standard" style={{ minWidth: 100 }}>
          <InputLabel id="status">Status</InputLabel>
          <Select
            labelId="status"
            id="status"
            value={disable}
            onChange={(e) => {
              setDisable(e.target.value);
              setPage(1);
            }}
          >
            <MenuItem value={false}>Active</MenuItem>
            <MenuItem value={true}>Inactive</MenuItem>
          </Select>
        </FormControl>
      </Stack>

      <SabaiCodeTable
        disableFunc={(data) => {
          setOpenDisable(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        deleteFunc={(data) => {
          setOpenDelete(true);
          setID(data._id);
          setAnchorEl(null);
        }}
        disable={disable}
        columns={columns}
        data={allClasses}
        pages={data.pages}
        page={page}
        setPage={setPage}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        view="classes"
      />
      <ConfirmDialog
        module={"class"}
        open={openDisable}
        status={disable}
        onClose={() => setOpenDisable(false)}
        disable={false}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
      <ConfirmDialog
        module={"class"}
        open={openDelete}
        status={disable}
        onClose={() => setOpenDelete(false)}
        disable={openDelete}
        _id={id}
        query={{ page, disable }}
        socket={socket}
      />
    </Box>
  );
}

const columns = [
  {
    coverFileName: true,
    width: 175,
    name: "Name",
    align: "left",
    attribute: "name",
  },

  {
    width: 150,
    name: "startDate",
    align: "left",
    attribute: "startDate",
  },
  {
    width: 150,
    name: "endDate",
    align: "left",
    attribute: "endDate",
  },
  {
    width: 50,
    name: "Student",
    align: "left",
    attribute: "studentIds",
    array: true,
  },
  {
    width: 50,
    name: "Code",
    align: "left",
    attribute: "code",
  },
  {
    width: 75,
    name: "Status",
    align: "right",
    attribute: "isActive",
  },
  {
    width: 75,
    name: "Invoice",
    align: "right",
    attribute: "invoices",
    array: true,
  },
  {
    width: 200,
    name: "Description",
    align: "left",
    attribute: "desc",
  },
];
