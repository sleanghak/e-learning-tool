import React, { useState } from "react";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import Link from "@mui/material/Link";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import { makeStyles } from "@mui/styles";
import IconButton from "@mui/material/IconButton";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import InputAdornment from "@mui/material/InputAdornment";
import FormControl from "@mui/material/FormControl";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import { ButtonBase, Typography } from "@mui/material";
import Image from "next/image";
import { loginUser } from "../utils/func/auth/authUser";
import { useRouter } from "next/router";
import jsCookie from "js-cookie";

export default function SignIn() {
  const classes = useStyles();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  async function signIn(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const email = e.target.elements.email.value;
    const password = e.target.elements.password.value;
    try {
      const data = await loginUser(email, password, setError, setLoading);
      console.log(data);
      const user = jsCookie.get("token_admin");
      console.log(user);
      setLoading(false);
    } catch (error) {
      console.error(error);
      setError(error);
      setLoading(false);
    }
  }

  return (
    <Grid container component="main" className={classes.root}>
      <CssBaseline />
      <Grid item xs={12} sm={8} md={4} component={Paper} elevation={6} square>
        <div className={classes.paper}>
          <Image
            src="/images/sabaicode.jpg"
            alt="me"
            width={100}
            height={100}
            className={classes.logo}
          />
          <Typography sx={{ fontWeight: "bold", p: 2 }}>
            Login to <span className="text-rainbow-animation">Admin</span>{" "}
            account
          </Typography>

          <form className={classes.form} onSubmit={signIn}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
            />
            <FormControl required variant="outlined" fullWidth>
              <InputLabel htmlFor="standard-adornment-password">
                Password
              </InputLabel>
              <OutlinedInput
                id="outlined-adornment-password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                name="password"
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? <Visibility /> : <VisibilityOff />}
                    </IconButton>
                  </InputAdornment>
                }
                labelWidth={70}
              />
            </FormControl>
            <div
              style={{
                color: `red`,
              }}
            >
              {error}
            </div>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              className={classes.submit}
              disabled={loading}
            >
              <Typography>{loading ? "Login ..." : "Login"}</Typography>
            </Button>
            <Link
              href="/reset"
              sx={{
                color: "#06BCC1",
                "&:hover": { textDecoration: "underline" },
              }}
            >
              Forgot password?
            </Link>

            <br />
          </form>
        </div>
      </Grid>

      <Grid item xs={false} sm={4} md={8} className={classes.image} />
    </Grid>
  );
}

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100vh",
  },
  image: {
    backgroundImage: `url('/images/welcome.svg')`,
    backgroundRepeat: "no-repeat",
    backgroundColor:
      theme.palette.type === "light"
        ? theme.palette.grey[50]
        : theme.palette.grey[50],
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundSize: "80%",
  },
  paper: {
    margin: theme.spacing(8, 4),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  margin: {
    margin: theme.spacing(1),
  },
  forgotpwd: {
    textAlign: `right`,
  },
  logo: {
    borderRadius: 8,
  },
}));
