const filterObjectAtt = (obj) => {
  for (let value in obj) {
    if (!obj[`${value}`]) {
      delete obj[`${value}`];
    }
  }
  return obj;
};

export default filterObjectAtt;
