export default function isPublicRoute(route) {
  let status = false;

  if (
    route === "/" ||
    route === "/auth/signup" ||
    route === "/auth/verify" ||
    route === "/404" ||
    route === "/reset" ||
    route === "/reset/[token]"
  ) {
    status = true;
  }

  return status;
}
