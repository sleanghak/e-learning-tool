export default function getVideoDuration(control, setDuration) {
  window.URL = window.URL || window.webkitURL;
  let duration;
  var video = document.createElement("video");
  video.preload = "metadata";
  video.onloadedmetadata = function() {
    window.URL.revokeObjectURL(video.src);
    duration = (video.duration / 60).toFixed(2);
    setDuration(duration);
  };

  video.src = URL.createObjectURL(control);
}
