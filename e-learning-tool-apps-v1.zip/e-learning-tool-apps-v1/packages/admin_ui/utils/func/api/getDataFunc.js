import jsCookie from "js-cookie";

const fetcher = async (url) => {
  const token = jsCookie.get("token_admin");
  let data = {};
  try {
    if (token) {
      const authorize = JSON.parse(token);
      const res = await fetch(url, {
        headers: {
          "x-access-token": authorize.accessToken,
        },
      });
      data = await res.json();
    }
  } catch (error) {
    console.error(error)
  }
  return data;
};

export default fetcher;
