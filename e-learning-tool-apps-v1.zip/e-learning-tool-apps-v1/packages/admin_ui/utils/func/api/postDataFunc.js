import jsCookie from "js-cookie";
import { customToast } from "./../../../components/presentations/toasts";
const postDataFunc = async (url, body) => {
  const token = jsCookie.get("token_admin");
  let data = {};
  try {
    if (token) {
      const authorize = JSON.parse(token);
      const res = await fetch(url, {
        method: "post",
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
          "x-access-token": authorize.accessToken,
        },
        body: JSON.stringify(body),
      });
      data = await res.json();
      console.log(data);
      customToast(data.statusCode, data.message);
    }
  } catch (error) {
    console.error(error);
    customToast(undefined, "Internal Server Error.");
  }
  return data;
};

export default postDataFunc;
