import uploadFile from "./uploadFile";
async function uploadFiles(path, files, setProgress, setMessage) {
  let res = [];
  if (files.length > 0) {
    for (const file of files) {
      const url = await uploadFile(path, file, setProgress, setMessage);
      res.push(url.key);
    }
  } else {
    setMessage("Please select aleast one file.");
  }
  return res;
}
export default uploadFiles;
