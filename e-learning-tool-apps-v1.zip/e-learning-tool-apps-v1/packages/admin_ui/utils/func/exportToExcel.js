import XLSX from "xlsx";
const exportToExcel = (label, data, tabName = "All Forms") => {
  console.log("Export files");
  let AllAttendances = [["No", ...label]];
  data.forEach((att, index) => {
    let attendanceArray = [index + 1];
    label.forEach((item) => {
      if (item == "salary") {
        const salary =
          att.default_salary + att.total_hours * att.price_per_hour;
        attendanceArray.push(salary);
        return;
      }
      attendanceArray.push(att[item]);
    });
    AllAttendances.push(attendanceArray);
  });
  const wb = XLSX.utils.book_new();
  const wsAll = XLSX.utils.aoa_to_sheet(AllAttendances);
  XLSX.utils.book_append_sheet(wb, wsAll, tabName);
  XLSX.writeFile(wb, `${tabName}.xlsx`);
};
export default exportToExcel;
