import changePassword from "./changePassword";
export{
    changePassword
}