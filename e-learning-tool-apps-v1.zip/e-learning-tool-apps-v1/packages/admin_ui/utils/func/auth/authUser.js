import axios from "axios";
import catchErrors from "./../error/catchErrors";
import jsCookie from "js-cookie";
import { setCookie } from "nookies";

export const registerUser = async (
  user, // user object
  setError,
  setLoading
) => {
  try {
    const res = await axios.post(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/signup`,
      { user }
    );
  } catch (error) {
    setError(catchErrors(error));
  }
  setLoading(false);
};

export const loginUser = async (email, password, setError, setLoading) => {
  setLoading(true);
  try {
    const res = await axios.post(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/signin`,
      { email, password }
    );

    if (res.data?.data.role == "ROLE_ADMIN") {
      console.log(res);
      setToken(res.data?.data);
    } else {
      setError("you are not admin");
    }
  } catch (error) {
    setError(catchErrors(error).toString());
  }
  setLoading(false);
};

export const redirectUser = (ctx, location) => {
  if (ctx.req) {
    ctx.res.writeHead(302, { Location: location });
    ctx.res.end();
  } else {
    if (typeof window !== "undefined") {
      // Client-side-only code
      window.location.href = location; // router.push("/")
    }
  }
};

const setToken = (token) => {
  setCookie(null, "token_admin", token);
  jsCookie.set("token_admin", JSON.stringify(token));
  if (typeof window !== "undefined") {
    // Client-side-only code
    window.location.href = "/dashboard";
  }
};

export const logoutUser = (email) => {
  jsCookie.set("userEmail", email.toString());
  jsCookie.remove("token_admin");
  window.location.href = "/";
};

export const registerCoach = async (user, setError, setLoading, onClose) => {
  try {
    const res = await axios.post(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/signup`,
      { ...user }
    );
    onClose();
  } catch (error) {
    setError(catchErrors(error));
  }
  setLoading(false);
};
