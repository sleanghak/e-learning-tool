const pieData=[
    {
      "id": "Express Course",
      "label": "Express Course",
      "value": 5,
      "color": "#F6C208"
    },
    {
      "id": "Basic Web Development",
      "label": "Basic Web Development",
      "value": 10,
      "color": "#25C9B5"
    },
   
    {
      "id": "Front-End Part I",
      "label": "Front-End Part I",
      "value": 3,
      "color": "#F26336"
    },
    {
      "id": "Front-End Part II",
      "label": "Front-End Part II",
      "value": 4,
      "color": "#0CF43F"
    },
    {
      "id": "Back-End PartI",
      "label": "Back-End PartI",
      "value": 2,
      "color": "#5D63FF"
    },
    {
      "id": "Back-End Part II",
      "label": "Back-End Part II",
      "value": 0,
      "color": "#87FEA1"
    },
    {
      "id": "Back-End Part III",
      "label": "Back-End Part III",
      "value": 5,
      "color": "#5D63FF"
    }
  ];
function horizontalBarData(videos,lessons,courses,subjects){
  return(
    [
      {
        "country": "Video",
        "Road": videos,
        "color": "#87FEA1",
        
      },
      {
        "country": "Lesson",
        "Road Update": lessons,
        "color": "#898DFE",
       
      },
      {
        "country": "Course",
        "Bridge": courses,
        "color": "#06BCC1"
      },
      {
        "country": "Subject",
        "Road Update": subjects,
        "color": "#898DFE",
       
      },
     
    ]
  )
}


const singleLineData=[
    
    {
      "id": "us",
      "color": "hsl(218, 70%, 50%)",
      "data": [
        {
          "x": "Jan",
          "y":0
        },
        {
          "x": "Feb",
          "y": 120
        },
        {
          "x": "Mar",
          "y": 111
        },
        {
          "x": "Apr",
          "y": 46
        },
        {
          "x": "May",
          "y": 203
        },
        {
          "x": "June",
          "y": 214
        },
        {
          "x": "July",
          "y": 151
        },
        {
          "x": "Aug",
          "y": 222
        },
        {
          "x": "Sep",
          "y": 78
        },
        {
          "x": "Oct",
          "y": 172
        },
        {
          "x": "Nov",
          "y": 117
        },
        {
          "x": "Dec",
          "y": 117
        },
        
      ]
    },
   
  ]
  const doubleData=[
    {
      "id": "Road",
      "color": "#0C15F4",
      "data": [
        {
          "x": "Jan",
          "y": 255
        },
        {
          "x": "Feb",
          "y": 120
        },
        {
          "x": "Mar",
          "y": 111
        },
        {
          "x": "Apr",
          "y": 46
        },
        {
          "x": "May",
          "y": 203
        },
        {
          "x": "June",
          "y": 214
        },
        {
          "x": "July",
          "y": 151
        },
        {
          "x": "Aug",
          "y": 222
        },
        {
          "x": "Sep",
          "y": 78
        },
        {
          "x": "Oct",
          "y": 172
        },
        {
          "x": "Nov",
          "y": 117
        },
        {
          "x": "Dec",
          "y": 90
        },
        
      ]
    },
    {
      "id": "Bridge",
      "color": "hsl(117, 70%, 50%)",
      "data": [
        {
          "x": "Jan",
          "y": 250
        },
        {
          "x": "Feb",
          "y": 110
        },
        {
          "x": "Mar",
          "y": 130
        },
        {
          "x": "Apr",
          "y": 64
        },
        {
          "x": "May",
          "y": 190
        },
        {
          "x": "June",
          "y": 200
        },
        {
          "x": "July",
          "y": 160
        },
        {
          "x": "Aug",
          "y": 200
        },
        {
          "x": "Sep",
          "y": 78
        },
        {
          "x": "Oct",
          "y": 172
        },
        {
          "x": "Nov",
          "y": 117
        },
        {
          "x": "Dec",
          "y": 100
        },
      ]
    },
   
   
  ]
  export {
      pieData,
      horizontalBarData,
      singleLineData,
      doubleData
  }