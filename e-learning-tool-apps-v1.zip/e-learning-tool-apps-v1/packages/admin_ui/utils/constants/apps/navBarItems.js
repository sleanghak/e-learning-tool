import DashboardIcon from "@mui/icons-material/Dashboard";
import ClassIcon from "@mui/icons-material/Class";
import AssignmentOutlinedIcon from "@mui/icons-material/AssignmentOutlined";
import GroupsIcon from "@mui/icons-material/Groups";
import SettingsApplicationsOutlinedIcon from "@mui/icons-material/SettingsApplicationsOutlined";
import PeopleAltOutlinedIcon from "@mui/icons-material/PeopleAltOutlined";
import BallotIcon from "@mui/icons-material/Ballot";
import SchoolIcon from "@mui/icons-material/School";
import PostAddIcon from "@mui/icons-material/PostAdd";
import ReceiptIcon from "@mui/icons-material/Receipt";
import ContactPhoneIcon from "@mui/icons-material/ContactPhone";
import ContactMailIcon from "@mui/icons-material/ContactMail";
import MovieIcon from "@mui/icons-material/Movie";
import GroupWorkIcon from "@mui/icons-material/GroupWork";
import PersonSearchSharpIcon from "@mui/icons-material/PersonSearchSharp";
import WorkIcon from "@mui/icons-material/Work";

const navBarItems = [
  {
    text: "Dashboard",
    icon: <DashboardIcon />,
    path: "/dashboard",
    sublist: [],
  },
  {
    text: "Courses",
    icon: <AssignmentOutlinedIcon />,
    path: "/courses",
    sublist: [],
  },
  {
    text: "Department",
    icon: <SchoolIcon />,
    path: "/departments",
    sublist: [],
  },
  {
    text: "Classes",
    icon: <ClassIcon />,
    path: "/classes",
    sublist: [],
  },
  {
    text: "Invoice",
    icon: <ReceiptIcon />,
    path: "/invoice",
    sublist: [],
  },
  {
    text: "People",
    icon: <GroupsIcon />,
    // path: "/students",
    sublist: [
      {
        text: "Students",
        icon: <PersonSearchSharpIcon />,
        path: "/students",
      },
      {
        text: "Student Work",
        icon: <GroupWorkIcon />,
        path: "/students/student-work",
      },
      {
        text: "Coaches",
        icon: <PeopleAltOutlinedIcon />,
        path: "/coaches",
      },
      {
        text: "Partners",
        icon: <GroupWorkIcon />,
        path: "/people/partners",
      },
    ],
  },
  {
    text: "Contact",
    icon: <ContactPhoneIcon />,
    path: "/contact_history",
    sublist: [
      {
        text: "Direct Contact",
        icon: <PersonSearchSharpIcon />,
        path: "/contact/contact_history",
      },
      {
        text: "Web Contact",
        icon: <ContactMailIcon />,
        path: "/contact/contact_us",
      },
    ],
  },
  {
    text: "News",
    icon: <PostAddIcon />,
    path: "/post",
    sublist: [
      {
        text: "Upcoming Class",
        icon: <PostAddIcon />,
        path: "/news/upcoming-class",
      },
      {
        text: "News",
        icon: <WorkIcon />,
        path: "/news",
      },
    ],
  },

  {
    text: "Media",
    icon: <MovieIcon />,
    path: "/media",
    sublist: [],
  },

  {
    text: "Inventory",
    icon: <BallotIcon />,
    path: "/inventory",
    sublist: [],
  },
  {
    text: "Setting",
    icon: <SettingsApplicationsOutlinedIcon />,
    path: "/setting",
    sublist: [],
  },
];

export { navBarItems };
