const types = ["press", "gallery", "video"];
const subTypes = ["student_activity", "school_activity", "firechat"];

export { types, subTypes };
