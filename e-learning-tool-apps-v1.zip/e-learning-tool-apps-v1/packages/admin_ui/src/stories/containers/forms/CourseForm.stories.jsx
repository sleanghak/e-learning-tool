import { CourseForm } from "../../../../components/containers/forms";

export default {
    title:"containers/forms/CourseForm",
    component:CourseForm
}

const Template= (args)=> <CourseForm {...args}/>

export const Primary = Template.bind({});