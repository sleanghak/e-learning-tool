import { LoginForm } from "../../../../components/containers/forms";

export default {
    title:'containers/forms/LoginForm',
    component : LoginForm
}

const Template = (args)=><LoginForm {...args}/>
export const Primary = Template.bind({})