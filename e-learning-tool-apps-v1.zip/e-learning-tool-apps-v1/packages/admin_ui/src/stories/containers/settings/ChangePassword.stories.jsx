import ChangePassword from "../../../../components/containers/settings/ChangePassword";
export default {
    title:'containers/settings/ChangePassword',
    component:ChangePassword
}

const Template= (args)=><ChangePassword {...args}/>
export const Primary= Template.bind({})