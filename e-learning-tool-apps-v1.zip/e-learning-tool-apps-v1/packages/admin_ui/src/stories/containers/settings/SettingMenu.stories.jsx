import SettingMenu from "../../../../components/containers/settings/SettingMenu";
import { RecoilRoot } from "recoil";
export default {
    title:'containers/setting/SettingMenu',
    component:SettingMenu
}

const Template= (args)=><RecoilRoot><SettingMenu {...args}/></RecoilRoot>

export const Primary = Template.bind({})