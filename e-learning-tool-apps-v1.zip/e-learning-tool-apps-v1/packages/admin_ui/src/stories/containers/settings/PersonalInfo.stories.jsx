import PersonalInfo from "../../../../components/containers/settings/PersonalInfo";
import { RecoilRoot } from "recoil";
export default {
    title:'containers/settings/PersonalInfo',
    component:PersonalInfo
}

const Template= (args)=><RecoilRoot><PersonalInfo {...args}/></RecoilRoot>

export const Primary = Template.bind({})