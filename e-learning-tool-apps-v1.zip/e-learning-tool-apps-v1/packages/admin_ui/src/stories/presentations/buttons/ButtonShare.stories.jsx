import ShareButton from "../../../../components/presentations/buttons/ButtonShare";
export default {
    title:'presentations/buttons/ShareButton',
    component:ShareButton
}

const Template= (args)=><ShareButton {...args}/>
export const Primary = Template.bind({})