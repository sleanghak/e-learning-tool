import { GroupSocialMedia } from "../../../../components/presentations";
export default {
    title:'presentations/buttons/GroupSocialMedia',
    component:GroupSocialMedia
}

const Template = (args)=><GroupSocialMedia {...args}/>

export const Primary = Template.bind({})