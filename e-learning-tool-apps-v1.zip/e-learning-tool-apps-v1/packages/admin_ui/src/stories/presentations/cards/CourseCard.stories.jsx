import React from 'react';
import { CourseCard } from '../../../../components/presentations/cards';
export default {
  title: 'presentations/cards/CoursCard',
  component: CourseCard,
}

const Template = (args) => <CourseCard {...args} />

export const Primary = Template.bind({});
