import { VideoLessonCard } from "../../../../components/presentations/cards";

export default{
    title:'presentations/cards/SubjectCard',
    component:VideoLessonCard
}
const Template = (args)=><VideoLessonCard {...args}/>
export const  Primary= Template.bind({})