
import { SubjectCard } from "../../../../components/presentations/cards";

export default{
    title:'presentations/cards/SubjectCard',
    component:SubjectCard
}
const Template = (args)=><SubjectCard {...args}/>
export const  Primary= Template.bind({})