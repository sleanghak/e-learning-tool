import Message from "../../../../components/presentations/feedback/Message";

export default {
    title:'presentations/feedback/Message',
    component:Message
}

const Template = (args)=><Message {...args}/>
export const Primary= Template.bind({})