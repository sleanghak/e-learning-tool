import TabNavigation from "../../../../components/presentations/tabs/TabNavigation";
import { RecoilRoot } from "recoil";
export default {
    title:'presentations/tabs/TabNavigation',
    component:TabNavigation
}

const Template = (args)=><RecoilRoot><TabNavigation {...args}/></RecoilRoot>

export const Primary = Template.bind({})