
import SearchBox from "../../../../components/presentations/searchBox/SearchBox";
export default {
    title:'presentations/searchBox/searchBox',
    component:SearchBox,
}

const Template = (args)=><SearchBox {...args}/>

export const Primary = Template.bind({})