import { ConfirmDialog } from "../../../../components/presentations/dialogs";

export default {
    title:'presentations/dialogs/ConfirmDialog',
    component: ConfirmDialog
}

const Template = (args)=><ConfirmDialog {...args}/>
export const Primary = Template.bind({})