import { LinearProgression } from "../../../../components/presentations/progressions";

export default {
    title:'presentations/progressions/LinearProgression',
    component:LinearProgression
}

const Template = (args)=><LinearProgression {...args}/>

export const Primary = Template.bind({})