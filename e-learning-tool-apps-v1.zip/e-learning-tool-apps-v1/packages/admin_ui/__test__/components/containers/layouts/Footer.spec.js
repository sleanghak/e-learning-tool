import { shallow } from 'enzyme';
import Footer from './../../../../components/containers/layouts/Footer';
import toJSON from 'enzyme-to-json';

describe(('Render Footer'),()=>{
    it ('snaphot',()=>{
        const wrapper = shallow(<Footer/>);
        expect(toJSON (wrapper)).toMatchSnapshot();
    })
})