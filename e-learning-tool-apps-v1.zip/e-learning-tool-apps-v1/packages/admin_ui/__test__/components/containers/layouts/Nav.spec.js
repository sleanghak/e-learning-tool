import { NavBar } from "../../../../components/containers/layouts";
import { shallow } from "enzyme";
import DashboardIcon from "@mui/icons-material/Dashboard";
import AssignmentOutlinedIcon from "@mui/icons-material/AssignmentOutlined";
import { ThemeProvider } from "@mui/material/styles";
import theme from "../../../../styles/theme";
jest.mock("next/router", () => ({
  useRouter() {
    return {
      route: "/",
      pathname: "",
      query: "",
      asPath: "",
      push: jest.fn(),
    };
  },
}));
describe("Navigation Left Side Bar Layout", () => {
  const mockNavBarItems = [
    {
      text: "Dashboard",
      icon: <DashboardIcon />,
      path: "/dashboard",
      sublist: 0,
    },
    {
      texut: "Courses",
      icon: <AssignmentOutlinedIcon />,
      path: "/courses",
      sublist: 0,
    },
  ];
  let wrapper;
  beforeEach(() => {
    wrapper = shallow(
      <ThemeProvider theme={theme}>
        <NavBar navBarItems={mockNavBarItems} />
      </ThemeProvider>
    );
  });
  it("render left side bar", () => {
    expect(wrapper).toMatchSnapshot();
  });
});
