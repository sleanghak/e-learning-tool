import { shallow } from "enzyme";
import toJson from "enzyme-to-json";
import { ThemeProvider } from "@mui/material/styles";
import {
  Layout,
  Header,
  Footer,
  NavBar,
} from "../../../../components/containers/layouts";
import theme from "../../../../styles/theme";
const mock_children = <div>Hello children</div>;
describe("Layout after Login", () => {
  let wrapper;
  beforeAll(() => {
    wrapper = shallow(
      <ThemeProvider theme={theme}>
        <Layout>{mock_children}</Layout>
      </ThemeProvider>
    );
  });
  it("snapshot", () => {
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  //   it("has Header", () => {
  //     expect(wrapper.find(Header).exists()).toBeTruthy();
  //   });
  //   it("has Footer", () => {
  //     expect(wrapper.find(Footer).exists()).toBeTruthy();
  //   });
  //   it("has Navigation Bar", () => {
  //     expect(wrapper.find(NavBar).exists()).toBeTruthy();
  //   });
  //   it("render children", () => {
  //     expect(
  //       wrapper
  //         .find("div")
  //         .at(1)
  //         .text()
  //     ).toBe(mock_children);
  //   });
});
