import { shallow } from "enzyme";
import toJson from "enzyme-to-json";
import { Header } from "../../../../components/containers/layouts";

describe("render header ", () => {
  let wrapper;
  const _mock_app_ = "Admin";
  beforeAll(() => {
    wrapper = shallow(<Header title={_mock_app_} />);
  });
  it("snapshot header", () => {
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  it("has title tag", () => {
    expect(wrapper.find("title")).toBeTruthy();
    expect(wrapper.find("title").text()).toEqual(_mock_app_);
  });
  it("check link tags are used", () => {
    expect(wrapper.find("link")).toHaveLength(4);
  });
  it("logo icon on title", () => {
    const icon = wrapper.find("link").at(0);
    expect(icon.prop("rel")).toBe("shortcut icon");
    expect(icon.prop("href")).toBe("/images/sabaicode.jpg");
    expect(icon.prop("type")).toBe("image/x-icon");
  });
  it("styles of video lib", () => {
    const styles = wrapper.find("link").at(2);
    // expect(styles.prop('rel')).toBe('stylesheet');
    // expect(styles.prop('href')).toBe('https://video-react.github.io/assets/video-react.css');
  });
});
