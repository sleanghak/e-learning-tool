import { shallow } from "enzyme";
import toJson from "enzyme-to-json";
import { HorizontalBarChart } from "../../../../components/containers/dashboards";
describe('render HorizontalBarChart',()=>{
    let wrapper;
    beforeAll(()=>{
        wrapper= shallow(<HorizontalBarChart/>);
    });
    it ('snapshot HorizontalBarChart',()=>{
        expect (toJson(wrapper)).toMatchSnapshot();
    })

    /**
     * @ todo : Check required attributes ...
     */
})