import { shallow } from "enzyme";
import toJson from "enzyme-to-json";
import { LineChart } from "../../../../components/containers/dashboards";
import { ResponsiveLine } from "@nivo/line";
describe("Render LineChart", () => {
  let wrapper;
  beforeAll(() => {
    wrapper = shallow(<LineChart />);
  });

  it("snapshot LineChart", () => {
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  it("check attributes and values", () => {
    expect(wrapper.find(ResponsiveLine).props().axisBottom).toMatchObject({
      legendOffset: 36,
      legendPosition: "middle",
      orient: "bottom",
      tickPadding: 5,
      tickRotation: 0,
      tickSize: 5,
    });
    expect(wrapper.find(ResponsiveLine).props().axisLeft).toMatchObject({
      legendOffset: -40,
      legendPosition: "middle",
      orient: "left",
      tickPadding: 5,
      tickRotation: 0,
      tickSize: 5,
    });

    expect(wrapper.find(ResponsiveLine).props().colors).toEqual(["#0C15F4"]);

    expect(wrapper.find(ResponsiveLine).props().margin).toMatchObject({
      bottom: 25,
      left: 60,
      right: 20,
      top: 15,
    });
  });
});
