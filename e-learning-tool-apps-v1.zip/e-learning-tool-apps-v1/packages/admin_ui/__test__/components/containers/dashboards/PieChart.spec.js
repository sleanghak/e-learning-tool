import { shallow } from "enzyme";
import { PieChart } from "../../../../components/containers/dashboards";
import toJSON from 'enzyme-to-json';
import { ResponsivePie } from '@nivo/pie'
describe('Rendering PieChart',()=>{
    let wrapper;
    beforeAll(()=>{
        wrapper= shallow(<PieChart data={[]}/>);
    });
    it('snapshot PieChart', ()=>{
        expect(toJSON(wrapper)).toMatchSnapshot();
    });
    it('check important attribute & value',()=>{
        expect(wrapper.find(ResponsivePie).props().data).toEqual([]);
        expect(wrapper.find(ResponsivePie).props().activeOuterRadiusOffset).toEqual(8);

        expect(wrapper.find(ResponsivePie).props().arcLabelsSkipAngle).toEqual(10);
        expect(wrapper.find(ResponsivePie).props().arcLabelsTextColor).toMatchObject({
            "from": "color",
        });
        expect(wrapper.find(ResponsivePie).props().arcLinkLabelsColor).toMatchObject({
            "from": "color",
        });
        expect(wrapper.find(ResponsivePie).props().arcLinkLabelsSkipAngle).toEqual(10);
        expect(wrapper.find(ResponsivePie).props().arcLinkLabelsTextColor).toEqual('#333333');
        expect(wrapper.find(ResponsivePie).props().arcLinkLabelsThickness).toEqual(2);
        expect(wrapper.find(ResponsivePie).props().borderWidth).toEqual(1);

        expect(wrapper.find(ResponsivePie).props().colors).toMatchObject({
            "datum": "data.color",
        });
        expect(wrapper.find(ResponsivePie).props().cornerRadius).toEqual(3);
        expect(wrapper.find(ResponsivePie).props().innerRadius).toEqual(0.5);
        expect(wrapper.find(ResponsivePie).props().padAngle).toEqual(0.7);
        expect(wrapper.find(ResponsivePie).props().margin).toMatchObject({
            "bottom": 20,
            "left": 80,
            "right": 80,
            "top": 15,
        });

    });
});

