import { LoginForm } from "../../../../components/containers/forms";
import toJson from "enzyme-to-json";
import { shallow } from "enzyme";
import { ThemeProvider } from "@mui/material/styles";
import theme from "./../../../../styles/theme";
describe("login form component", () => {
  let wrapper;
  beforeEach(() => {
    wrapper = shallow(
      <ThemeProvider theme={theme}>
        <LoginForm />
      </ThemeProvider>
    );
  });

  it("login form render snapshot", () => {
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  //   it("check button content", () => {
  //     expect(wrapper.find('[id="sign-in-btn"]').text()).toEqual("Sign In");
  //     expect(wrapper.find('[id="forgot-pwd"]').text()).toEqual(
  //       "Forgot password?"
  //     );
  //     expect(wrapper.find('[id="signup-btn"]').text()).toEqual(
  //       "Don't have an account? Sign Up"
  //     );
  //   });
});
