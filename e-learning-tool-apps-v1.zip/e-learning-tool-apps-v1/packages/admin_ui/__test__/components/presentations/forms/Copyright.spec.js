import { shallow } from "enzyme";
import toJson from "enzyme-to-json";
import Copyright from "../../../../components/containers/forms/Copyright";
import Link from "next/link";
import { Typography } from "@mui/material";
describe("Render Copyright:", () => {
  let wrapper;
  beforeAll(() => {
    wrapper = shallow(<Copyright />);
  });
  it("Snapshot Copyright", () => {
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  it("link to sabaicode (url)", () => {
    expect(wrapper.find(Link).prop("color")).toEqual("inherit");
    expect(wrapper.find(Link).prop("href")).toEqual("https://sabaicode.com");
  });
  // it("it has content ", () => {
  //   expect(wrapper.find(Typography).text()).toEqual(
  //     "Copyright ©<Link /> " + (new Date().getFullYear().toString() + ".")
  //   );
  // });
});
