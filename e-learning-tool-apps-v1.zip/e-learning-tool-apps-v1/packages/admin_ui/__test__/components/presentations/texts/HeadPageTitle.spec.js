import { ExpansionPanelActions } from "@mui/material";
import { shallow } from "enzyme";
import HeadPageTitle from "../../../../components/presentations/titles/HeadPageTitle";
import { createSerializer } from "enzyme-to-json";
import toJson from "enzyme-to-json";
expect.addSnapshotSerializer(createSerializer({ mode: "deep" }));
describe("Head Page Title ", () => {
  let wrapper;
  beforeEach(() => {
    wrapper = shallow(<HeadPageTitle title="test header" />);
  });
  it("Head Page Title render", () => {
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  it("To have h2 tag", () => {
    expect(wrapper.find("h2").exists()).toBeTruthy();
  });
  it("check content", () => {
    expect(wrapper.find("h2").text()).toEqual("test header");
  });
});
