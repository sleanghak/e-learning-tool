import { shallow } from "enzyme";
import SearchBox from "../../../../components/presentations/searchBox/SearchBox";
import toJSON from "enzyme-to-json";
import Paper from "@mui/material/Paper";
import InputBase from "@mui/material/InputBase";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
describe("Render Search Box as search field", () => {
  let wrapper;
  beforeAll(() => {
    wrapper = shallow(<SearchBox />);
  });
  it("snapshot render Search Box", () => {
    expect(toJSON(wrapper)).toMatchSnapshot();
  });
  it("Check required component", () => {
    expect(wrapper.find(Paper).exists()).toBeTruthy();
    expect(wrapper.find(InputBase).exists()).toBeTruthy();
    expect(wrapper.find(Divider).exists()).toBeTruthy();
    expect(wrapper.find(IconButton).exists()).toBeTruthy();
    expect(wrapper.find(MenuIcon).exists()).toBeTruthy();
    expect(wrapper.find(SearchIcon).exists()).toBeTruthy();
  });
  it("component is a form", () => {
    expect(wrapper.find(Paper).prop("component")).toEqual("form");
  });
  it("check placeholder content input", () => {
    expect(wrapper.find(InputBase).prop("placeholder")).toEqual(
      "Search Student"
    );
  });
  it("it is vertical Divider", () => {
    expect(wrapper.find(Divider).prop("orientation")).toEqual("vertical");
  });
});
