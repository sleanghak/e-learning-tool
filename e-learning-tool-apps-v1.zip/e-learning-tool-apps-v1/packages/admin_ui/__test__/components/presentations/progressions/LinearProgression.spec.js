import { shallow } from "enzyme";
import LinearProgression from "../../../../components/presentations/progressions/LinearProgression";
import LinearProgressWithLabel from "../../../../components/presentations/progressions/LinearWithLabel";
import toJson from "enzyme-to-json";
describe("rendering LinearProgression", () => {
  it("snapshot linear", () => {
    const wrapper = shallow(<LinearProgression  />);
   
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  it("show linear progression", () => {
    const wrapper = shallow(<LinearProgression show={true}/>);
    expect(wrapper.find(LinearProgressWithLabel).exists()).toBeTruthy();
  });
  it("hide linear progression",()=>{
      const wrapper = shallow(<LinearProgression show={false}/>);
      expect(wrapper.find(LinearProgressWithLabel).exists()).toBeFalsy();
  })
});
