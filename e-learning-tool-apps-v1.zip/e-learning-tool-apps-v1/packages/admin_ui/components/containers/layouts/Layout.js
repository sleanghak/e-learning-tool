import React from "react";
import Navbar from "./Nav";
import Header from "./Header";
import { makeStyles } from "@mui/styles";
import Footer from "./Footer";

const useStyles = makeStyles((theme) => ({
  root: {},
  page: {
    paddingTop: theme.spacing(2),
  },
  toolbar: theme.mixins.toolbar,
}));

const Layout = ({ children, navBarItems, title, user }) => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Header title={title} />
      <Navbar navBarItems={navBarItems} user={user}>
        <div className={classes.page}>{children}</div>
        <Footer />
      </Navbar>
    </div>
  );
};

export default Layout;
