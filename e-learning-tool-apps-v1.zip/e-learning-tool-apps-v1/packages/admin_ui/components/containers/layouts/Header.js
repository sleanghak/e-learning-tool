import React from "react";
import Head from "next/head";

const Header = ({ title }) => {
  return (
    <Head>
      <link
        rel="shortcut icon"
        href="/images/sabaicode.jpg"
        type="image/x-icon"
      />
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin />
      <link
        href="https://fonts.googleapis.com/css2?family=Maven+Pro&display=swap"
        rel="stylesheet"
      />

      <title>{title}</title>
    </Head>
  );
};

export default Header;
