import React from "react";
import clsx from "clsx";
import { makeStyles } from "@mui/styles";
import Badge from "@mui/material/Badge";
import Drawer from "@mui/material/Drawer";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import ExitToAppOutlinedIcon from "@mui/icons-material/ExitToAppOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import ExpandMore from "@mui/icons-material/ExpandMore";
import ExpandLess from "@mui/icons-material/ExpandLess";
import { convertFilePathToURL } from "./../../../utils/func/s3";
import {
  Avatar,
  Collapse,
  Popover,
  Paper,
  Tooltip,
  CircularProgress,
} from "@mui/material";
import { useRouter } from "next/router";
import { logoutUser } from "../../../utils/func/auth/authUser";

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  hide: {
    display: "none",
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,

    whiteSpace: "nowrap",
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: "hidden",
    width: 72,
    [theme.breakpoints.up("sm")]: {
      width: 72,
    },
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
    background: "#06BCC1",
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    marginTop: 50,
  },
  active: {
    background: "rgb(200, 250, 205)",
    color: "rgb(0, 171, 85)",
    // borderRight: '3px solid rgb(0, 171, 85)',
    borderBottomLeftRadius: 10,
    borderTopRightRadius: 10,
    "&:hover": {
      background: "rgba(0, 171, 85, 0.08)",
    },
  },
  active__icon: {
    color: "rgb(0, 171, 85)",
  },
  menu__title: {
    paddingTop: theme.spacing(3),
  },
  sublist: {
    background: "#F4F4F4",
    width: "90%",
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 10,
    marginBottom: 10,
    borderRadius: 10,
  },
  appbar: {
    background: "#FFFFFF",
    zIndex: theme.zIndex.drawer + 1,
    boxShadow: " 0 1px 1px 0 rgba(0,0,0,0.1)",
    height: 60,
  },
  appbar__avatar: {
    background: "#06BCC1",
    marginLeft: theme.spacing(2),
    color: "#fff",
  },
  signin__button: {
    marginLeft: theme.spacing(2),
    minWidth: "max-content",
  },
  bottom__list: {
    position: "relative",
    bottom: 0,
    left: 0,
    // width: "100%",
  },
  logo: {
    cursor: "pointer",
    marginLeft: 50,
  },
  signout: {
    background: "rgb(255, 72, 66)",
    borderBottomLeftRadius: 10,
    borderTopRightRadius: 10,
    color: "#FFFFFF",
    "&:hover": {
      background: "rgba(0, 171, 85, 0.08)",
      color: "rgb(255, 72, 66)",
    },
  },
  app_activity: {
    marginLeft: `auto`,
  },
  popups: {
    maxWidth: 250,
    maxHeight: 350,
    backgroundColor: "#fff",
  },
  profile: {
    backgroundColor: "#5DE7",
    borderRadius: 15,
    marginBottom: 20,
    overflow: "hidden",
    // padding: 1,
    "& *": {
      // color: "#fff",
    },
  },
}));

export default function Navbar({ children, navBarItems, user }) {
  const classes = useStyles();
  const router = useRouter();
  const [open, setOpen] = React.useState(false);
  const [submenu, setSubmenu] = React.useState();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [currentUser, setCurrentUser] = React.useState();

  const openPopup = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const openPopupStatus = Boolean(anchorEl);
  const id = openPopupStatus ? "simple-popover" : undefined;

  const handleClickSublist = (index) => {
    if (index != submenu) {
      setSubmenu(index);
    } else {
      setSubmenu(undefined);
    }
  };

  const handleDrawerOpen = () => {
    setOpen(!open);
  };

  React.useEffect(() => {
    convertFilePathToURL(user.data).then((data) => {
      setCurrentUser(data);
      console.log("Render");
    });
  }, []);
  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar position="fixed" className={clsx(classes.appBar, {})}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            // className={clsx(classes.menuButton, {
            //   [classes.hide]: open,
            // })}
          >
            <MenuIcon />
          </IconButton>
          <Typography sx={{ fontWeight: "bold" }} variant="h5" noWrap>
            SabaiCode
          </Typography>

          <IconButton
            aria-describedby={id}
            onClick={openPopup}
            className={classes.app_activity}
          >
            <Badge badgeContent={100} color="secondary" max={9}>
              <NotificationsNoneOutlinedIcon />
            </Badge>
          </IconButton>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
      >
        <div className={classes.toolbar}>
          {/* <IconButton>
            {theme.direction === "rtl" ? (
              <ChevronRightIcon style={{ color: "#fff" }} />
            ) : (
              <ChevronLeftIcon style={{ color: "#fff" }} />
            )}
          </IconButton> */}
        </div>
        <div>
          <List>
            <ListItem className={classes.profile}>
              <Avatar
                style={{ marginRight: 16 }}
                alt="Remy Sharp"
                src={currentUser?.coverFileName}
              />
              <ListItemText
                primary={<b color="primary">{currentUser?.name}</b>}
                secondary={
                  <Typography className="max-line-text-1">
                    {currentUser?.email}
                  </Typography>
                }
              />
            </ListItem>
            {navBarItems.map((item, index) => {
              return item?.sublist?.length == 0 ? (
                <Tooltip title={item.text} key={index}>
                  <ListItem
                    button
                    className={
                      router.pathname == item.path ||
                      router.pathname.includes(item.path)
                        ? classes.active
                        : null
                    }
                    onClick={() => router.push(item.path)}
                  >
                    <ListItemIcon
                      className={
                        router.pathname == item.path ||
                        item.path.includes(router.pathname)
                          ? classes.active__icon
                          : null
                      }
                    >
                      {item.icon}
                    </ListItemIcon>
                    <ListItemText primary={item.text} />
                  </ListItem>
                </Tooltip>
              ) : (
                <div key={item.text}>
                  <Tooltip title={item.text} key={index}>
                    <ListItem button onClick={() => handleClickSublist(index)}>
                      <ListItemIcon>{item.icon}</ListItemIcon>
                      <ListItemText primary={item.text} />
                      {index === submenu ? <ExpandLess /> : <ExpandMore />}
                    </ListItem>
                  </Tooltip>
                  <Collapse in={index === submenu} timeout="auto" unmountOnExit>
                    <List
                      component="div"
                      disablePadding
                      className={classes.sublist}
                    >
                      {item.sublist.map((subItem) => (
                        <Tooltip title={subItem.text} key={index}>
                          <ListItem
                            button
                            className={
                              router.pathname == subItem.path
                                ? classes.active
                                : null
                            }
                            key={subItem.text}
                            onClick={() => router.push(subItem.path)}
                          >
                            <ListItemIcon
                              className={
                                router.pathname == subItem.path
                                  ? classes.active__icon
                                  : null
                              }
                            >
                              {subItem.icon}
                            </ListItemIcon>
                            <ListItemText primary={subItem.text} />
                          </ListItem>
                        </Tooltip>
                      ))}
                    </List>
                  </Collapse>
                </div>
              );
            })}
            <ListItem className={classes.signout} button onClick={logoutUser}>
              <ListItemIcon>
                <ExitToAppOutlinedIcon style={{ color: "white" }} />
              </ListItemIcon>
              <ListItemText primary="Sign Out" />
            </ListItem>
          </List>
        </div>
      </Drawer>
      <main className={classes.content}>{children}</main>
      <Popover
        id={id}
        open={openPopupStatus}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
      >
        <Paper className={classes.popups}>
          <List>
            <ListItem>
              <ListItemIcon>
                <Avatar />
              </ListItemIcon>
              <ListItemText
                primary="Activity 01"
                secondary="SEIREY chhunheng add 3 hours"
              />
            </ListItem>
            <ListItem>
              <ListItemIcon>
                <Avatar />
              </ListItemIcon>
              <ListItemText
                primary="Activity 01"
                secondary="SEIREY chhunheng add 3 hours"
              />
            </ListItem>{" "}
            <ListItem>
              <ListItemIcon>
                <Avatar />
              </ListItemIcon>
              <ListItemText
                primary="Activity 01"
                secondary="SEIREY chhunheng add 3 hours"
              />
            </ListItem>
          </List>
        </Paper>
      </Popover>
    </div>
  );
}
