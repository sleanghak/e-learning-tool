import Header from './Header'
import NavBar from './Nav'
import Footer from './Footer'
import Layout from './Layout'
export {
    Header,
    NavBar,
    Footer,
    Layout
}