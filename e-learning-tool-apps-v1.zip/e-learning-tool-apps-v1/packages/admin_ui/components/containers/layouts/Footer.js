import React, { useState } from "react";
import { Grid, Typography, Button } from "@mui/material";
import { makeStyles } from "@mui/styles";
import ButtonShare from "./../../presentations/buttons/ButtonShare";
import { GroupSocialMedia } from "../../presentations";
import PhoneIcon from "@mui/icons-material/Phone";
import EmailIcon from "@mui/icons-material/Email";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import TelegramIcon from "@mui/icons-material/Telegram";
const useStyles = makeStyles((theme) => ({
  root: {
    color: "white",
    width: `100%`,
  },
  footer: {
    marginTop: 50,
    backgroundColor: " rgb(0, 171, 85)",
    width: `100%`,
    height: 300,
    padding: 30,
    "& img": {
      width: 100,
      display: "block",
      margin: "0 auto",
    },
  },
  textFooter: {
    color: "white",
  },

  item: {
    marginBottom: 20,
    // textAlign: 'center'
  },
}));

export default function Footer() {
  const classes = useStyles();
  return (
    <Grid container className={classes.root}>
      <Grid className={classes.footer} item xs={12} md={4}>
        <h3 id="footer-title-1" className={classes.h3}>
          Contact Us
        </h3>
        <p className={classes.item} />
        <Typography>
          <TelegramIcon />{" "}
          <sup style={{ marginLeft: 10 }}>(+885) 96 32 34 760</sup>
        </Typography>
        <Typography>
          <PhoneIcon />{" "}
          <sup style={{ marginLeft: 10 }}>(+885) 96 32 34 760</sup>
        </Typography>
        <Typography>
          <EmailIcon />{" "}
          <sup style={{ marginLeft: 10 }}>sabaicode@gmail.com</sup>
        </Typography>
        <Typography>
          <LocationOnIcon />{" "}
          <sup style={{ marginLeft: 10 }}>
            <a
              id="location"
              href="https://www.google.com/maps/place/SabaiCode/@11.5472808,104.9161711,17z/data=!3m1!4b1!4m5!3m4!1s0x310951f3148296db:0x5b289f3f5cef444!8m2!3d11.5472756!4d104.9183598"
            >
              28 saint 368, Phnom Penh, Cambodia
            </a>
          </sup>
        </Typography>
      </Grid>
      <Grid className={classes.footer} item xs={12} md={4}>
        <h3 id="footer-title-2" className={classes.h3}>
          About Us
        </h3>
        <p className={classes.item} />
        <img src="/images/sabaicode.jpg" alt="sabaicode" />
        <Typography style={{ textAlign: "center" }}>
          We aspire to be the highest quality coding and robots school for
          children.
        </Typography>
        <br />
      </Grid>
      <Grid className={classes.footer} item xs={12} md={4}>
        <h3 id="footer-title-3" className={classes.item}>
          Follow Us
        </h3>
        <GroupSocialMedia />
        <p className={classes.item} />
        <ButtonShare />
      </Grid>
    </Grid>
  );
}
