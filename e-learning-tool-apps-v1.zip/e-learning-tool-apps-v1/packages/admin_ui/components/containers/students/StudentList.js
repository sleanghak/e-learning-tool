import React from "react";
import { makeStyles } from "@mui/styles";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { StudentInfo } from "../../presentations";
import Pagination from "@mui/lab/Pagination";
import { Button } from "@mui/material";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "33.33%",
    flexShrink: 0,
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(15),
    color: theme.palette.text.secondary,
  },
}));

export default function StudentList({ students, pages, page, setPage }) {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);
  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
  console.log(students);

  return (
    <div className={classes.root}>
      {students.map((item, index) => {
        return (
          <Accordion
            key={index}
            expanded={expanded === `panel${index}`}
            onChange={handleChange(`panel${index}`)}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1bh-content"
              id="panel1bh-header"
            >
              <Typography className={classes.heading}>{item.name}</Typography>
              <Typography className={classes.secondaryHeading}>
                Contact % {item.email}
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              <StudentInfo student={item} />
            </AccordionDetails>
          </Accordion>
        );
      })}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        <Pagination
          style={{ marginTop: 20 }}
          variant="outlined"
          count={pages}
          page={page}
          onChange={(e, value) => setPage(value)}
          color="primary"
        />
        {/* <Button variant="contained" size="small" startIcon={<ExitToAppIcon />}>
          Excel
        </Button> */}
      </div>
    </div>
  );
}
