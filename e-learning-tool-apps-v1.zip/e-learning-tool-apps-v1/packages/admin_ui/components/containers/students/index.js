import StudentList from "./StudentList";
export {
    StudentList
}