import React from "react";
import { Player } from "video-react";
import { Paper, Grid } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { Typography } from "@mui/material";
import { convertFilePathToURL } from "../../../utils/func/s3";
import { VideoLessonCard } from "../../presentations/cards";
import { TextField } from "@mui/material";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/getDataFunc";
import SabaiCodeLoading from "./../../presentations/loading";
const useStyles = makeStyles((theme) => ({
  root: {},
  center: {
    width: 400,
    margin: "0px auto",
  },
  big: {
    fontSize: 27,
    marginTop: 20,
    marginBottom: 10,
    [theme.breakpoints.down("sm")]: {
      fontSize: 18,
    },
  },
  small: {
    fontSize: 20,
    [theme.breakpoints.down("sm")]: {
      fontSize: 12,
    },
  },
}));
const AllLessons = ({ course, token }) => {
  // console.log(course,token)
  const classes = useStyles();
  const [video, setVideo] = React.useState({});
  const [lessons, setLessons] = React.useState([]);

  const [courseId, setCourseId] = React.useState(course.courseIds[0]?._id);

  const handlePlay = async (item) => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/video?id=${item.videoId}`,
        {
          headers: {
            "x-access-token": token.accessToken,
          },
        }
      );
      const data = await res.json();
      if (data.statusCode == 200) {
        const video = await convertFilePathToURL({
          ...item,
          ...data.data,
          isPlay: true,
        });

        setVideo(video);
      }
    } catch (error) {
      console.error(error);
    }

    window.scrollTo(0, 200);
  };
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course?id=${courseId}`,
    fetcher
  );

  React.useEffect(() => {
    if (data?.data?.lessonIds.length > 0) {
      convertFilePathToURL(data.data.lessonIds).then((res) => {
        setLessons(res);
      });
    }
  }, [data]);

  React.useEffect(async () => {
    // if (lessons.length > 0) {
    //   try {
    //     const res = await fetch(
    //       `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/video?id=${lessons[0].videoId}`,
    //       {
    //         headers: {
    //           "x-access-token": token.accessToken,
    //         },
    //       }
    //     );
    //     const data = await res.json();
    //     if (data.statusCode == 200) {
    //       const video = await convertFilePathToURL({
    //         ...lessons[0],
    //         ...data.data,
    //         isPlay: true,
    //       });
    //       setVideo(video);
    //     }
    //   } catch (error) {
    //     console.log(error);
    //   }
    // }
  }, [lessons]);
  if (error) return `${error}`;
  if (!data) return <SabaiCodeLoading />;
  return (
    <Paper square className={classes.root}>
      {course.courseIds.length === 0 ? (
        <h1>No Course</h1>
      ) : (
        <Grid
          style={{ paddingTop: 35 }}
          container
          justifyContent="space-evenly"
        >
          <Grid item xs={7}>
            <Player
              className="video"
              playInline
              poster={video.coverFileName}
              autoPlay={video.isPlay}
              src={video.fileName}
            />

            <h2 className={classes.big}>{video.name}</h2>
            <Typography className={classes.small}>{video.desc} </Typography>
          </Grid>
          <Grid item xs={3}>
            <TextField
              size="small"
              className={classes.textInput}
              id="outlined-select-currency-native"
              select
              required
              label="Select Subject"
              name="subjectId"
              SelectProps={{
                native: true,
              }}
              variant="outlined"
              onChange={(e) => setCourseId(e.target.value)}
            >
              {course.courseIds.map((item, index) => {
                return (
                  <option key={index} value={item._id}>
                    {item.name}
                  </option>
                );
              })}
            </TextField>
            {lessons.map((item, index) => {
              return (
                <Grid key={index} style={{ padding: 15 }} item xs={12}>
                  <VideoLessonCard
                    url={item.coverFileName}
                    desc={item.desc}
                    name={item.name}
                    onClick={() => handlePlay(item)}
                  />
                </Grid>
              );
            })}
          </Grid>
        </Grid>
      )}
    </Paper>
  );
};

export default AllLessons;
