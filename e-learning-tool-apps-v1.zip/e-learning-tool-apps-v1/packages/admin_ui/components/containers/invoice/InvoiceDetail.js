import React from "react";
import {
  Box,
  Stack,
  IconButton,
  Typography,
  Grid,
  Paper,
  Divider,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import {
  compareCurrentDate,
  toDateFormat,
} from "./../../../utils/func/toDateFormat";
import Add from "@mui/icons-material/Add";
import SabaiCodeForm from "../forms/SabaiCodeForm";
import postDataFunc from "../../../utils/func/api/postDataFunc";
const InvoiceDetail = ({ data, onClose }) => {
  const [panel, setPanel] = React.useState();
  const [loading, setLoading] = React.useState(false);
  const handleAddPayment = async (e) => {
    e.preventDefault();
    setLoading(true);
    const form = e.target.elements;
    console.log(form.amount.value, form.description.value);
    await postDataFunc(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/invoice/addPayment/${data?._id}`,
      {
        amount: form.amount.value,
        description: form.description.value,
      }
    );
    setLoading(false);
  };
  return (
    <Box sx={{ p: 2 }}>
      <Stack
        direction={"row"}
        justifyContent="space-between"
        alignItems={"center"}
      >
        <Typography variant="h5">{data.invoiceId}</Typography>
        <IconButton onClick={onClose}>
          <CloseIcon color="secondary" />
        </IconButton>
      </Stack>
      <Grid container>
        <Grid item xs={12} sm={6}>
          <img src={data.coverFileName} style={{ width: "100%" }} />
        </Grid>
        <Grid item xs={12} sm={6}>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography>SentTo</Typography>
              <Typography>{data.partner}</Typography>
            </Stack>
          </Paper>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography>Email</Typography>
              <Typography>{data.email}</Typography>
            </Stack>
          </Paper>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography>Send Date</Typography>
              <Typography>{toDateFormat(data.createdAt)}</Typography>
            </Stack>
          </Paper>
          <Paper
            sx={{
              p: 1,
              m: 1,
              backgroundColor: compareCurrentDate(data.dueDate)
                ? "pink"
                : "white",
            }}
          >
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography>Due Date</Typography>
              <Typography>{toDateFormat(data.dueDate)}</Typography>
            </Stack>
          </Paper>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography>Class</Typography>
              <Typography>
                {data?.classId?.name} , Code : {data?.classId?.code}
              </Typography>
            </Stack>
          </Paper>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography>Students</Typography>
              <Stack>
                {data?.studentIds?.map((item, index) => {
                  return (
                    <Typography key={index}>
                      {item._id} ||{item.name}
                    </Typography>
                  );
                })}
              </Stack>
            </Stack>
          </Paper>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography>Amount</Typography>
              <Typography>{data.amount}$</Typography>
            </Stack>
          </Paper>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography>Discount</Typography>
              <Typography>{data.discount}$</Typography>
            </Stack>
          </Paper>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography sx={{ mr: 3 }}>Noted</Typography>
              <Typography>{data.description}</Typography>
            </Stack>
          </Paper>
          <Paper sx={{ p: 1, m: 1 }}>
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Typography sx={{ mr: 2 }}>Payments</Typography>
              <Stack>
                {data?.paids?.map((item, index) => {
                  return (
                    <Typography key={index}>
                      Payment {index + 1} ||{item.amount}$ ||{" "}
                      {toDateFormat(item.date)}
                      <Typography>Noted :: {item.description}</Typography>
                      <Divider color="error" />
                    </Typography>
                  );
                })}
              </Stack>
            </Stack>
          </Paper>

          <Accordion
            sx={{ p: 1, m: 1 }}
            expanded={panel === "panel1"}
            onChange={() => setPanel("panel1")}
          >
            <AccordionSummary
              expandIcon={<Add />}
              aria-controls="panel1bh-content"
              id="panel1bh-header"
            >
              <Typography sx={{ width: "33%", flexShrink: 0 }}>
                Add Payment
              </Typography>
              <Typography sx={{ color: "text.secondary" }}>
                You can enter extra payment
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              <SabaiCodeForm
                loading={loading}
                label={label}
                onSubmit={handleAddPayment}
              />
            </AccordionDetails>
          </Accordion>
        </Grid>
      </Grid>
    </Box>
  );
};

export default InvoiceDetail;

const label = [
  {
    label: "Amount",
    name: "amount",
  },
  {
    label: "Note",
    name: "description",
  },
];
