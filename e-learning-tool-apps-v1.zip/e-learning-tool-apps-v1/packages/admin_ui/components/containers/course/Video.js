import React from "react";
import { Player } from "video-react";
import {
  Grid,
  Paper,
  Typography,
  Button,
  Stack,
  Accordion,
  Box,
  AccordionSummary,
  AccordionDetails,
  Dialog,
} from "@mui/material";
import AddBoxOutlined from "@mui/icons-material/AddBoxOutlined";
import { makeStyles } from "@mui/styles";
import { convertFilePathToURL } from "../../../utils/func/s3";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import VideoForm from "../forms/VideoForm";
import CourseSubList from "../../presentations/lists/CourseSubList";
const useStyles = makeStyles((theme) => ({
  root: {
    // maxWidth: 345,
  },
  center: {
    width: 400,
    margin: "0px auto",
  },
  big: {
    fontSize: 27,
    marginTop: 20,
    marginBottom: 10,
    [theme.breakpoints.down("sm")]: {
      fontSize: 18,
    },
  },
  small: {
    fontSize: 20,
    [theme.breakpoints.down("sm")]: {
      fontSize: 12,
    },
  },
}));
const Video = ({ lessons, token, setOpen, courseId, socket }) => {
  const classes = useStyles();
  const [openVideo, setOpenVideo] = React.useState(false);
  const [video, setVideo] = React.useState(null);
  const [data, setData] = React.useState({});
  const handlePlay = async (item) => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/video?id=${item._id}`,
        {
          headers: {
            "x-access-token": token.accessToken,
          },
        }
      );
      const data = await res.json();

      if (data.statusCode == 200) {
        const video = await convertFilePathToURL({
          ...item,
          ...data.data,
          isPlay: true,
        });

        setVideo(video);
      }
    } catch (error) {
      console.error(error);
    }

    window.scrollTo(0, 200);
  };
  const handleClose = () => {
    setOpenVideo(false);
  };
  const handleOpen = (item) => {
    setOpenVideo(true);
    setData(item);
    console.log(item);
  };
  return (
    <Paper square style={{ padding: 16 }}>
      <Grid container justify="space-evenly">
        <Grid item xs={12}>
          {video && (
            <Box>
              <Player
                className="video"
                playInline
                poster={video.coverFileName}
                autoPlay={video.isPlay}
                src={video.fileName}
              />
              <Stack spacing={1} sx={{ pt: 1, mb: 3 }}>
                <h2 className={classes.big}>{video.name}</h2>
                <Typography className={classes.small}>
                  {video.description}{" "}
                </Typography>
              </Stack>
            </Box>
          )}
        </Grid>
      </Grid>
      <Stack
        spacing={2}
        justifyContent="space-between"
        direction={"row"}
        sx={{
          p: 3,
          background: "linear-gradient(to right, #2193b0, #6dd5ed);",
        }}
      >
        <Button
          onClick={() => setOpen(true)}
          variant="contained"
          endIcon={<AddBoxOutlined />}
        >
          Add Lesson
        </Button>
      </Stack>
      <Box sx={{ mt: 2 }}>
        {lessons.map((item, index) => {
          return (
            <Accordion key={index}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography>{item.name}</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Stack direction={"row"} justifyContent="space-between">
                  <Box />
                  <Button variant="outlined" onClick={() => handleOpen(item)}>
                    Upload Video
                  </Button>
                </Stack>

                {item.videoIds.map((video, index) => {
                  return (
                    <CourseSubList
                      playFunc={() => handlePlay(video)}
                      key={index}
                      title={video.name}
                      time={video.duration}
                    />
                  );
                })}
              </AccordionDetails>
            </Accordion>
          );
        })}
      </Box>

      <Dialog open={openVideo}>
        <VideoForm
          socket={socket}
          onClose={handleClose}
          courseId={courseId}
          lesson={data}
        />
      </Dialog>
    </Paper>
  );
};

export default Video;
