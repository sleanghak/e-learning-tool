import { Button, Paper, Stack, Typography, Box } from "@mui/material";
import dynamic from "next/dynamic";
import React from "react";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import { convertFilePathToURL, uploadFile } from "../../../utils/func/s3";
import { LinearProgression } from "../../presentations/progressions";
import Image from "next/image";
const FileView = dynamic(() => import("react-file-viewer"), {
  ssr: false,
});
const Curriculum = ({ courseId, name, curriculum, socket }) => {
  const [data, setData] = React.useState(null);
  const [progress, setProgress] = React.useState(0);
  const [msg, setMsg] = React.useState("");

  const uploadCurriculum = async (e) => {
    try {
      const file = e.target.files[0];
      const uploaded = await uploadFile(
        `curriculum/${courseId}`,
        file,
        setProgress,
        setMsg
      );
      const res = await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course/${courseId}`,
        {
          curriculum: uploaded.key,
        }
      );
      socket.emit("detail-courseId", { id: courseId });
    } catch (error) {
      console.log(error);
    }
  };

  React.useEffect(() => {
    if (curriculum) {
      convertFilePathToURL({ fileName: curriculum }).then((data) => {
        setData(data);
      });
    }
  }, []);
  React.useEffect(() => {
    socket.on("courseId", (data) => {
      console.log(data);
      convertFilePathToURL({ fileName: data.curriculum }).then((data) => {
        console.log(data);
        setData(data);
      });
    });
  }, [socket]);
  return (
    <Paper>
      <Typography variant="h3" align="center" style={{ padding: 8 }}>
        {name} Curriculum
      </Typography>
      <LinearProgression
        show={progress > 0 && progress < 100}
        increase={progress}
      />
      <Stack
        spacing={2}
        justifyContent="space-between"
        direction={"row"}
        sx={{
          p: 3,
          m: 3,
          background: "linear-gradient(to right, #2193b0, #6dd5ed);",
        }}
      >
        <label
          htmlFor="curriculum"
          align="center"
          style={{
            borderRadius: 4,
            padding: 8,
            background: "#5DE2E7",
            color: "#eee",
            boxShadow: "0px 0px 4px rgba(0, 0, 0, 0.25)",
          }}
        >
          {curriculum ? "UPDATE CURRICULUM" : "UPLOAD CURRICULUM"}
        </label>

        <input
          hidden
          id="curriculum"
          name="curriculum"
          onChange={uploadCurriculum}
          type={"file"}
          accept=".pdf"
          required
        />

        <Button target={"_blank"} variant="contained" href={data?.fileName}>
          Download
        </Button>
      </Stack>
      {data ? (
        <div style={{ width: "100%" }}>
          <FileView fileType="pdf" filePath={data.fileName} />
        </div>
      ) : (
        <Box
          sx={{
            width: 400,
            p: 4,
            mt: 2,
            mb: 2,
            mr: "auto",
            ml: "auto",
            backgroundColor: "lightblue",
            borderRadius: 2,
          }}
        >
          <Image
            width={400}
            height={400}
            alt="No Curriculum"
            src="/images/undraw_not_found_dyeh.svg"
          />
        </Box>
      )}
    </Paper>
  );
};

export default Curriculum;
