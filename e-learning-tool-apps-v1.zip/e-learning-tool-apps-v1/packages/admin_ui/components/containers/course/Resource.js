import React from "react";
import { Paper, Button, Stack, Box } from "@mui/material";
import AddBoxOutlined from "@mui/icons-material/AddBoxOutlined";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { convertFilePathToURL } from "../../../utils/func/s3";
import dynamic from "next/dynamic";
const FileView = dynamic(() => import("react-file-viewer"), {
  ssr: false,
});
const Resource = ({ setOpen, resources, socket }) => {
  const [data, setData] = React.useState([]);
  const onError = (e) => {
    console.log(e, "error in file-viewer");
  };

  React.useEffect(() => {
    convertFilePathToURL(resources).then((data) => {
      // console.log(data);
      setData(data);
    });
  }, []);
  React.useEffect(() => {
    if (socket) {
      socket.on("courseId", (data) => {
        convertFilePathToURL(data.resources).then((data) => {
          // console.log(data);
          setData(data);
        });
      });
    }
  }, [socket]);
  return (
    <Paper square>
      <Typography sx={{ p: 2 }} variant="h3" align="center">
        Course Materials Book & Slide{" "}
      </Typography>
      <Stack
        spacing={2}
        justifyContent="space-between"
        direction={"row"}
        sx={{
          p: 3,
          m: 3,
          background: "linear-gradient(to right, #2193b0, #6dd5ed);",
        }}
      >
        <Button
          onClick={() => setOpen(true)}
          variant="contained"
          endIcon={<AddBoxOutlined />}
        >
          Materials
        </Button>
      </Stack>
      <Box sx={{ mt: 2, p: 3 }}>
        {data.map((item, index) => {
          return (
            <Accordion key={index}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography>{item.name}</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <div style={{ width: "80%", margin: "0px auto" }}>
                  <FileView
                    fileType="pdf"
                    filePath={item.fileName}
                    onError={onError}
                  />
                </div>
              </AccordionDetails>
            </Accordion>
          );
        })}
      </Box>
    </Paper>
  );
};

export default Resource;
