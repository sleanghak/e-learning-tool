import React, { useState } from "react";
import { makeStyles } from "@mui/styles";
import EditIcon from "@mui/icons-material/Edit";
import { TextField, Grid, Button } from "@mui/material";
import Image from "next/image";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import uploadFile from "../../../utils/func/s3/uploadFile";
import { convertFilePathToURL } from "../../../utils/func/s3";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: 8,
    maxWidth: 400,
    margin: "0px auto",
  },
  title: {
    textAlign: "center",
    marginTop: 8,
  },
  profileContainer: {
    width: 100,
    margin: "0px auto",
    marginTop: 16,
    marginBottom: 8,
    position: "relative",
  },
  profile: {
    borderRadius: 50,
  },

  profileEdit: {
    position: `absolute`,
    left: 65,
    top: 65,
    width: 0,
    height: 30,
    borderRadius: 15,
    padding: 3,
  },
}));
const PersonalInfo = ({ user }) => {
  const classes = useStyles();
  const [file, setFile] = React.useState(null);
  const [name, setName] = React.useState(user.name);
  const [progress, setProgress] = React.useState(0);
  const [loading, setLoading] = React.useState(false);
  const [currentUser, setCurrentUser] = React.useState(null);
  const [msg, setMsg] = React.useState("");
  const handleUpdateUser = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (file) {
        const res = await uploadFile(
          `users/${user._id}`,
          file,
          setProgress,
          setMsg
        );
        console.log(res);
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/update_current_user`,
          {
            name,
            coverFileName: res.key,
          }
        );
      } else {
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/update_current_user`,
          {
            name: name,
          }
        );
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.log(error);
    }
  };

  React.useEffect(() => {
    convertFilePathToURL(user).then((data) => {
      console.log("user: ", data);
      setCurrentUser(data);
    });
  }, []);
  return (
    <div className={classes.root}>
      <h3 className={classes.title}>Personal Info</h3>
      <form onSubmit={handleUpdateUser}>
        <div className={classes.profileContainer}>
          {currentUser?.coverFileName && (
            <>
              <img
                className={classes.profile}
                src={
                  file
                    ? window.URL.createObjectURL(file)
                    : user.coverFileName
                    ? user.coverFileName
                    : "./images/sabaicode.jpg"
                }
                alt="profile"
                width={100}
                height={100}
              />
              <label htmlFor="profile" className={classes.profileEdit} disabled>
                <EditIcon color="secondary" />
              </label>
            </>
          )}
          <input
            accept=".jpg, .png, .jpeg"
            onChange={(e) => setFile(e.target.files[0])}
            type="file"
            id="profile"
            label="profile"
            hidden
          />
        </div>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <TextField
              type="text"
              variant="outlined"
              fullWidth
              label="Full Name"
              value={name}
              name="name"
              onChange={(e) => setName(e.target.value)}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              type="email"
              value={user.email}
              variant="outlined"
              fullWidth
              label="Email Address"
              name="email"
            />
          </Grid>
          <Grid item xs={12}>
            <Button
              disabled={loading}
              type="submit"
              color="primary"
              className={classes.input}
              fullWidth
              variant="contained"
            >
              Save Change
            </Button>
          </Grid>
        </Grid>
      </form>
    </div>
  );
};

export default PersonalInfo;
