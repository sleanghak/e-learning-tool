import PersonalInfo from "./PersonalInfo";
import SettingMenu from "./SettingMenu";
import ChangePassword from "./ChangePassword";
export {
    PersonalInfo,
    SettingMenu,
    ChangePassword
}