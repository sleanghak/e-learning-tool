import React from "react";
import { Button, TextField, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 400,
    margin: "0px auto",
  },
  input: {
    margin: 8,
  },
}));
const ChangePassword = () => {
  const classes = useStyles();
  const [error, setError] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const handleChangePassword = async (e) => {
    e.preventDefault();
    setLoading(true);
    const form = e.target.elements;
    console.log(
      form.password.value,
      form.newPassword.value,
      form.verifyPassword.value
    );
    if (form.newPassword.value !== form.verifyPassword.value) {
      setError("Verify is not match.");
      setLoading(false);
      return 0;
    }
    try {
      await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/change_password`,
        {
          password: form.password.value,
          newPassword: form.newPassword.value,
          verifyPassword: form.verifyPassword.value,
        }
      );
      setLoading(false);
    } catch (error) {
      setError(error);
      setLoading(false);
    }
  };
  return (
    <div className={classes.root}>
      <form onSubmit={handleChangePassword}>
        <TextField
          className={classes.input}
          label="Enter Your Password"
          name="password"
          fullWidth
          variant="outlined"
        />
        <TextField
          className={classes.input}
          label="Enter New Password"
          name="newPassword"
          fullWidth
          variant="outlined"
        />
        <TextField
          className={classes.input}
          label="Retype New Password"
          name="verifyPassword"
          fullWidth
          variant="outlined"
        />
        {error != "" && <Typography color="error">{error}</Typography>}
        <Button
          disabled={loading}
          type="submit"
          color="primary"
          className={classes.input}
          fullWidth
          variant="contained"
        >
          Change Password
        </Button>
      </form>
    </div>
  );
};

export default ChangePassword;
