import React, { useState } from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import useSWR from "swr";
import { makeStyles } from "@mui/styles";
import IconButton from "@mui/material/IconButton";
import DesktopDatePicker from "@mui/lab/DesktopDatePicker";
import { useRouter } from "next/router";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import InputAdornment from "@mui/material/InputAdornment";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import fetcher from "../../../utils/func/api/getDataFunc";
import { Box, Grid, Input, Stack, Typography } from "@mui/material";
import { registerCoach } from "../../../utils/func/auth/authUser";
import { uploadFile } from "../../../utils/func/s3";
import { LinearProgression } from "./../../presentations/progressions";
import SabaiCodeLoading from "./../../presentations/loading";
const useStyles = makeStyles((theme) => ({
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: 150,
      cursor: "pointer",
    },
  },
}));

export default function CoachForm({ onClose, updateData, socket }) {
  const classes = useStyles();
  const [value, setValue] = React.useState(new Date("2000-01-01:11:54"));
  const [update, setUpdate] = React.useState(updateData);

  const handleChange = (newValue) => {
    setValue(newValue);
  };
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [file, setFile] = React.useState(null);
  const [progress, setProgress] = React.useState(0);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/department?disable=false`,
    fetcher
  );

  async function handleCreateCoach(e) {
    e.preventDefault();
    setErrorMessage("");
    setIsLoading(true);
    const form = e.target.elements;

    try {
      const profile = await uploadFile(
        "coach_profile/",
        form.profile.files[0],
        setProgress,
        setErrorMessage
      );

      await registerCoach(
        {
          coverFileName: profile.key,
          username: form.username.value,
          email: form.email.value,
          password: form.password.value,
          major: form.major.value,
          default_salary: form.default_salary.value,
          price_per_hour: form.price_per_hour.value,
          role: "coach",
          bank: form.bank.value,
          tels: [form.tel.value],
          dateOfBirth: form.dateOfBirth.value,
        },
        setErrorMessage,
        setIsLoading,
        onClose
      );
      socket.emit("meta-user", { role: "coach" });
    } catch (error) {
      setErrorMessage(error.message);
      setIsLoading(false);
    }
  }
  if (!data) return <SabaiCodeLoading />;
  if (error) return error;

  return (
    <Box sx={{ minWidth: 450, p: 3 }}>
      <div>
        <LinearProgression
          show={progress > 0 && progress < 100}
          increase={progress}
        />
        <form onSubmit={handleCreateCoach}>
          <Box
            className={
              file || update?.coverFileName ? classes.uploadImg : classes.upload
            }
          >
            <label htmlFor="profile">
              <img
                id="icon"
                alt="uploadIcon"
                src={
                  update?.coverFileName && !file
                    ? update?.coverFileName
                    : file
                    ? window.URL.createObjectURL(file)
                    : "icons/uploadImage.png"
                }
              />
              <Typography textAlign={"center"}>Upload a profile</Typography>
            </label>
            <input
              onChange={(e) => setFile(e.target.files[0])}
              type="file"
              hidden
              id="profile"
              label="image URL"
              variant="outlined"
              name="profile"
              accept="image/*"
              required={!update}
            />
          </Box>
          <Grid container spacing={3}>
            <Grid item xs={6}>
              <TextField
                variant="standard"
                required
                fullWidth
                label="User Name"
                name="username"
                onChange={(e) =>
                  setUpdate((prev) => ({
                    ...prev,
                    username: e.target.value,
                  }))
                }
                value={update?.username}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                variant="standard"
                type={"email"}
                required
                fullWidth
                label="Email Address"
                name="email"
                autoComplete="email"
                autoFocus
                onChange={(e) =>
                  setUpdate((prev) => ({
                    ...prev,
                    email: e.target.value,
                  }))
                }
                value={update?.email}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                size="small"
                className={classes.textInput}
                id="outlined-select-currency-native"
                select
                required
                label="Major"
                name="major"
                onChange={(e) =>
                  setUpdate((prev) => ({
                    ...prev,
                    major: e.target.value,
                  }))
                }
                value={update?.subjectId}
                SelectProps={{
                  native: true,
                }}
                variant="standard"
              >
                <option></option>

                {data.data?.map((item, index) => {
                  return (
                    <option key={index} value={item._id}>
                      {item.name}
                    </option>
                  );
                })}
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField
                variant="standard"
                required
                fullWidth
                label="ABA Bank"
                name="bank"
                autoFocus
                onChange={(e) =>
                  setUpdate((prev) => ({
                    ...prev,
                    bank: e.target.value,
                  }))
                }
                value={update?.bank}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                variant="standard"
                required
                fullWidth
                label="Phone Number"
                name="tel"
                type={"tel"}
                autoFocus
                onChange={(e) =>
                  setUpdate((prev) => ({
                    ...prev,
                    tels: e.target.value,
                  }))
                }
                //   value={update?.tels[0]}
              />
            </Grid>
            <Grid item xs={6}>
              <DesktopDatePicker
                label="Date of birth"
                inputFormat="MM/dd/yyyy"
                value={value}
                onChange={handleChange}
                color="primary"
                renderInput={(params) => (
                  <TextField
                    fullWidth
                    variant="standard"
                    required
                    name="dateOfBirth"
                    {...params}
                  />
                )}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                variant="standard"
                required
                fullWidth
                label="Base Salary"
                name="default_salary"
                type={"number"}
                autoFocus
                onChange={(e) =>
                  setUpdate((prev) => ({
                    ...prev,
                    default_salary: e.target.value,
                  }))
                }
                value={update?.default_salary}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                variant="standard"
                required
                fullWidth
                label="Price Per Hour"
                name="price_per_hour"
                type={"number"}
                autoFocus
                onChange={(e) =>
                  setUpdate((prev) => ({
                    ...prev,
                    price_per_hour: e.target.value,
                  }))
                }
                value={update?.price_per_hour}
              />
            </Grid>
            <Grid item xs={6}>
              <FormControl required variant="outlined" fullWidth>
                <InputLabel htmlFor="standard-adornment-password">
                  Password
                </InputLabel>
                <Input
                  id="outlined-adornment-password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  fullWidth
                  name="password"
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={() => setShowPassword(!showPassword)}
                        edge="end"
                      >
                        {showPassword ? (
                          <Visibility color="primary" />
                        ) : (
                          <VisibilityOff color="primary" />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                  labelWidth={70}
                />
              </FormControl>
            </Grid>
          </Grid>

          <Typography color={"secondary"}>{errorMessage}</Typography>
          <Stack direction={"row"} justifyContent={"end"}>
            <Button
              type="submit"
              onClick={onClose}
              color="primary"
              disabled={isLoading}
            >
              <Typography style={{ color: "#000" }}>Cancel</Typography>
            </Button>
            <Button
              type="submit"
              // fullWidth
              //   variant="contained"
              color="primary"
              disabled={isLoading}
            >
              {isLoading ? "Submit ..." : "Submit"}
            </Button>
          </Stack>
        </form>
      </div>
    </Box>
  );
}
