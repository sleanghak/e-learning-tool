import { TextField, Box, Button, Stack } from "@mui/material";

const SabaiCodeForm = ({ label, loading, onSubmit }) => {
  return (
    <Box>
      <form onSubmit={onSubmit}>
        <Stack spacing={2}>
          {label?.map((item, index) => {
            return (
              <TextField label={item.label} key={index} name={item.name} />
            );
          })}
          <Box>
            <Button type="reset">Cancle</Button>
            <Button disabled={loading} type="submit">
              Submit
            </Button>
          </Box>
        </Stack>
      </form>
    </Box>
  );
};

export default SabaiCodeForm;
