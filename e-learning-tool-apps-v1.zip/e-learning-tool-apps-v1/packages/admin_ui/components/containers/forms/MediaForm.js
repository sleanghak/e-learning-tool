import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Card,
  Box,
  TextField,
  Typography,
  // MenuItem,
  Button,
} from "@mui/material";
import { MenuItem } from "@mui/material";
import { makeStyles } from "@mui/styles";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/getDataFunc";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import uploadFile from "../../../utils/func/s3/uploadFile";
import { LinearProgression } from "../../presentations/progressions";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import DatePicker from "@mui/lab/DatePicker";
import filterObjectAtt from "../../../utils/func/filterObjectAtt";
import { types, subTypes } from "../../../utils/constants/media";
const useStyles = makeStyles((theme) => ({
  root: {
    boxShadow: "none",
    minWidth: 450,
    padding: "30px 40px",
  },
  title: {
    width: "100%",
    marginBottom: 30,
  },
  input: {
    marginBottom: 20,
    marginTop: 20,
  },
  button: {
    diplay: "flex",
    alignItems: "center",
    textAlign: "right",
    marginTop: 40,
  },
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: 250,
      cursor: "pointer",
    },
  },
  video: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 20,
    marginTop: 20,
    "& input": {
      width: "50%",
    },
  },
}));

const MediaForm = ({ onClose, updateData, socket, query }) => {
  const classes = useStyles();
  const [file, setFile] = React.useState(null);
  const [progress, setProgress] = React.useState(0);
  const [update, setUpdate] = React.useState(updateData || {});
  const [errorMsg, setErrorMsg] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const handlePost = async (e) => {
    e.preventDefault();
    const form = e.target.elements;
    const coverFileName = form.coverFileName.files[0];
    const fileName = form.fileName?.files[0];
    console.log(
      filterObjectAtt({
        name: form.name.value,
        coverFileName: coverFileName,
        type: form.type.value,
        subType: form.subType?.value,
        description: form.description.value,
        date: form.date.value,
        link: form.link?.value,
        fileName: fileName,
      })
    );
    let fileNamePath = null;
    setLoading(true);
    if (fileName) {
      const res = await uploadFile(
        "media/videos",
        fileName,
        setProgress,
        setErrorMsg
      );
      fileNamePath = res.key;
    }
    if (Boolean(updateData && file)) {
      if (!coverFileName) {
        setErrorMsg("Please select a file.");
        return;
      }
      try {
        const coverFileNamePath = await uploadFile(
          "post/image",
          coverFileName,
          setProgress,
          setErrorMsg
        );
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/media/${update._id}`,
          filterObjectAtt({
            name: form.name.value,
            coverFileName: coverFileNamePath.key,
            type: form.type.value,
            subType: form.subType?.value,
            description: form.description.value,
            date: form.date.value,
            link: form.link?.value,
            fileName: fileNamePath,
          })
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
      // update only text
    } else if (updateData) {
      try {
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/media/${update._id}`,
          filterObjectAtt({
            name: form.name.value,
            type: form.type.value,
            subType: form.subType?.value,
            description: form.description.value,
            date: form.date.value,
            link: form.link?.value,
          })
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
      // create a new post
    } else {
      if (!coverFileName) {
        setErrorMsg("Please select a file.");
        return;
      }

      try {
        const coverFileNamePath = await uploadFile(
          "media/images",
          coverFileName,
          setProgress,
          setErrorMsg
        );
        await postDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/media`,
          filterObjectAtt({
            name: form.name.value,
            coverFileName: coverFileNamePath.key,
            type: form.type.value,
            subType: form.subType?.value,
            description: form.description.value,
            date: form.date.value,
            link: form.link?.value,
            fileName: fileNamePath,
          })
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
    }
    setLoading(false);
    socket.emit("meta-media", query);
  };
  return (
    <Card className={classes.root}>
      <Box className={classes.title}>
        <Typography variant="h6">
          {updateData ? "Update Media" : "New Media"}
        </Typography>
      </Box>
      <Box>
        <form onSubmit={handlePost}>
          <div
            className={
              file || update?.coverFileName ? classes.uploadImg : classes.upload
            }
          >
            <label htmlFor="coverFileName">
              <img
                id="icon"
                alt="uploadIcon"
                src={
                  update?.coverFileName && !file
                    ? update?.coverFileName
                    : file
                    ? window.URL.createObjectURL(file)
                    : "icons/uploadImage.png"
                }
              />
              <Typography textAlign={"center"}>
                Tab above image to upload a file
              </Typography>
            </label>
            <input
              onChange={(e) => setFile(e.target.files[0])}
              type="file"
              hidden
              id="coverFileName"
              label="image URL"
              variant="outlined"
              name="coverFileName"
              required={!update}
              accept=".png,.jpg,.jpeg"
            />
          </div>

          <TextField
            className={classes.input}
            fullWidth
            required
            variant="standard"
            size="large"
            label="Name"
            name="name"
            onChange={(e) =>
              setUpdate((prev) => ({ ...prev, name: e.target.value }))
            }
            value={update?.name}
          />
          <TextField
            className={classes.input}
            fullWidth
            variant="standard"
            size="large"
            select
            required
            label="type"
            name="type"
            value={update?.type}
            onChange={(e) => {
              setUpdate((prev) => ({ ...prev, type: e.target.value }));
            }}
          >
            {types.map((item, index) => {
              return (
                <MenuItem key={index} value={item}>
                  {item}
                </MenuItem>
              );
            })}
          </TextField>
          {update.type == "press" ? (
            <TextField
              className={classes.input}
              fullWidth
              variant="standard"
              name="link"
              value={update?.link}
              onChange={(e) => {
                setUpdate((prev) => ({ ...prev, link: e.target.value }));
              }}
              label="link"
            />
          ) : (
            <>
              <TextField
                className={classes.input}
                fullWidth
                variant="standard"
                size="large"
                select
                required
                label="sub-type"
                name="subType"
                value={update?.subType}
                onChange={(e) => {
                  setUpdate((prev) => ({ ...prev, subType: e.target.value }));
                }}
              >
                {subTypes.map((item, index) => {
                  return (
                    <MenuItem key={index} value={item}>
                      {item}
                    </MenuItem>
                  );
                })}
              </TextField>
            </>
          )}
          {update.type == "video" && (
            <div className={classes.video}>
              <label>Upload Video</label>
              <input type={"file"} name="fileName" accept=".mp4" />
            </div>
          )}

          <Box className={classes.input}>
            <DatePicker
              renderInput={(props) => (
                <TextField
                  fullWidth
                  name="date"
                  {...props}
                  variant="standard"
                />
              )}
              value={update?.date}
              onChange={(newValue) => {
                console.log(newValue);
                setUpdate((prev) => ({
                  ...prev,
                  date: newValue,
                }));
              }}
            />
          </Box>
          <TextField
            className={classes.input}
            fullWidth
            variant="standard"
            size="large"
            type="text"
            multiline
            rows={4}
            label="Description"
            name="description"
            onChange={(e) =>
              setUpdate((prev) => ({ ...prev, description: e.target.value }))
            }
            value={update?.description}
          />

          <Typography color="secondary">{errorMsg}</Typography>
          <Box className={classes.button}>
            <Box>
              <Button
                variant="text"
                onClick={onClose}
                sx={{ fontFamily: "Arial" }}
              >
                Cancel
              </Button>
              <Button
                disabled={loading}
                type="submit"
                variant="text"
                sx={{ fontFamily: "Arial" }}
              >
                {updateData ? "Update" : "Submit"}
              </Button>
            </Box>
          </Box>
          <LinearProgression
            show={progress > 0 && progress <= 100}
            increase={progress}
          />
        </form>
      </Box>
    </Card>
  );
};

export default MediaForm;

MediaForm.propTypes = {};

MediaForm.defaultProps = {};
