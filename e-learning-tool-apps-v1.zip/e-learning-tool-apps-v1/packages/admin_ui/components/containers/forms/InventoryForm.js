import React from "react";
import { makeStyles } from "@mui/styles";
import { Grid, TextField, IconButton, Button, Typography } from "@mui/material";
import ClearIcon from "@mui/icons-material/Clear";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import { uploadFile } from "../../../utils/func/s3";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 350,
  },
  title: {
    paddingTop: 10,
    textAlign: `left`,
    textTransform: `uppercase`,
  },

  textInput: {
    width: `100%`,
  },
  btnSubmit: {
    width: `100%`,

    marginBottom: 10,
  },
  loading: {
    display: "block",
    position: "fixed",
    top: `30vh`,
    margin: `0 auto`,
  },
  clearIcon: {
    position: "absolute",
    top: 0,
    right: 5,
  },
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: 200,
      cursor: "pointer",
    },
  },
}));
const InventoryForm = ({ onClose, updateData }) => {
  const classes = useStyles();
  const [file, setFile] = React.useState();
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [update, setUpdate] = React.useState(updateData);
  const [progress, setProgress] = React.useState(0);
  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    const form = e.target.elements;
    // Update data text and image
    if (Boolean(updateData && file)) {
      uploadFile(
        "coverIventory/",
        form.coverFileName.files[0],
        setProgress
      ).then((res) => {
        updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/inventory/${update._id}`,
          {
            name: form.name.value,
            coverFileName: res.key,
            serialCode: form.serialCode.value,
          }
        ).then((data) => {
          console.log(data);
          setLoading(false);
          onClose();
        });
      });
      // update only text
    } else if (updateData) {
      updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/inventory/${update._id}`,
        {
          name: form.name.value,
          serialCode: form.serialCode.value,
        }
      ).then((data) => {
        console.log(data);
        setLoading(false);
        onClose();
      });
      // create new
    } else {
      uploadFile(
        "coverIventory/",
        form.coverFileName.files[0],
        setProgress
      ).then((res) => {
        postDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/inventory`,
          {
            name: form.name.value,
            coverFileName: res.key,
            serialCode: form.serialCode.value,
          }
        ).then((data) => {
          console.log(data);
          setLoading(false);
          onClose();
        });
      });
    }
  };
  return (
    <div className={classes.root}>
      <Grid container justifyContent="center">
        <div className={classes.loading}>{loading && <div>Loading</div>}</div>
        <Grid item xs={11}>
          <IconButton
            onClick={onClose}
            color="secondary"
            className={classes.clearIcon}
          >
            <ClearIcon />
          </IconButton>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <div
                  className={
                    file || update?.coverFileName
                      ? classes.uploadImg
                      : classes.upload
                  }
                >
                  <label htmlFor="coverFileName">
                    <img
                      id="icon"
                      alt="uploadIcon"
                      src={
                        update?.coverFileName && !file
                          ? update?.coverFileName
                          : file
                          ? window.URL.createObjectURL(file)
                          : "icons/uploadImage.png"
                      }
                    />
                  </label>
                  <input
                    onChange={(e) => setFile(e.target.files[0])}
                    type="file"
                    hidden
                    id="coverFileName"
                    label="image URL"
                    variant="outlined"
                    name="coverFileName"
                    required={!update}
                  />
                </div>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  variant="outlined"
                  name="name"
                  label="Inventory's name"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      name: e.target.value,
                    }))
                  }
                  value={update?.name}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  variant="outlined"
                  name="serialCode"
                  label="SerialCode"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      serialCode: e.target.value,
                    }))
                  }
                  value={update?.serialCode}
                />
              </Grid>

              <Grid item xs={6}>
                <Button
                  size="small"
                  type="cancel"
                  fullWidth
                  variant="contained"
                  color="error"
                  onClick={onClose}
                >
                  Cancel
                </Button>
              </Grid>

              <Grid item xs={6}>
                <Button
                  size="small"
                  fullWidth
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={loading}
                >
                  {loading ? "Loading..." : "Submit"}
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Typography color="secondary">{error}</Typography>
              </Grid>
            </Grid>
            <div />
          </form>
        </Grid>
      </Grid>
    </div>
  );
};

export default InventoryForm;
