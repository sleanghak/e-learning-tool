import React, { useEffect } from "react";
import { Grid, TextField, Button, Typography, IconButton } from "@mui/material";
import { makeStyles } from "@mui/styles";
import ClearIcon from "@mui/icons-material/Clear";
import postData from "../../../utils/func/api/postDataFunc";
import { uploadFile } from "../../../utils/func/s3";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import PropTypes from "prop-types";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/getDataFunc";

import LinearProgression from "./../../presentations/progressions/LinearProgression";
import SabaiCodeLoading from "../../presentations/loading";
const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 400,
  },
  title: {
    paddingTop: 10,
    textAlign: `left`,
    textTransform: `uppercase`,
  },

  textInput: {
    width: `100%`,
  },
  btnSubmit: {
    width: `100%`,
    marginBottom: 10,
  },
  loading: {
    display: "block",
    position: "fixed",
    top: `30vh`,
    margin: `0 auto`,
  },
  clearIcon: {
    position: "absolute",
    top: 0,
    right: 5,
  },
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: 200,
      cursor: "pointer",
    },
  },
}));

const CourseForm = ({ onClose, updateData, socket, query }) => {
  const classes = useStyles();
  const [loading, setLoading] = React.useState(false);
  const [errorMessage, setError] = React.useState("");
  const [file, setFile] = React.useState(null);
  const [update, setUpdate] = React.useState(updateData);

  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/department?disable=false`,
    fetcher
  );
  const [progress, setProgress] = React.useState(0);
  const handleClose = () => {
    onClose();
    setUpdate(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const name = e.target.elements.name.value;
    const desc = e.target.elements.desc.value;
    const price = e.target.elements.price.value;
    const coverFileName = e.target.elements.coverFileName.files[0];
    const subjectId = e.target.elements.subjectId.value;
    const fileName = e.target.elements.intro_video.files[0];
    setLoading(true);
    // Update with cover & intro video
    if (fileName && Boolean(updateData && file)) {
      const res = await uploadFile(
        "coverCourses/",
        coverFileName,
        setProgress,
        setError
      );
      const video = await uploadFile(
        "courses/video_intro/",
        fileName,
        setProgress,
        setError
      );
      await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course/${update._id}`,
        {
          name,
          desc,
          price,
          coverFileName: res.key,
          subjectId,
          fileName: video.key,
        }
      );
      handleClose();
    } else if (updateData && fileName) {
      // Update with video intro
      const res = await uploadFile(
        "courses/video_intro/",
        fileName,
        setProgress,
        setError
      );
      await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course/${update._id}`,
        {
          name,
          desc,
          price,
          fileName: res.key,
          subjectId,
        }
      );
      handleClose();
    } else if (Boolean(updateData && file)) {
      const res = await uploadFile(
        "coverCourses/",
        coverFileName,
        setProgress,
        setError
      );
      await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course/${update._id}`,
        {
          name,
          desc,
          price,
          coverFileName: res.key,
          subjectId,
        }
      );
      handleClose();
    }
    // update only text
    else if (updateData) {
      await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course/${update._id}`,
        {
          name,
          desc,
          price,
          subjectId,
        }
      );
      handleClose();
      // create a new course
    } else {
      if (!coverFileName || !fileName) {
        setError("Please select a file.");
        setLoading(false);
        return;
      }

      try {
        const res = await uploadFile(
          "coverCourses/",
          coverFileName,
          setProgress,
          setError
        );
        const video = await uploadFile(
          "courses/video_intro/",
          fileName,
          setProgress,
          setError
        );
        const data = await postData(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course`,
          {
            name,
            desc,
            price,
            coverFileName: res.key,
            fileName: video.key,
            subjectId,
          }
        );
        setLoading(false);
        console.log("posted data" + res);
        onClose();
      } catch (error) {
        setLoading(false);
        console.error(error);
        setError(error.message);
      }
    }
    setLoading(false);
    socket.emit("meta-course", query);
  };

  if (!data) return <SabaiCodeLoading />;
  if (error) return error;
  return (
    <div className={classes.root}>
      <Grid container justifyContent="center">
        <LinearProgression
          show={progress > 0 && progress < 100}
          increase={progress}
        />
        <Grid item xs={11} justifyContent="center">
          <IconButton
            onClick={onClose}
            color="secondary"
            className={classes.clearIcon}
          >
            <ClearIcon />
          </IconButton>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <div
                  className={
                    file || update?.coverFileName
                      ? classes.uploadImg
                      : classes.upload
                  }
                >
                  <label htmlFor="coverFileName">
                    <img
                      id="icon"
                      alt="uploadIcon"
                      src={
                        update?.coverFileName && !file
                          ? update?.coverFileName
                          : file
                          ? window.URL.createObjectURL(file)
                          : "icons/uploadImage.png"
                      }
                    />
                    <Typography textAlign={"center"}>Upload a cover</Typography>
                  </label>
                  <input
                    onChange={(e) => setFile(e.target.files[0])}
                    type="file"
                    hidden
                    id="coverFileName"
                    label="image URL"
                    variant="outlined"
                    name="coverFileName"
                    accept="image/*"
                    required={!update}
                  />
                </div>
              </Grid>
              <Grid item xs={12}>
                {/* TODO :  */}
                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <label>Add Video Intro</label>
                  <input
                    style={{ width: "50%" }}
                    type={"file"}
                    name={"intro_video"}
                    accept="video/*"
                  />
                </div>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  size="small"
                  className={classes.textInput}
                  id="outlined-select-currency-native"
                  required
                  label="Enter Course Name"
                  variant="outlined"
                  name="name"
                  onChange={(e) =>
                    setUpdate((prev) => ({ ...prev, name: e.target.value }))
                  }
                  value={update?.name}
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  size="small"
                  className={classes.textInput}
                  id="price"
                  label="Price"
                  variant="outlined"
                  name="price"
                  required
                  onChange={(e) =>
                    setUpdate((prev) => ({ ...prev, price: e.target.value }))
                  }
                  value={update?.price}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  size="small"
                  className={classes.textInput}
                  id="outlined-select-currency-native"
                  select
                  required
                  label="Select Subject"
                  name="subjectId"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      subjectId: e.target.value,
                    }))
                  }
                  value={update?.subjectId}
                  SelectProps={{
                    native: true,
                  }}
                  variant="outlined"
                >
                  <option></option>

                  {data.data?.map((item, index) => {
                    return (
                      <option key={index} value={item._id}>
                        {item.name}
                      </option>
                    );
                  })}
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  multiline
                  rows={3}
                  maxRows={3}
                  size="small"
                  fullWidth
                  id="outlined-select-currency-native"
                  required
                  label="Course Description"
                  variant="outlined"
                  name="desc"
                  onChange={(e) =>
                    setUpdate((prev) => ({ ...prev, desc: e.target.value }))
                  }
                  value={update?.desc}
                />
              </Grid>

              <Grid item xs={6}>
                <Button
                  size="small"
                  type="cancel"
                  fullWidth
                  variant="contained"
                  color="error"
                  onClick={handleClose}
                >
                  Cancel
                </Button>
              </Grid>

              <Grid item xs={6}>
                <Button
                  size="small"
                  fullWidth
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={loading}
                >
                  Submit
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Typography color="secondary">{errorMessage}</Typography>
              </Grid>
            </Grid>

            <div />
          </form>
        </Grid>
      </Grid>
    </div>
  );
};

export default CourseForm;

CourseForm.propTypes = {
  onClose: PropTypes.func,
  updateData: PropTypes.object,
};

CourseForm.defaultProps = {
  onClose: () => {
    console.log("close funct");
  },
  updateData: {
    name: "Course 1",
    price: 25,
  },
};
