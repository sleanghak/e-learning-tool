import React from "react";
import {
  Paper,
  Grid,
  TextField,
  Button,
  Typography,
  TextareaAutosize,
  Avatar,
  IconButton,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import ClearIcon from "@mui/icons-material/Clear";
import { Storage } from "aws-amplify";
import { LinearProgression } from "../../presentations/progressions";
import { uploadFile } from "../../../utils/func/s3";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
// import ReactLoading from 'react-loading';
const useStyles = makeStyles((theme) => ({
  root: {},
  title: {
    paddingTop: 10,
    textAlign: `left`,
    textTransform: `uppercase`,
  },

  textInput: {
    width: `100%`,
  },
  btnSubmit: {
    width: `100%`,

    marginBottom: 10,
  },
  loading: {
    display: "block",
    position: "fixed",
    top: `30vh`,
    margin: `0 auto`,
  },
  clearIcon: {
    position: "absolute",
    top: 0,
    right: 5,
  },
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: 150,
      cursor: "pointer",
    },
  },
}));

const ResourceForm = ({ onClose, courseId, lessons, socket }) => {
  const classes = useStyles();
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [progress, setProgress] = React.useState(0);
  const [data, setData] = React.useState({});
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const { name, fileName, type } = e.target.elements;
    setData({
      name: name.value,
      fileName: fileName.files[0],
      type: type.value,
    });
    try {
      const resource = await uploadFile(
        `resource/${courseId}`,
        fileName.files[0],
        setProgress,
        setError
      );
      await postDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course/resource/${courseId}`,
        {
          fileName: resource.key,
          type: type.value,
          name: name.value,
        }
      );
      socket.emit("detail-courseId", { id: courseId });
      setLoading(false);
      onClose();
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };
  return (
    <div className={classes.root}>
      <LinearProgression
        show={progress > 0 && progress < 100}
        increase={progress}
      />
      <Grid container justifyContent="center">
        <Grid item xs={11}>
          <IconButton
            onClick={onClose}
            color="secondary"
            className={classes.clearIcon}
          >
            <ClearIcon />
          </IconButton>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <div
                  className={data.fileName ? classes.uploadImg : classes.upload}
                >
                  <label htmlFor="fileName">
                    <img
                      id="icon"
                      alt="uploadIcon"
                      src={
                        data.fileName
                          ? "/icons/folders.png"
                          : "/icons/uploadImage.png"
                      }
                    />
                  </label>
                  <Typography align="center">
                    Upload a lesson or slide in PDF
                  </Typography>
                  <input
                    onChange={(e) =>
                      setData((prev) => ({
                        ...prev,
                        fileName: e.target.files[0],
                      }))
                    }
                    type="file"
                    hidden
                    id="fileName"
                    label="image URL"
                    variant="outlined"
                    name="fileName"
                    accept=".pdf"
                    required
                  />
                </div>
              </Grid>

              <Grid item xs={12}>
                <FormControl size="small" required variant="outlined" fullWidth>
                  <InputLabel id="demo-controlled-open-select-label">
                    Select Lesson
                  </InputLabel>
                  <Select
                    labelId="demo-controlled-open-select-label"
                    id="demo-controlled-open-select"
                    name="name"
                  >
                    {lessons?.map((lesson, index) => {
                      return (
                        <MenuItem key={index} value={lesson.name}>
                          {lesson.name}
                        </MenuItem>
                      );
                    })}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12}>
                <FormControl fullWidth variant="outlined" size="small">
                  <InputLabel id="demo-controlled-open-select-label">
                    Type
                  </InputLabel>
                  <Select
                    labelId="demo-controlled-open-select-label"
                    id="demo-controlled-open-select"
                    name="type"
                  >
                    <MenuItem value={"slide"}>Slide</MenuItem>
                    <MenuItem value={"book"}>Book</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6}>
                <Button
                  size="small"
                  type="cancel"
                  fullWidth
                  variant="contained"
                  color="error"
                  onClick={onClose}
                >
                  Cancel
                </Button>
              </Grid>

              <Grid item xs={6}>
                <Button
                  size="small"
                  fullWidth
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={loading}
                >
                  {loading ? "Submit ..." : "Submit"}
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Typography color="secondary">{error}</Typography>
              </Grid>
            </Grid>

            <div />
          </form>
        </Grid>
      </Grid>
    </div>
  );
};

export default ResourceForm;
