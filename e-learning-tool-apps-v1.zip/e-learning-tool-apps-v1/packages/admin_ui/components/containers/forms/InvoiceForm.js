import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Card,
  Box,
  TextField,
  Typography,
  // MenuItem,
  Button,
  Stack,
  IconButton,
  Grid,
  Checkbox,
  FormControl,
  Select,
  Input,
  ListItemText,
  InputLabel,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { MenuItem } from "@mui/material";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/getDataFunc";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import uploadFile from "../../../utils/func/s3/uploadFile";
import { makeStyles } from "@mui/styles";
import Autocomplete from "@mui/material/Autocomplete";
import { LinearProgression } from "../../presentations/progressions";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import unauthFetcher from "utils/func/api/unauthFetch";
import DatePicker from "@mui/lab/DatePicker";
import SabaiCodeLoading from "./../../presentations/loading";

const useStyles = makeStyles((theme) => ({
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    position: "relative",
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: "100%",
      cursor: "pointer",
    },
  },
}));

const InvoiceForm = ({ onClose, updateData, query, socket }) => {
  const classes = useStyles();
  const [file, setFile] = React.useState(null);
  const [progress, setProgress] = React.useState(0);
  const [studentData, setStudentData] = React.useState([]);
  const [classId, setClassId] = React.useState(null);
  const [message, setMessage] = React.useState("");
  const [update, setUpdate] = React.useState({
    ...updateData,
    students: [],
  });
  const [errorMsg, setErrorMsg] = React.useState("");
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/class?disable=false`,
    fetcher
  );
  const students = useSWR(
    classId ? `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/students` : null,
    fetcher
  );
  //`${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/students?classId=${classId._id}`
  console.log(updateData);
  const partners = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/partner`,
    unauthFetcher
  );

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setUpdate({
      ...update,
      students: typeof value === "string" ? value.split(",") : value,
    });
    setStudentData(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };
  // console.log(update)
  const handlePost = async (e) => {
    e.preventDefault();
    const form = e.target.elements;
    const coverFileName = form.coverFileName.files[0];

    // Update file and text
    // return;
    if (Boolean(updateData && file)) {
      if (!coverFileName) {
        setErrorMsg("Please select a file.");
        return;
      }
      try {
        const path = await uploadFile(
          "invoice/",
          coverFileName,
          setProgress,
          setMessage
        );
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/invoice/${update._id}`,
          {
            invoiceId: form.invoiceId.value,
            coverFileName: path.key,
            email: form.email.value,
            amount: form.amount.value,
            discount: form.discount.value,
            classId: classId?._id,
            description: form.description.value,
            dueDate: form.dueDate.value,
            studentIds: studentData,
            partner: form.partner?.value,
          }
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
      // update only text
    } else if (updateData) {
      try {
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/invoice/${update._id}`,
          {
            invoiceId: form.invoiceId.value,
            email: form.email.value,
            amount: form.amount.value,
            discount: form.discount.value,
            classId: classId?._id,
            description: form.description.value,
            dueDate: form.dueDate.value,
            studentIds: studentData,
            partner: form.partner?.value,
          }
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
      // create a new post
    } else {
      if (!coverFileName) {
        setErrorMsg("Please select a file.");
        return;
      }
      try {
        const path = await uploadFile(
          "invoice/",
          coverFileName,
          setProgress,
          setMessage
        );
        await postDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/invoice`,
          {
            invoiceId: form.invoiceId.value,
            coverFileName: path.key,
            email: form.email.value,
            amount: form.amount.value,
            discount: form.discount.value,
            classId: classId?._id,
            description: form.description.value,
            dueDate: form.dueDate.value,
            studentIds: studentData,
            partner: form.partner?.value,
          }
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
    }
    socket.emit("meta-invoice", query);
  };
  if (error) return "Form cannot data.";
  if (!data) return <SabaiCodeLoading />;

  return (
    <Box sx={{ p: { xs: 1, sm: 2, md: 3, lg: 4 } }}>
      <Stack
        direction={"row"}
        justifyItems="center"
        justifyContent={"space-between"}
        sx={{ mb: { xs: 1, sm: 2, md: 3, lg: 4 } }}
      >
        <Typography variant="h4">
          {updateData ? "Update Invoice" : "New Invoice"}
        </Typography>
        <IconButton onClick={onClose}>
          <CloseIcon color="secondary" />
        </IconButton>
      </Stack>

      <Box>
        <form onSubmit={handlePost}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Stack spacing={2}>
                <TextField
                  required
                  fullWidth
                  variant="standard"
                  size="large"
                  label="Invoice ID #1234"
                  name="invoiceId"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      invoiceId: e.target.value,
                    }))
                  }
                  value={update?.invoiceId}
                />

                <Autocomplete
                  onChange={(e, value) => {
                    setClassId(value);
                  }}
                  disablePortal
                  id="combo-box-demo"
                  options={data?.data}
                  getOptionLabel={(option) => option.name}
                  renderInput={(params) => (
                    <TextField
                      fullWidth
                      variant="standard"
                      size="large"
                      required
                      label={
                        updateData
                          ? `${update?.classId?.name}`
                          : "Seclect a class"
                      }
                      name="classId"
                      {...params}
                    />
                  )}
                />

                {classId && (
                  <FormControl fullWidth>
                    <InputLabel id="demo-multiple-checkbox-label">
                      Select Students
                    </InputLabel>
                    <Select
                      labelId="demo-multiple-checkbox-label"
                      id="demo-multiple-checkbox"
                      multiple
                      value={update?.students}
                      onChange={handleChange}
                      input={<Input fullWidth label="Select Students" />}
                      renderValue={(selected) => selected.join(", ")}
                      // MenuProps={MenuProps}
                    >
                      {students?.data?.map((item, i) => (
                        <MenuItem key={i} value={item._id}>
                          <Checkbox
                            checked={update?.students?.indexOf(item._id) > -1}
                          />
                          <ListItemText primary={item.name} />
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                )}
                <Autocomplete
                  disablePortal
                  id="combo-box-demo"
                  options={partners?.data?.data}
                  getOptionLabel={(option) => option.name}
                  renderInput={(params) => (
                    <TextField
                      value={update?.partner}
                      fullWidth
                      variant="standard"
                      size="large"
                      label={
                        updateData
                          ? `${update?.partner}`
                          : "Choose Organization"
                      }
                      name="partner"
                      {...params}
                    />
                  )}
                />
                <DatePicker
                  renderInput={(props) => (
                    <TextField name="dueDate" {...props} variant="standard" />
                  )}
                  label="Due Date"
                  required
                  value={update?.dueDate}
                  onChange={(newValue) => {
                    console.log(newValue);
                    setUpdate((prev) => ({
                      ...prev,
                      dueDate: newValue,
                    }));
                  }}
                />

                <TextField
                  type="email"
                  required
                  fullWidth
                  variant="standard"
                  size="large"
                  label="Email"
                  name="email"
                  onChange={(e) =>
                    setUpdate((prev) => ({ ...prev, email: e.target.value }))
                  }
                  value={update?.email}
                />
                <TextField
                  type="number"
                  required
                  fullWidth
                  variant="standard"
                  size="large"
                  label="Amount"
                  name="amount"
                  onChange={(e) =>
                    setUpdate((prev) => ({ ...prev, amount: e.target.value }))
                  }
                  value={update?.amount}
                />
                <TextField
                  required
                  fullWidth
                  type="number"
                  variant="standard"
                  size="large"
                  label="Discount"
                  name="discount"
                  onChange={(e) =>
                    setUpdate((prev) => ({ ...prev, discount: e.target.value }))
                  }
                  value={update?.discount}
                />
                <TextField
                  fullWidth
                  variant="standard"
                  size="large"
                  type="text"
                  multiline
                  rows={4}
                  label="Notes"
                  name="description"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                  value={update?.description}
                />
              </Stack>
            </Grid>
            <Grid item xs={12} md={6}>
              <div
                className={
                  file || update?.coverFileName
                    ? classes.uploadImg
                    : classes.upload
                }
              >
                <label htmlFor="coverFileName">
                  <img
                    id="icon"
                    alt="uploadIcon"
                    src={
                      update?.coverFileName && !file
                        ? update?.coverFileName
                        : file
                        ? window.URL.createObjectURL(file)
                        : "icons/uploadImage.png"
                    }
                  />
                </label>
                <input
                  onChange={(e) => setFile(e.target.files[0])}
                  type="file"
                  hidden
                  id="coverFileName"
                  label="image URL"
                  variant="outlined"
                  name="coverFileName"
                  required={!update}
                  accept=".png,.jpg,.jpeg"
                />

                {file ? (
                  <IconButton
                    onClick={() => setFile(null)}
                    sx={{ position: "absolute", top: 0, right: 0 }}
                  >
                    <HighlightOffIcon color="secondary" />
                  </IconButton>
                ) : (
                  <Typography sx={{ mt: 4 }} textAlign={"center"}>
                    Attact Invoice File
                  </Typography>
                )}
              </div>
            </Grid>
          </Grid>
          <Stack direction={"row"} spacing={3} sx={{ m: 3, float: "right" }}>
            <Button color="secondary" variant="outlined" onClick={onClose}>
              Cancel
            </Button>
            <Button color="primary" variant="contained" type="submit">
              {updateData ? "Update" : "Submit"}
            </Button>
          </Stack>
          <Typography color="secondary">{errorMsg}</Typography>

          <LinearProgression
            show={progress > 0 && progress <= 100}
            increase={progress}
          />
        </form>
      </Box>
    </Box>
  );
};

export default InvoiceForm;

InvoiceForm.propTypes = {};

InvoiceForm.defaultProps = {};
