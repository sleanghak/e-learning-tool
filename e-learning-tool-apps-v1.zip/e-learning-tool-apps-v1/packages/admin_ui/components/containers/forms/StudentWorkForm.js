import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Card,
  Box,
  TextField,
  Typography,
  // MenuItem,
  Button,
  Grid,
  Stack,
  ImageList,
  ImageListItem,
  FormControl,
  InputLabel,
  Select,
  OutlinedInput,
  Checkbox,
  ListItemText,
  Input,
} from "@mui/material";
import ClearIcon from "@mui/icons-material/Clear";
import { IconButton, MenuItem } from "@mui/material";
import { makeStyles } from "@mui/styles";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/getDataFunc";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import uploadFile from "../../../utils/func/s3/uploadFile";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import { LinearProgression } from "../../presentations/progressions";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import DatePicker from "@mui/lab/DatePicker";
import SabaiCodeLoading from "../../presentations/loading";
import Image from "next/image";
import { uploadFiles } from "utils/func/s3";
const useStyles = makeStyles((theme) => ({
  root: {
    boxShadow: "none",
    minWidth: 400,
    padding: "30px 40px",
  },
  title: {
    width: "100%",
    marginBottom: 30,
  },

  button: {
    diplay: "flex",
    alignItems: "center",
    textAlign: "right",
    marginTop: 40,
  },
}));

const StudentWorkForm = ({ onClose, updateData, socket, query }) => {
  const classes = useStyles();
  const [file, setFile] = React.useState(null);
  const [progress, setProgress] = React.useState(0);
  const [update, setUpdate] = React.useState({
    students: [],
  });
  const [errorMsg, setErrorMsg] = React.useState("");
  const [studentData, setStudentData] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const courses = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course?disable=false`,
    fetcher
  );
  const students = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/students`,
    fetcher
  );
  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setUpdate({
      ...update,
      students: typeof value === "string" ? value.split(",") : value,
    });
    setStudentData(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  // console.log(update)
  const handlePost = async (e) => {
    e.preventDefault();
    let files = [];
    const form = e.target.elements;
    if (file) {
      files = Array.from(file);
    }
    console.log(form.fileName.files[0]);

    setLoading(true);
    try {
      const images = await uploadFiles(
        "student-work",
        files,
        setProgress,
        setErrorMsg
      );
      let filePath;
      const fileName = await uploadFile(
        "student-work",
        form.fileName.files[0],
        setProgress,
        setErrorMsg
      );
      filePath = fileName?.key;
      const data = await postDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/student_work`,
        {
          images: images,
          name: form.name.value,
          course: form.courseId.value,
          students: studentData,
          date: form.date.value,
          link: form.link.value,
          description: form.description.value,
          fileName: filePath,
        }
      );
      if (data.statusCode === 200) {
        onClose();
      } else {
        setErrorMsg(data.message);
      }
    } catch (error) {
      setErrorMsg(error.message);
    }
    socket.emit("meta-student_work", query);
    setLoading(false);
  };

  return (
    <Card className={classes.root}>
      <Stack direction={"row"} justifyContent="space-between">
        <Typography variant="h6">
          {updateData ? "Update Student Work" : "New Student Work"}
        </Typography>
        <IconButton onClick={onClose}>
          <ClearIcon color="secondary" />
        </IconButton>
      </Stack>
      <Box className={classes.body}>
        <form onSubmit={handlePost}>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}>
              <Box>
                <label htmlFor="coverFileName">
                  <Box sx={{ width: 100, margin: "0px auto" }}>
                    <Image
                      src="/icons/uploadImage.png"
                      alt="upload"
                      width={100}
                      height={100}
                    />
                    <input
                      onChange={(e) => setFile(e.target.files)}
                      type="file"
                      hidden
                      multiple
                      id="coverFileName"
                      label="image URL"
                      variant="outlined"
                      name="coverFileName"
                      required={!update}
                      accept=".png,.jpg,.jpeg"
                    />
                  </Box>
                </label>
                {file ? (
                  <ImageList
                    sx={{ width: "100%", height: 450 }}
                    cols={3}
                    rowHeight={164}
                  >
                    {Array.from(file).map((item, index) => {
                      return (
                        <ImageListItem
                          sx={{ position: "relative" }}
                          key={index}
                        >
                          <img
                            id="icon"
                            alt="uploadIcon"
                            src={window.URL.createObjectURL(item)}
                          />
                          {/* <IconButton
                              onClick={() =>
                                setFile((prev) =>
                                  Array.from(prev).splice(index, 1)
                                )
                              }
                              sx={{ position: "absolute", top: 0, right: 0 }}
                            >
                              <Clear color="secondary" />
                            </IconButton> */}
                        </ImageListItem>
                      );
                    })}
                  </ImageList>
                ) : (
                  <></>
                  // <img src="/icons/uploadImage.png" alt="upload" />
                )}
                <Stack
                  sx={{
                    backgroundColor: "#f5f5f5",
                    borderRadius: 4,
                    p: 4,
                  }}
                  direction={"row"}
                  justifyContent="space-between"
                  alignItems={"center"}
                >
                  <Typography>Upload Video about project</Typography>
                  <input type="file" accept=".mp4" name="fileName" />
                </Stack>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Stack spacing={3}>
                <TextField
                  fullWidth
                  required
                  variant="standard"
                  size="large"
                  label="Project Name"
                  name="name"
                  onChange={(e) =>
                    setUpdate((prev) => ({ ...prev, name: e.target.value }))
                  }
                  value={update?.name}
                />
                <TextField
                  fullWidth
                  variant="standard"
                  size="large"
                  select
                  required
                  label="Course"
                  name="courseId"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      courseId: e.target.value,
                    }))
                  }
                  value={update?.course?._id}
                >
                  {courses.data ? (
                    courses.data?.data.map((item, index) => {
                      return (
                        <MenuItem key={index} value={item._id}>
                          {item.name}
                        </MenuItem>
                      );
                    })
                  ) : (
                    <SabaiCodeLoading />
                  )}
                </TextField>

                {students?.data ? (
                  <FormControl fullWidth>
                    <InputLabel id="demo-multiple-checkbox-label">
                      Select Students
                    </InputLabel>
                    <Select
                      labelId="demo-multiple-checkbox-label"
                      id="demo-multiple-checkbox"
                      multiple
                      value={update?.students}
                      onChange={handleChange}
                      input={<Input fullWidth label="Select Students" />}
                      renderValue={(selected) => selected.join(", ")}
                      // MenuProps={MenuProps}
                    >
                      {students?.data?.map((item, i) => (
                        <MenuItem key={i} value={item._id}>
                          <Checkbox
                            checked={update?.students?.indexOf(item._id) > -1}
                          />
                          <ListItemText primary={item.name} />
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                ) : (
                  <SabaiCodeLoading />
                )}

                <DatePicker
                  renderInput={(props) => (
                    <TextField
                      fullWidth
                      name="date"
                      {...props}
                      variant="standard"
                    />
                  )}
                  label="Publish Date"
                  value={update?.date}
                  onChange={(newValue) => {
                    setUpdate((prev) => ({
                      ...prev,
                      date: newValue,
                    }));
                  }}
                />

                <TextField
                  fullWidth
                  variant="standard"
                  size="large"
                  label="Publish URL / https//:www.example.com"
                  name="link"
                  onChange={(e) =>
                    setUpdate((prev) => ({ ...prev, link: e.target.value }))
                  }
                  value={update?.link}
                />
                <TextField
                  required
                  fullWidth
                  variant="standard"
                  size="large"
                  type="text"
                  multiline
                  rows={6}
                  label="Project Description"
                  name="description"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                  value={update?.description}
                />
              </Stack>
            </Grid>
          </Grid>

          <Typography color="secondary">{errorMsg}</Typography>
          <Box className={classes.button}>
            <Box>
              <Button
                variant="text"
                onClick={onClose}
                sx={{ fontFamily: "Arial" }}
              >
                Cancel
              </Button>
              <Button
                disabled={loading}
                type="submit"
                variant="text"
                sx={{ fontFamily: "Arial" }}
              >
                {updateData ? "Update" : "Submit"}
              </Button>
            </Box>
          </Box>
          <LinearProgression
            show={progress > 0 && progress <= 100}
            increase={progress}
          />
        </form>
      </Box>
    </Card>
  );
};

export default StudentWorkForm;

StudentWorkForm.propTypes = {};

StudentWorkForm.defaultProps = {};
