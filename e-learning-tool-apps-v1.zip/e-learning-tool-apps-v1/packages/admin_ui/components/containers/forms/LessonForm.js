import React from "react";
import {
  Paper,
  Grid,
  TextField,
  Button,
  Typography,
  TextareaAutosize,
  Avatar,
  IconButton,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import ClearIcon from "@mui/icons-material/Clear";
import { Storage } from "aws-amplify";
import { LinearProgression } from "../../presentations/progressions";
import { uploadFile } from "../../../utils/func/s3";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import getVideoDuration from "../../../utils/func/files/getVideoDuration";
// import ReactLoading from 'react-loading';
const useStyles = makeStyles((theme) => ({
  root: {},
  title: {
    paddingTop: 10,
    textAlign: `left`,
    textTransform: `uppercase`,
  },

  textInput: {
    width: `100%`,
  },
  btnSubmit: {
    width: `100%`,

    marginBottom: 10,
  },
  loading: {
    display: "block",
    position: "fixed",
    top: `30vh`,
    margin: `0 auto`,
  },
  clearIcon: {
    position: "absolute",
    top: 0,
    right: 5,
  },
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: 150,
      cursor: "pointer",
    },
  },
}));

const LessonForm = ({ onClose, courseId, socket }) => {
  const classes = useStyles();
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [progress, setProgress] = React.useState(0);
  const [data, setData] = React.useState({});

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const { name, coverFileName, description } = e.target.elements;

    try {
      setData({
        name: name.value,
        coverFileName: coverFileName.files[0],
        description: description.value,
      });
      const uploadCover = await uploadFile(
        "coverVideoLessons",
        coverFileName.files[0],
        setProgress,
        setError
      );
      await updateDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course/addlesson/${courseId}`,
        {
          name: name.value,
          description: description.value,
          coverFileName: uploadCover.key,
        }
      );
      socket.emit("detail-courseId", { id: courseId });
      setLoading(false);
      onClose();
    } catch (error) {
      setLoading(false);
      console.log(error);
      setError(error.message);
    }
  };
  return (
    <div className={classes.root}>
      <LinearProgression
        show={progress > 0 && progress < 100}
        increase={progress}
      />
      <Grid container justifyContent="center">
        <Grid item xs={11}>
          <IconButton
            onClick={onClose}
            color="secondary"
            className={classes.clearIcon}
          >
            <ClearIcon />
          </IconButton>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <div
                  className={
                    data.coverFileName ? classes.uploadImg : classes.upload
                  }
                >
                  <label htmlFor="coverFileName">
                    <img
                      id="icon"
                      alt="uploadIcon"
                      src={
                        data.coverFileName
                          ? window.URL.createObjectURL(data.coverFileName)
                          : "/icons/uploadImage.png"
                      }
                    />
                  </label>
                  <input
                    onChange={(e) =>
                      setData((prev) => ({
                        ...prev,
                        coverFileName: e.target.files[0],
                      }))
                    }
                    type="file"
                    hidden
                    id="coverFileName"
                    label="image URL"
                    variant="outlined"
                    name="coverFileName"
                    accept=".jpg,.png,.jpeg"
                    required
                  />
                </div>
              </Grid>

              <Grid item xs={12} sm={12}>
                <TextField
                  size="small"
                  className={classes.textInput}
                  id="outlined-select-currency-native"
                  required
                  label="Enter Lesson Name"
                  variant="outlined"
                  name="name"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  multiline
                  rows={3}
                  size="small"
                  fullWidth
                  id="outlined-select-currency-native"
                  required
                  label="Lesson Description"
                  variant="outlined"
                  name="description"
                />
              </Grid>

              <Grid item xs={6}>
                <Button
                  size="small"
                  type="cancel"
                  fullWidth
                  variant="contained"
                  color="error"
                  onClick={onClose}
                >
                  Cancel
                </Button>
              </Grid>

              <Grid item xs={6}>
                <Button
                  size="small"
                  fullWidth
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={loading}
                >
                  {loading ? "Submit ..." : "Submit"}
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Typography color="secondary">{error}</Typography>
              </Grid>
            </Grid>

            <div />
          </form>
        </Grid>
      </Grid>
    </div>
  );
};

export default LessonForm;
