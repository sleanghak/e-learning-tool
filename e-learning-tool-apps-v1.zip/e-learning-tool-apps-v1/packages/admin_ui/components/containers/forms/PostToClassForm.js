import React from "react";
import {
  Menu,
  Typography,
  Button,
  Select,
  FormControl,
  MenuItem,
  Stack,
} from "@mui/material";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/getDataFunc";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import SabaiCodeLoading from "../../../components/presentations/loading";
const PostToClassForm = ({ postId, onClose }) => {
  const [loading, setLoading] = React.useState(false);
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/coaches`,
    fetcher
  );
  if (error) return <Typography>Error Occured</Typography>;
  if (!data) return <SabaiCodeLoading />;

  const handleCreateClass = async (e) => {
    e.preventDefault();

    const { coachId } = e.target.elements;
    console.log(coachId.value, postId);
    setLoading(true);
    try {
      await postDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/admin/post/${postId}/toclass`,
        {
          coachId: coachId.value,
        }
      );
      onClose();
      console.log("Success create a class.");
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };
  if (error) return "Error Occured";
  if (!data) return <SabaiCodeLoading />;
  return (
    <div style={{ minWidth: 400, margin: 24 }}>
      <form onSubmit={handleCreateClass}>
        <div spacing={3}>
          <div>
            <Typography variant="h6">Create a class by post</Typography>
            <Typography>Choose a coach to control a class. </Typography>
          </div>

          {/* <Select name="coachId" required style={{ padding: 12 }} fullWidth>
            <Menu disabled> Select a coach</Menu>
            {data.map((user) => {
              return (
                <Menu key={user._id} value={user._id}>
                  {user.name}
                </Menu>
              );
            })}
          </Select> */}

          <FormControl
            sx={{ mb: 2, mt: 2 }}
            fullWidth
            required
            variant="standard"
          >
            <Select name="coachId">
              {data.map((user) => {
                return (
                  <MenuItem key={user._id} value={user._id}>
                    {user.name}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
          <Stack direction={"row"}>
            <Button onClick={onClose}>
              <Typography style={{ color: "#000", fontSize: 14 }}>
                Cancel
              </Typography>
            </Button>
            <Button disabled={loading} type="submit">
              Submit
            </Button>
          </Stack>
        </div>
      </form>
    </div>
  );
};

export default PostToClassForm;
