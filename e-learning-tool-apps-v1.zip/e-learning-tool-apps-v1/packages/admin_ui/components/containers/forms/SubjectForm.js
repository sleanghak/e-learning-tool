import React from "react";
import {
  TextField,
  IconButton,
  Button,
  Stack,
  Typography,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import ClearIcon from "@mui/icons-material/Clear";
import { uploadFile } from "../../../utils/func/s3";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";

const useStyles = makeStyles((theme) => ({
  root: {
    width: 400,
    padding: 8,
  },
  clearIcon: {
    position: "absolute",
    top: 0,
    right: 5,
  },
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: 200,
      cursor: "pointer",
    },
  },
  input: {
    marginTop: 16,
  },
}));
const SubjectForm = ({ onClose, updateData, socket, query }) => {
  const classes = useStyles();
  const [file, setFile] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const [update, setUpdate] = React.useState(updateData);
  const [progress, setProgress] = React.useState(0);
  const [msg, setMsg] = React.useState("");
  const handleClose = () => {
    onClose();
    setUpdate(null);
  };
  const handleCreateSubject = async (e) => {
    e.preventDefault();
    setLoading(true);
    const coverFileName = e.target.elements.coverFileName.files[0];
    const name = e.target.elements.name.value;
    const desc = e.target.elements.desc.value;
    try {
      // Udpate data and update image
      if (Boolean(updateData && file)) {
        const res = await uploadFile(
          "coverFileSubject/",
          coverFileName,
          setProgress,
          setMsg
        );
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/department/${update._id}`,
          {
            coverFileName: res.key,
            name,
            desc,
          }
        );
        setLoading(false);
        handleClose();
      }
      // Update Data
      else if (updateData) {
        // do not chnage image
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/department/${update._id}`,
          {
            name,
            desc,
          }
        );
        setLoading(false);
        handleClose();
      }
      //  Post Data
      else {
        if (!coverFileName) {
          setMsg("Select a file");
          return;
        }
        const res = await uploadFile(
          "coverFileSubject",
          coverFileName,
          setProgress,
          setMsg
        );
        await postDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/department`,
          {
            coverFileName: res.key,
            name,
            desc,
          }
        );
        setLoading(false);
        handleClose();
      }
      socket.emit("meta-department", query);
    } catch (error) {
      console.log(error);
      setLoading(false);
      handleClose();
    }
  };

  return (
    <form onSubmit={handleCreateSubject} className={classes.root}>
      <IconButton
        onClick={handleClose}
        color="secondary"
        className={classes.clearIcon}
      >
        <ClearIcon />
      </IconButton>
      <div
        className={
          file || update?.coverFileName ? classes.uploadImg : classes.upload
        }
      >
        <label htmlFor="coverFileName">
          <img
            id="icon"
            alt="uploadIcon"
            src={
              update?.coverFileName && !file
                ? update?.coverFileName
                : file
                ? window.URL.createObjectURL(file)
                : "icons/uploadImage.png"
            }
          />
          <Typography textAlign={"center"}>Select a file</Typography>
        </label>
        <input
          onChange={(e) => setFile(e.target.files[0])}
          type="file"
          hidden
          id="coverFileName"
          label="image URL"
          variant="outlined"
          name="coverFileName"
          required={!update}
          accept=".png,.jpg,.jpeg"
        />
      </div>
      <TextField
        fullWidth
        required
        label="Name"
        variant="outlined"
        name="name"
        onChange={(e) =>
          setUpdate((prev) => ({ ...prev, name: e.target.value }))
        }
        value={update?.name}
        className={classes.input}
      />
      <TextField
        fullWidth
        label="Description"
        variant="outlined"
        name="desc"
        onChange={(e) =>
          setUpdate((prev) => ({ ...prev, desc: e.target.value }))
        }
        value={update?.desc}
        multiline
        className={classes.input}
      />
      <Typography color="secondary">{msg}</Typography>
      <Stack direction={"row"} spacing={2} sx={{ mt: 2 }}>
        <Button
          variant="outlined"
          fullWidth
          onClick={onClose}
          color="secondary"
        >
          Cancel
        </Button>
        <Button
          disabled={loading}
          fullWidth
          className={classes.input}
          variant="contained"
          color="primary"
          type="submit"
        >
          {loading
            ? `Loading ... ${progress}`
            : updateData
            ? "Update"
            : "Create"}
        </Button>
      </Stack>
    </form>
  );
};

export default SubjectForm;
