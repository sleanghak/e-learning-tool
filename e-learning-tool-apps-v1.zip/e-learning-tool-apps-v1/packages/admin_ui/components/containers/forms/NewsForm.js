import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Card,
  Box,
  TextField,
  Typography,
  // MenuItem,
  Button,
  Stack,
  IconButton,
  Grid,
  Checkbox,
  FormControl,
  Select,
  Input,
  ListItemText,
  InputLabel,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { MenuItem } from "@mui/material";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/getDataFunc";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import uploadFile from "../../../utils/func/s3/uploadFile";
import { makeStyles } from "@mui/styles";
import Autocomplete from "@mui/material/Autocomplete";
import { LinearProgression } from "../../presentations/progressions";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import DateTimePicker from "@mui/lab/DateTimePicker";
import HighlightOffIcon from "@mui/icons-material/HighlightOff";
import unauthFetcher from "utils/func/api/unauthFetch";

import DatePicker from "@mui/lab/DatePicker";
import SabaiCodeLoading from "./../../presentations/loading";
const useStyles = makeStyles((theme) => ({
  upload: {
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      width: 100,
      margin: "0 auto",
      cursor: "pointer",
    },
  },
  uploadImg: {
    position: "relative",
    marginTop: 16,
    marginBottom: 8,
    "& img": {
      display: "block",
      margin: "0 auto",
      width: "100%",
      cursor: "pointer",
    },
  },
}));

const NewsForm = ({ onClose, updateData, socket, query }) => {
  const classes = useStyles();
  const [file, setFile] = React.useState(null);
  const [progress, setProgress] = React.useState(0);
  const [type, setType] = React.useState();
  const [loading, setLoading] = React.useState(false);
  const [update, setUpdate] = React.useState({
    ...updateData,
    students: [],
  });

  const [errorMsg, setErrorMsg] = React.useState("");

  const partners = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/partner`,
    unauthFetcher
  );

  // console.log(update)
  const handlePost = async (e) => {
    e.preventDefault();
    const form = e.target.elements;
    const coverFileName = form.coverFileName.files[0];
    // console.log({
    //   coverFileName: coverFileName,
    //   name: form.name.value,
    //   description: form.description.value,
    //   type: form.type.value,
    //   partner: form.partner?.value,
    //   dueDate: form.dueDate.value,
    // });
    // Update file and text

    setLoading(true);
    if (Boolean(updateData && file)) {
      if (!coverFileName) {
        setErrorMsg("Please select a file.");
        return;
      }
      try {
        const path = await uploadFile(
          "news/",
          coverFileName,
          setProgress,
          setErrorMsg
        );
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/news/${update._id}`,
          {
            coverFileName: path.key,
            name: form.name.value,
            description: form.description.value,
            type: form.type.value,
            partner: form.partner?.value,
            dueDate: form.dueDate.value,
          }
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
      // update only text
    } else if (updateData) {
      try {
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/news/${update._id}`,
          {
            name: form.name.value,
            description: form.description.value,
            type: form.type.value,
            partner: form.partner?.value,
            dueDate: form.dueDate.value,
          }
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
      // create a new post
    } else {
      if (!coverFileName) {
        setErrorMsg("Please select a file.");
        return;
      }
      try {
        const path = await uploadFile(
          "news/",
          coverFileName,
          setProgress,
          setErrorMsg
        );
        await postDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/news`,
          {
            coverFileName: path.key,
            name: form.name.value,
            description: form.description.value,
            type: form.type.value,
            partner: form.partner?.value,
            dueDate: form.dueDate.value,
          }
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
    }
    setLoading(false);
    socket.emit("meta-news", query);
  };
  if (partners?.error) return "Form cannot data.";
  if (!partners?.data) return <SabaiCodeLoading />;

  return (
    <Box sx={{ p: { xs: 1, sm: 2, md: 3, lg: 4 } }}>
      <Stack
        direction={"row"}
        justifyItems="center"
        justifyContent={"space-between"}
        sx={{ mb: { xs: 1, sm: 2, md: 3, lg: 4 } }}
      >
        <Typography variant="h4">
          {updateData ? "Update News" : "Post News"}
        </Typography>
        <IconButton onClick={onClose}>
          <CloseIcon color="secondary" />
        </IconButton>
      </Stack>

      <Box>
        <form onSubmit={handlePost}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Stack spacing={2}>
                <TextField
                  required
                  fullWidth
                  variant="standard"
                  size="large"
                  label="Title "
                  name="name"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      name: e.target.value,
                    }))
                  }
                  value={update?.name}
                />
                <FormControl
                  required
                  variant="standard"
                  style={{ minWidth: 100 }}
                >
                  <InputLabel id="type">Type</InputLabel>
                  <Select
                    name={"type"}
                    labelId="statusl"
                    id="type"
                    value={update?.type}
                    onChange={(e) => setType(e.target.value)}
                  >
                    <MenuItem value={"job"}>Career</MenuItem>
                    <MenuItem value={"scholarship"}>Scholarship</MenuItem>
                  </Select>
                </FormControl>
                {type === "scholarship" && (
                  <Autocomplete
                    disablePortal
                    id="combo-box-demo"
                    options={partners?.data?.data}
                    getOptionLabel={(option) => option.name}
                    renderInput={(params) => (
                      <TextField
                        value={update?.partner}
                        fullWidth
                        variant="standard"
                        size="large"
                        label="Choose Organization"
                        name="partner"
                        {...params}
                      />
                    )}
                  />
                )}
                <DatePicker
                  renderInput={(props) => (
                    <TextField name="dueDate" {...props} variant="standard" />
                  )}
                  label="Due Date"
                  required
                  value={update?.dueDate}
                  onChange={(newValue) => {
                    console.log(newValue);
                    setUpdate((prev) => ({
                      ...prev,
                      dueDate: newValue,
                    }));
                  }}
                />

                <TextField
                  fullWidth
                  variant="standard"
                  size="large"
                  type="text"
                  multiline
                  rows={6}
                  label="Description"
                  name="description"
                  onChange={(e) =>
                    setUpdate((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                  value={update?.description}
                />
              </Stack>
            </Grid>
            <Grid item xs={12} md={6}>
              <div
                className={
                  file || update?.coverFileName
                    ? classes.uploadImg
                    : classes.upload
                }
              >
                <label htmlFor="coverFileName">
                  <img
                    id="icon"
                    alt="uploadIcon"
                    src={
                      update?.coverFileName && !file
                        ? update?.coverFileName
                        : file
                        ? window.URL.createObjectURL(file)
                        : "icons/uploadImage.png"
                    }
                  />
                </label>
                <input
                  onChange={(e) => setFile(e.target.files[0])}
                  type="file"
                  hidden
                  id="coverFileName"
                  label="image URL"
                  variant="outlined"
                  name="coverFileName"
                  required={!update}
                  accept=".png,.jpg,.jpeg"
                />

                {file ? (
                  <IconButton
                    onClick={() => setFile(null)}
                    sx={{ position: "absolute", top: 0, right: 0 }}
                  >
                    <HighlightOffIcon color="secondary" />
                  </IconButton>
                ) : (
                  <Typography sx={{ mt: 4 }} textAlign={"center"}>
                    Attact a file
                  </Typography>
                )}
              </div>
            </Grid>
          </Grid>
          <Stack direction={"row"} spacing={3} sx={{ m: 3, float: "right" }}>
            <Button color="secondary" variant="outlined" onClick={onClose}>
              Cancel
            </Button>
            <Button
              disabled={loading}
              color="primary"
              variant="contained"
              type="submit"
            >
              {updateData ? "Update" : "Submit"}
            </Button>
          </Stack>
          <Typography color="secondary">{errorMsg}</Typography>

          <LinearProgression
            show={progress > 0 && progress <= 100}
            increase={progress}
          />
        </form>
      </Box>
    </Box>
  );
};

export default NewsForm;

NewsForm.propTypes = {};

NewsForm.defaultProps = {};
