import LoginForm from "./LoginForm";
import CourseForm from "./CourseForm";
import LessonForm from "./LessonForm";
import SubjectForm from "./SubjectForm";
import InventoryForm from "./InventoryForm";
import CoachForm from "./CoachForm";
import Copyright from "./Copyright";
import ResourceForm from "./ResourceForm";
import MediaForm from "./MediaForm";

export {
  LoginForm,
  CourseForm,
  LessonForm,
  SubjectForm,
  InventoryForm,
  Copyright,
  CoachForm,
  ResourceForm,
  MediaForm,
};
