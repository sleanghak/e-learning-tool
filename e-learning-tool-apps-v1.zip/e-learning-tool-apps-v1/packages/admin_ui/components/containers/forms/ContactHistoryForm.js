import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Card,
  Box,
  TextField,
  Typography,
  // MenuItem,
  Button,
  Menu,
} from "@mui/material";
import { MenuItem } from "@mui/material";
import { makeStyles } from "@mui/styles";
import useSWR from "swr";
import fetcher from "../../../utils/func/api/getDataFunc";
import postDataFunc from "../../../utils/func/api/postDataFunc";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";

const useStyles = makeStyles((theme) => ({
  root: {
    boxShadow: "none",
    minWidth: 400,
    padding: "30px 40px",
  },
  title: {
    width: "100%",
    marginBottom: 30,
  },
  input: {
    marginBottom: 20,
    color: "#7D7878",
  },
  button: {
    diplay: "flex",
    alignItems: "center",
    textAlign: "right",
    marginTop: 40,
  },
}));

const ContactHistoryForm = ({ onClose, updateData, socket, query }) => {
  const classes = useStyles();
  const [update, setUpdate] = React.useState(updateData);
  // console.log(updateData)
  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/course?disable=false`,
    fetcher
  );
  const handleCreateAttendance = async (e) => {
    e.preventDefault();
    const form = e.target.elements;

    if (updateData) {
      try {
        await updateDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/contact_history/${update._id}`,
          {
            name: form.name.value,
            tel: form.tel.value,
            email: form.email.value,
            knownBy: form.knownBy.value,
            courseId: form.courseId.value,
            description: form.description.value,
          }
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
    } else {
      try {
        await postDataFunc(
          `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/contact_history`,
          {
            name: form.name.value,
            tel: form.tel.value,
            email: form.email.value,
            knownBy: form.knownBy.value,
            courseId: form.courseId.value,
            description: form.description.value,
          }
        );
        onClose();
      } catch (error) {
        console.info(error);
      }
    }
    socket.emit("meta-contact_history", query);
  };
  return (
    <Card className={classes.root}>
      <Box className={classes.title}>
        <Typography variant="h6">
          {updateData ? "Update Contact" : "New Contact"}
        </Typography>
      </Box>
      <Box className={classes.body}>
        <form onSubmit={handleCreateAttendance}>
          <TextField
            className={classes.input}
            fullWidth
            variant="standard"
            size="large"
            label="Name"
            name="name"
            onChange={(e) =>
              setUpdate((prev) => ({ ...prev, name: e.target.value }))
            }
            value={update?.name}
          />
          <TextField
            className={classes.input}
            fullWidth
            variant="standard"
            size="large"
            label="Tel"
            name="tel"
            onChange={(e) =>
              setUpdate((prev) => ({ ...prev, tel: e.target.value }))
            }
            value={update?.tel}
          />
          <TextField
            className={classes.input}
            fullWidth
            variant="standard"
            size="large"
            label="Email"
            name="email"
            onChange={(e) =>
              setUpdate((prev) => ({ ...prev, email: e.target.value }))
            }
            value={update?.email}
          />
          <TextField
            className={classes.input}
            fullWidth
            variant="standard"
            size="large"
            select
            label="Known By"
            name="knownBy"
            onChange={(e) =>
              setUpdate((prev) => ({
                ...prev,
                knownBy: e.target.value,
              }))
            }
            value={update?.knownBy}
          >
            <MenuItem value={"facebook"}>Facebook</MenuItem>
            <MenuItem value={"friend"}>Friend</MenuItem>
            <MenuItem value={"family"}>Family</MenuItem>
            <MenuItem value={"other"}>Other</MenuItem>
          </TextField>
          <TextField
            className={classes.input}
            fullWidth
            variant="standard"
            size="large"
            select
            label="Course"
            name="courseId"
            onChange={(e) =>
              setUpdate((prev) => ({
                ...prev,
                courseId: e.target.value,
              }))
            }
            value={update?.courseId?._id}
          >
            {data?.data?.map((item, index) => {
              return (
                <MenuItem key={index} value={item._id}>
                  {item.name}
                </MenuItem>
              );
            })}
          </TextField>
          <TextField
            className={classes.input}
            fullWidth
            variant="standard"
            size="large"
            type="text"
            multiline
            rows={4}
            label="Description"
            name="description"
            onChange={(e) =>
              setUpdate((prev) => ({ ...prev, description: e.target.value }))
            }
            value={update?.description}
          />
          <Box>
            <MenuItem>1. Experience Coding</MenuItem>
            <MenuItem>
              2. High School or Unversity Stuent, if Unversity, major?
            </MenuItem>
          </Box>

          <Box className={classes.button}>
            <Box>
              <Button
                variant="text"
                onClick={onClose}
                sx={{ fontFamily: "Arial" }}
              >
                <Typography style={{ color: "#000" }}>Cancel</Typography>
              </Button>
              <Button type="submit" variant="text" sx={{ fontFamily: "Arial" }}>
                {updateData ? "Update" : "Submit"}
              </Button>
            </Box>
          </Box>
        </form>
      </Box>
    </Card>
  );
};

export default ContactHistoryForm;

ContactHistoryForm.propTypes = {};

ContactHistoryForm.defaultProps = {};
