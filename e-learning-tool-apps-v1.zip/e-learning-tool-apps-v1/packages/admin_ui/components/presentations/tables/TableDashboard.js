import React from "react";
import { makeStyles } from "@mui/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";

const useStyles = makeStyles({
  table: {
    minWidth: 650,
    boxShadow: `0px 0px 2px 2px rgba(0, 0, 0, 0.25)`,
    width: `100%`,
  },
});

function createData(
  month,
  users,
  new_users,
  bridge,
  bridge_update,
  road,
  road_update
) {
  return { month, users, new_users, bridge, bridge_update, road, road_update };
}

const rows = [createData("កមរា", 159, 6, 24, 4, 24)];

export default function TableDashboard() {
  const classes = useStyles();

  return (
    <Paper>
      <TableContainer component={Paper}>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>
                <Typography>ខែ</Typography>
              </TableCell>
              <TableCell align="center">
                <Typography fontWeight={400}>អ្នកប្រើប្រាស់</Typography>
              </TableCell>
              <TableCell align="center">
                <Typography fontWeight={400}>ស្ពាន</Typography>
              </TableCell>
              <TableCell align="center">
                <Typography fontWeight={400}>ផ្លូវថ្នល់</Typography>
              </TableCell>
              <TableCell align="center">
                <Typography fontWeight={400}>ការអភិវឌ្ឍន៍ផ្លូវថ្នល់</Typography>
              </TableCell>
              <TableCell align="center">
                <Typography fontWeight={400}>ការអភិវឌ្ឍន៍ស្ពាន</Typography>{" "}
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <TableRow key={row.month}>
                <TableCell component="th" scope="row">
                  <Typography fontWeight={400}>{row.month}</Typography>
                </TableCell>
                <TableCell align="center">{row.users}</TableCell>
                <TableCell align="center">{row.new_users}</TableCell>
                <TableCell align="center">{row.bridge}</TableCell>
                <TableCell align="center">{row.bridge_update}</TableCell>
                <TableCell align="center">{row.road}</TableCell>
                <TableCell align="center">{row.road_update}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}
