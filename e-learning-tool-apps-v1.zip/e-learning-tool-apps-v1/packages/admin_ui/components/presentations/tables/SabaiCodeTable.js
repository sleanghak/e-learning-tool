import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Paper,
  TableContainer,
  Table,
  Typography,
  Box,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  IconButton,
  Stack,
  Avatar,
  Menu,
  MenuItem,
  ListItemIcon,
  Snackbar,
} from "@mui/material";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import CachedIcon from "@mui/icons-material/Cached";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import EditRoundedIcon from "@mui/icons-material/EditRounded";
import DeleteRoundedIcon from "@mui/icons-material/DeleteRounded";
import { toDateFormat, toTime } from "../../../utils/func/toDateFormat";
import Pagination from "@mui/lab/Pagination";
import VisibilityIcon from "@mui/icons-material/Visibility";
import { useRouter } from "next/router";
import CloseIcon from "@mui/icons-material/Close";
import ClassIcon from "@mui/icons-material/Class";
const SabaiCodeTable = ({
  createClassByPostFunc,
  changeStatusFunc,
  columns,
  editFunc,
  deleteFunc,
  disableFunc,
  page,
  pages,
  setPage,
  anchorEl,
  setAnchorEl,
  data = [],
  disable,
  view,
}) => {
  const open = Boolean(anchorEl);
  const router = useRouter();
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const [activeItem, setActiveItem] = React.useState({});

  return (
    <Paper>
      <TableContainer sx={{ pl: 2 }}>
        <Table>
          <TableHead style={{ margin: 8 }}>
            {columns.map((column, index) => {
              return (
                <TableCell
                  align={column.align}
                  key={index}
                  sx={{ minWidth: column.width }}
                >
                  <Typography>{column.name}</Typography>
                </TableCell>
              );
            })}

            <TableCell sx={{ minWidth: 150 }} align="right">
              <Typography>Action</Typography>
            </TableCell>
          </TableHead>
          <TableBody>
            {data.map((contact, index) => {
              return (
                <TableRow key={index}>
                  {columns.map((column, index) => {
                    return (
                      <TableCell padding="none" key={index} sx={{ p: 0.5 }}>
                        {column.coverFileName ? (
                          <Stack
                            direction="row"
                            spacing={1}
                            alignItems="center"
                          >
                            <Avatar
                              src={contact.coverFileName ?? contact.fileName}
                            />
                            <Typography>{contact[column.attribute]}</Typography>
                          </Stack>
                        ) : column.attribute == "desc" ||
                          column.attribute == "description" ? (
                          <Typography
                            sx={{ m: 2, maxWidth: 250 }}
                            className="max-line-text-2"
                          >
                            {contact[column.attribute]}
                          </Typography>
                        ) : column.name == "Time" ? (
                          <Typography>
                            {toTime(contact[column.attribute])}
                          </Typography>
                        ) : column.name.includes("Date") ||
                          column.attribute == "createdAt" ? (
                          <Typography>
                            {toDateFormat(contact[column.attribute])}
                          </Typography>
                        ) : column.attribute == "link" ? (
                          <Stack
                            direction={"row"}
                            spacing={2}
                            alignItems="center"
                          >
                            <Typography
                              style={{ fontSize: 12, width: 150 }}
                              className="max-line-text-1"
                            >
                              {contact.link}
                            </Typography>
                            <IconButton
                              onClick={() => {
                                setOpenSnackbar(true);
                                navigator.clipboard.writeText(contact.link);
                              }}
                            >
                              <ContentCopyIcon size="small" color="primary" />
                            </IconButton>
                          </Stack>
                        ) : column.attribute == "disable" ? (
                          <div
                            style={{
                              backgroundColor: contact[column.attribute]
                                ? "#ffc0cb"
                                : "lightgreen",
                              borderRadius: 8,
                            }}
                          >
                            <Typography textAlign={"center"}>
                              {contact[column.attribute]
                                ? "Inactive"
                                : "Active"}
                            </Typography>
                          </div>
                        ) : column?.array ? (
                          <Typography textAlign={"center"}>
                            {contact[column.attribute]?.length}
                          </Typography>
                        ) : column.isName ? (
                          <Typography textAlign={"left"}>
                            {contact[column.attribute]?.name}
                          </Typography>
                        ) : column.attribute === "isActive" ? (
                          <div
                            style={{
                              backgroundColor: contact[column.attribute]
                                ? "lightgreen"
                                : "#ffc0cb",
                              borderRadius: 8,
                            }}
                          >
                            <Typography textAlign={"center"}>
                              {contact[column.attribute] ? "Present" : "Past"}
                            </Typography>
                          </div>
                        ) : column.attribute == "status" ? (
                          <div
                            style={{
                              padding: 4,
                              borderRadius: 8,
                              margin: 4,
                              backgroundColor: contact[column.attribute]
                                ? "#83e3e6"
                                : "#f23f48",
                            }}
                          >
                            {contact[column.attribute] ? (
                              <Typography align="center" fontSize={10}>
                                Contacted{" "}
                              </Typography>
                            ) : (
                              <Typography align="center" fontSize={10}>
                                Uncontacted
                              </Typography>
                            )}
                          </div>
                        ) : (
                          <Typography>{contact[column.attribute]}</Typography>
                        )}
                      </TableCell>
                    );
                  })}

                  <TableCell sx={{ width: 100 }} padding="none" align="right">
                    <Box>
                      {editFunc && (
                        <IconButton
                          onClick={() => editFunc(contact)}
                          sx={{ mr: 1 }}
                        >
                          <EditRoundedIcon
                            sx={{ fontSize: 20, color: "#1597BB" }}
                          />
                        </IconButton>
                      )}
                      <IconButton
                        aria-label="more"
                        aria-controls="long-menu"
                        aria-haspopup="true"
                        onClick={(e) => {
                          handleClick(e);
                          setActiveItem(contact);
                        }}
                      >
                        <MoreVertIcon />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
        <Menu
          id="long-menu"
          anchorEl={anchorEl}
          keepMounted
          open={open}
          onClose={handleClose}
          PaperProps={{}}
        >
          {changeStatusFunc && (
            <MenuItem>
              <ListItemIcon onClick={() => changeStatusFunc(activeItem)}>
                <CachedIcon style={{ fontSize: 20, color: "#1c54b2" }} />
              </ListItemIcon>
              <Typography>Status</Typography>
            </MenuItem>
          )}
          {disable ? (
            <MenuItem onClick={() => disableFunc(activeItem)}>
              <ListItemIcon>
                <CachedIcon color="primary" sx={{ fontSize: 20 }} />
              </ListItemIcon>
              <Typography>Restore</Typography>
            </MenuItem>
          ) : (
            <MenuItem onClick={() => disableFunc(activeItem)}>
              <ListItemIcon>
                <DeleteRoundedIcon sx={{ fontSize: 20, color: "#F70776" }} />
              </ListItemIcon>
              <Typography>Disable</Typography>
            </MenuItem>
          )}

          {createClassByPostFunc && (
            <MenuItem onClick={() => createClassByPostFunc(activeItem)}>
              <ListItemIcon>
                <ClassIcon color="primary" sx={{ fontSize: 20 }} />
              </ListItemIcon>
              <Typography>create a class</Typography>
            </MenuItem>
          )}

          {view && (
            <MenuItem
              onClick={() => router.push(`/${view}/${activeItem?._id}`)}
            >
              <ListItemIcon>
                <VisibilityIcon color="primary" sx={{ fontSize: 20 }} />
              </ListItemIcon>
              <Typography>View</Typography>
            </MenuItem>
          )}

          {disable && (
            <MenuItem onClick={() => deleteFunc(activeItem)}>
              <ListItemIcon>
                <DeleteForeverIcon sx={{ fontSize: 20, color: "#F70776" }} />
              </ListItemIcon>
              <Typography>Delete</Typography>
            </MenuItem>
          )}
        </Menu>
      </TableContainer>
      <Snackbar
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        open={openSnackbar}
        autoHideDuration={6000}
        onClose={() => setOpenSnackbar(false)}
        message={"Copied to clipboard! "}
        action={
          <IconButton onClick={() => setOpenSnackbar(false)}>
            <CloseIcon color="primary" />
          </IconButton>
        }
      />
      <div style={{ padding: 16 }}>
        <Pagination
          color="primary"
          count={pages}
          page={page}
          onChange={(e, value) => setPage(value)}
        />
      </div>
    </Paper>
  );
};

export default SabaiCodeTable;

SabaiCodeTable.propTypes = {};

SabaiCodeTable.defaultProps = {};
