import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Paper,
  TableContainer,
  Table,
  Typography,
  Box,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  IconButton,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import { ConfirmDialog } from "./../../presentations/dialogs";
import SortButton from "../../presentations/buttons/SortButton";
import EditRoundedIcon from "@mui/icons-material/EditRounded";
import DeleteRoundedIcon from "@mui/icons-material/DeleteRounded";
import useSWR from "swr";
import { useRouter } from "next/router";
import fetcher from "./../../../utils/func/api/getDataFunc";
import { toDateFormat } from "../../../utils/func/toDateFormat";
import useSocket from "../../../utils/func/socket/useSocket";
import SabaiCodeLoading from "../loading";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    padding: 8,
    overflow: "hidden",
    padding: "0px 20px",
    [theme.breakpoints.down("md")]: {
      padding: "0px 10px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "0px 5px",
    },
  },
  container: {
    maxHeight: 700,
  },
}));

const AttendanceCoaches = ({ year, month, setTotalHours, setCoach }) => {
  const classes = useStyles();
  const router = useRouter();
  const { id } = router.query;

  const [attendances, setAttendances] = React.useState([]);
  const [openDeleteAttendance, setOpenDeleteAttendance] = React.useState(false);
  const [dataUpdate, setDataUpdate] = React.useState(null);
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);

  const { data, error } = useSWR(
    id
      ? `${
          process.env.NEXT_PUBLIC_API_URL
        }/api/v1/admin/coach_time?coachId=${id}&year=${year}&month=${Number(
          month
        ) + 1}`
      : null,
    fetcher
  );

  const handleDeleteAttendance = (item) => {
    setOpenDeleteAttendance(true);
    setDataUpdate(item);
  };

  React.useEffect(() => {
    if (data?.data) {
      setTotalHours(data.total);
      setCoach(data.coach);
      setAttendances(data);
    }
  }, [data]);
  React.useEffect(() => {
    if (socket) {
      socket.on("attendance-coach", (data) => {
        console.log("socket:", data);
        setAttendances(data);
      });
    }
  }, [socket]);
  if (error) return `${error}`;
  if (!data) return <SabaiCodeLoading />;

  return (
    <Paper className={classes.root}>
      <TableContainer className={classes.container}>
        <Table>
          <TableHead>
            <TableCell sx={{ minWidth: 150 }}>
              <SortButton title="Class" />
            </TableCell>
            <TableCell sx={{ minWidth: 250 }}>
              <Typography variant="primary">
                <SortButton title="Course Name" />
              </Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 100 }}>
              <Typography variant="primary">Durations</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 120 }}>
              <Typography variant="primary">Date</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 100 }}>
              <Typography variant="primary">Students</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 120 }}>
              <Typography variant="primary">Action</Typography>
            </TableCell>
          </TableHead>
          <TableBody>
            {attendances?.data?.map((att, index) => {
              return (
                <TableRow key={index}>
                  <TableCell padding="none">
                    <Typography variant="primary">{att.class?.name}</Typography>
                  </TableCell>
                  <TableCell padding="none">
                    <Typography variant="primary">
                      Basic Web development
                    </Typography>
                  </TableCell>
                  <TableCell padding="none">
                    <Typography variant="primary">{att.hour} hours</Typography>
                  </TableCell>
                  <TableCell padding="none">
                    <Typography variant="primary">
                      {toDateFormat(att.createdAt)}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ minWidth: 100 }} padding="none">
                    <Typography align="right" variant="primary">
                      {att.class?.studentIds.length}
                    </Typography>
                  </TableCell>
                  <TableCell padding="none">
                    <Box>
                      {/* <IconButton
                        sx={{ mr: "10px" }}
                        onClick={() => handleEditAttendance}
                      >
                        <EditRoundedIcon
                          sx={{ fontSize: 20, color: "#1597BB" }}
                        />
                      </IconButton> */}
                      <IconButton onClick={() => handleDeleteAttendance(att)}>
                        <DeleteRoundedIcon
                          sx={{ fontSize: 20, color: "#F70776" }}
                        />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              );
            })}
            {/* Total Hours */}
            <TableRow>
              <TableCell>
                <Typography variant="primary">Total</Typography>
              </TableCell>
              <TableCell>
                <Typography variant="primary">{attendances.total}</Typography>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
      <ConfirmDialog
        open={openDeleteAttendance}
        message={"Do you want to delete attendance?"}
        onClose={() => setOpenDeleteAttendance(false)}
        url={`${process.env.NEXT_PUBLIC_API_URL}/api/v1/coach/coach_time/${dataUpdate?._id}`}
        disable={true} // for delete dialog
      />
    </Paper>
  );
};

export default AttendanceCoaches;

AttendanceCoaches.propTypes = {};

AttendanceCoaches.defaultProps = {};
