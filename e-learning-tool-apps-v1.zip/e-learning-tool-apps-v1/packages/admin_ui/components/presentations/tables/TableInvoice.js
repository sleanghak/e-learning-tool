import React, { useState } from "react";
import {
  Paper,
  TableContainer,
  Table,
  Typography,
  Box,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  IconButton,
  Avatar,
  Button,
  Menu,
  Pagination,
  Stack,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import EditRoundedIcon from "@mui/icons-material/EditRounded";
import PreviewIcon from "@mui/icons-material/Preview";
import {
  compareCurrentDate,
  toDateFormat,
} from "../../../utils/func/toDateFormat";

import MenuItem from "@mui/material/MenuItem";

import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import Fade from "@mui/material/Fade";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    overflow: "hidden",
    padding: "0px 20px",
  },
  container: {
    maxHeight: 700,
  },
}));

const TableInvoice = ({
  editFunc,
  disableFunc,
  previewFunc,
  status,
  startDate,
  endDate,
  page,
  setPage,
  socket,
  data,
}) => {
  const classes = useStyles();

  const [invoice, setInvoice] = React.useState({});
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleOpenStatus = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClosePopup = () => {
    setAnchorEl(null);
  };
  const handleChangeStatus = async (value, data) => {
    await updateDataFunc(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/invoice/${data._id}`,
      {
        status: value,
      }
    );
    console.log("status", value);
    socket?.emit("meta-invoice", { status: value, page, startDate, endDate });
    handleClosePopup();
  };

  return (
    <Paper className={classes.root}>
      <TableContainer className={classes.container}>
        <Table>
          <TableHead>
            <TableCell>
              <Typography sx={{ minWidth: 120 }}>Invoice</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 100 }}>
              <Typography>Reciever</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 150 }}>
              <Typography>Email</Typography>
            </TableCell>
            <TableCell>
              <Typography>Amount</Typography>
            </TableCell>
            <TableCell>
              <Typography>Discount</Typography>
            </TableCell>

            <TableCell sx={{ minWidth: 150 }} align="center">
              <Typography>Start Date</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 150 }} align="center">
              <Typography>Due Date</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 150 }}>
              <Typography>Paid Date</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 100 }}>
              <Typography>Status</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 100 }} align="right">
              <Typography>Action</Typography>
            </TableCell>
          </TableHead>
          <TableBody>
            {data?.map((inv, index) => {
              return (
                <TableRow key={index}>
                  <TableCell>
                    <Stack direction={"row"} spacing={1} alignItems="center">
                      <Avatar src={inv.coverFileName} />
                      <Typography>{inv.invoiceId}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Typography variant="primary">
                      {inv.partner ?? inv.studentIds?.length}
                    </Typography>
                  </TableCell>

                  <TableCell>
                    <Typography variant="primary">{inv.email}</Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="primary">{inv.amount} $</Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="primary">
                      {inv.discount ?? "____"} $
                    </Typography>
                  </TableCell>

                  <TableCell align="right">
                    <Typography>{toDateFormat(inv.createdAt)}</Typography>
                  </TableCell>
                  <TableCell align="right">
                    {compareCurrentDate(inv.dueDate) ? (
                      <Typography
                        sx={{ backgroundColor: "pink", borderRadius: 1, p: 1 }}
                      >
                        {toDateFormat(inv.dueDate)}
                      </Typography>
                    ) : (
                      <Typography>{toDateFormat(inv.dueDate)}</Typography>
                    )}
                  </TableCell>
                  <TableCell align="right">
                    {inv.status == "paid" && (
                      <Typography>{toDateFormat(inv.updatedAt)}</Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Box
                      sx={{
                        backgroundColor:
                          inv.status === "paid" ? "lightgreen" : "#ffc0cb",
                        borderRadius: 1,
                        p: 0.5,
                      }}
                    >
                      <Button
                        size="small"
                        startIcon={<EditRoundedIcon />}
                        aria-controls="fade-menu"
                        aria-haspopup="true"
                        fullWidth={true}
                        onClick={(e) => {
                          handleOpenStatus(e);
                          setInvoice(inv);
                        }}
                      >
                        {inv.status}
                      </Button>
                    </Box>
                  </TableCell>
                  <TableCell sx={{ minWidth: 150 }} align="right">
                    <Box>
                      <IconButton onClick={() => editFunc(inv)}>
                        <EditRoundedIcon
                          sx={{ color: "#1597BB" }}
                          size="small"
                        />
                      </IconButton>
                      <IconButton onClick={() => disableFunc(inv)}>
                        <DeleteForeverIcon color="error" size="small" />
                      </IconButton>
                      <IconButton onClick={() => previewFunc(inv)}>
                        <PreviewIcon sx={{ fontSize: 20 }} />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
        <Menu
          id="fade-menu"
          anchorEl={anchorEl}
          keepMounted
          open={open}
          onClose={handleClosePopup}
          TransitionComponent={Fade}
        >
          <MenuItem
            onClick={() => {
              handleChangeStatus("paid", invoice);
              console.log(invoice);
            }}
          >
            Paid
          </MenuItem>
          <MenuItem
            onClick={() => {
              handleChangeStatus("sent", invoice);
              console.log(invoice);
            }}
          >
            Sent
          </MenuItem>
        </Menu>
      </TableContainer>
      <div style={{ padding: 16 }}>
        <Pagination
          count={data.pages}
          color="primary"
          onChange={(e, value) => setPage(value)}
        />
      </div>
    </Paper>
  );
};

export default TableInvoice;

TableInvoice.propTypes = {};

TableInvoice.defaultProps = {};
