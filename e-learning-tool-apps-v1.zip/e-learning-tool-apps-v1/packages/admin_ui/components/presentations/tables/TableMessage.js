import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Paper,
  TableContainer,
  Table,
  Typography,
  Box,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  IconButton,
  Avatar,
  Stack,
} from "@mui/material";
import { makeStyles } from "@mui/styles";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import EditRoundedIcon from "@mui/icons-material/EditRounded";
import DeleteRoundedIcon from "@mui/icons-material/DeleteRounded";
import useSWR from "swr";
import fetcher from "./../../../utils/func/api/getDataFunc";
import { toDateFormat, toTime } from "../../../utils/func/toDateFormat";
import { convertFilePathToURL } from "../../../utils/func/s3";
import ClassIcon from "@mui/icons-material/Class";
import useSocket from "../../../utils/func/socket/useSocket";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { Dialog, ListItemIcon, Menu, MenuItem } from "@mui/material";
import Pagination from "@mui/lab/Pagination";
import SabaiCodeLoading from "../loading";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import ListPhoneNumber from "../lists/ListPhoneNumber";
import PublishedWithChangesIcon from "@mui/icons-material/PublishedWithChanges";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    overflow: "hidden",
    padding: "0px 20px",
  },
  container: {
    maxHeight: 700,
  },
}));

const TableMessage = ({
  changeStatusFunc,
  deleteFunc,
  status,
  page,
  setPage,
}) => {
  const classes = useStyles();
  const [posts, setPosts] = React.useState([]);

  const { data, error } = useSWR(
    `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/contact_us?page=${page}&status=${status}`,
    fetcher
  );
  const socket = useSocket(process.env.NEXT_PUBLIC_API_URL);
  React.useEffect(() => {
    // console.log(data);
    const getPostBySocket = async () => {
      if (data?.data) {
        setPosts(data.data);
      }
    };
    getPostBySocket();
  }, [data]);
  //   React.useEffect(() => {
  //     if (socket) {
  //       socket.on("post", (data) => {
  //         console.info("GET_POST_SOCKET");
  //         console.log(data);
  //         convertFilePathToURL(data).then((res) => {
  //           setPosts(res);
  //         });
  //       });
  //     }
  //   }, [socket]);
  if (error) return `${error}`;
  if (!data) return <SabaiCodeLoading />;

  return (
    <Paper className={classes.root}>
      <TableContainer className={classes.container}>
        <Table>
          <TableHead>
            <TableCell sx={{ minWidth: 150 }}>
              <Typography variant="primary">Name</Typography>
            </TableCell>

            <TableCell sx={{ minWidth: 100 }}>
              <Typography variant="primary">Subject</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 200 }}>
              <Typography variant="primary">Message</Typography>
            </TableCell>

            <TableCell sx={{ minWidth: 100 }}>
              <Typography variant="primary">Date</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 100 }} align="center">
              <Typography variant="primary">Status</Typography>
            </TableCell>
            <TableCell sx={{ minWidth: 150 }} align="right">
              <Typography variant="primary">Action</Typography>
            </TableCell>
          </TableHead>
          <TableBody>
            {posts.map((contact, index) => {
              return (
                <TableRow key={index}>
                  <TableCell padding="none">
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography>{contact.name}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell padding="none">
                    <Typography variant="primary">
                      {contact.subject?.name}
                    </Typography>
                  </TableCell>

                  <TableCell padding="none">
                    <Typography variant="primary">{contact.message}</Typography>
                  </TableCell>

                  <TableCell padding="none">
                    <Typography variant="primary">
                      {toDateFormat(contact.createdAt)}||
                      {toTime(contact.createdAt)}
                    </Typography>
                  </TableCell>
                  <TableCell padding="none" align="center">
                    <div
                      style={{
                        padding: 4,
                        borderRadius: 8,
                        margin: 4,
                        backgroundColor: contact.status ? "#83e3e6" : "#f23f48",
                      }}
                    >
                      {contact.disable ? (
                        <Typography align="center" fontSize={10}>
                          Contacted
                        </Typography>
                      ) : (
                        <Typography align="center" fontSize={10}>
                          Uncontacted
                        </Typography>
                      )}
                    </div>
                  </TableCell>

                  <TableCell
                    sx={{ minWidth: 120 }}
                    padding="none"
                    align="right"
                  >
                    <Box>
                      <IconButton onClick={() => changeStatusFunc(contact)}>
                        <PublishedWithChangesIcon
                          sx={{ fontSize: 20, color: "#1597BB" }}
                        />
                      </IconButton>
                      <IconButton
                        aria-label="more"
                        aria-controls="long-menu"
                        aria-haspopup="true"
                        onClick={() => deleteFunc(contact)}
                      >
                        <DeleteForeverIcon color="secondary" />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <div style={{ padding: 16 }}>
        <Pagination
          count={data.pages}
          color="primary"
          onChange={(e, value) => setPage(value)}
        />
      </div>
    </Paper>
  );
};

export default TableMessage;

TableMessage.propTypes = {};

TableMessage.defaultProps = {};
