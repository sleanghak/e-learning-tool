import React from "react";
import { makeStyles } from "@mui/styles";
import Card from "@mui/material/Card";
import CardActionArea from "@mui/material/CardActionArea";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { Tooltip } from "@mui/material";
import Link from "next/link";
import PropTypes from "prop-types";
const useStyles = makeStyles({
  root: {
    minWidth: `100%`,
  },
  media: {
    height: 140,
  },
});

export default function CourseCard({
  draft,
  image,
  imageTitle,
  name,
  desc,
  href,
  onClick,
  disableFunc,
  deleteFunc,
  restoreFunc,
}) {
  const classes = useStyles();

  return (
    <>
      <Card className={classes.root}>
        <Link href={href}>
          <CardActionArea>
            <CardMedia
              className={classes.media}
              image={image}
              title={imageTitle}
            />
            <CardContent>
              <Typography gutterBottom varaint="h5" component="h5">
                {name}
              </Typography>
              <Tooltip title={desc} arrow>
                <Typography
                  className="max-line-text-5"
                  variant="body2"
                  color="textSecondary"
                  component="p"
                >
                  {desc}
                </Typography>
              </Tooltip>
            </CardContent>
          </CardActionArea>
        </Link>
        <CardActions>
          {draft ? (
            <>
              <Button onClick={deleteFunc} size="small" color="secondary">
                Delete
              </Button>
              <Button size="small" color="primary" onClick={restoreFunc}>
                Restore
              </Button>
            </>
          ) : (
            <>
              <Button onClick={disableFunc} size="small" color="secondary">
                Disable
              </Button>
              <Button size="small" color="primary" onClick={onClick}>
                Update
              </Button>
            </>
          )}
        </CardActions>
      </Card>
    </>
  );
}
CourseCard.propTypes = {
  draft: PropTypes.bool,
  image: PropTypes.string,
  imageTitle: PropTypes.string,
  name: PropTypes.string,
  desc: PropTypes.string,
  href: PropTypes.string.isRequired,
  onClick: PropTypes.func,
  disableFunc: PropTypes.func,
  deleteFunc: PropTypes.func,
  restoreFunc: PropTypes.func,
};

CourseCard.defaultProps = {
  draft: false,
  image:
    "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201810/stockvault-person-studying-and-learning---knowledge-concept178241_0.jpeg?yCXmhi7e2ARwUtzHHlvtcrgETnDgFwCK&size=770:433",
  imageTitle: "image title",
  name: "Title",
  desc:
    "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially",
  href: "/course",
  onClick: undefined,
  disableFunc: undefined,
  deleteFunc: undefined,
  restoreFunc: undefined,
};
