import StudentInfo from "./StudentInfo";

import VideoLessonCard from "./VideoLessonCard";

import BackgroundCard from "./BackgroundCard";
import InfoCard from "./InfoCard";
export { StudentInfo, VideoLessonCard, BackgroundCard, InfoCard };
