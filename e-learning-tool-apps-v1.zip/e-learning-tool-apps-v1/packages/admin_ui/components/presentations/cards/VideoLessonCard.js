import React from "react";
import { makeStyles } from "@mui/styles";
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import PlayCircleFilledIcon from "@mui/icons-material/PlayCircleFilled";
import Typography from "@mui/material/Typography";
import ButtonBase from "@mui/material/ButtonBase";
import { IconButton } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import PropTypes from "prop-types";
const useStyles = makeStyles((theme) => ({
  root: {
    // maxWidth: 345,
    position: "relative",
    "& .tool": {
      float: "right",
      display: "none",
    },
    "&:hover .tool": {
      display: "block",
    },
  },
  media: {
    height: 0,
    paddingTop: "56.25%", // 16:9
  },
  icon: {
    position: "absolute",
    top: "30%",
    left: "46%",
    zIndex: 25,
    color: "red",
  },
}));

const VideoLessonCard = ({ url, name, desc, onClick }) => {
  const classes = useStyles();
  return (
    <Card className={classes.root}>
      <div className="tool">
        <IconButton>
          <MoreVertIcon />
        </IconButton>
      </div>
      <CardMedia
        onClick={onClick}
        className={classes.media}
        image={url}
        title={name}
      />
      <CardContent>
        <Typography
          style={{ color: "#000" }}
          color="textSecondary"
          component="h5"
        >
          {name}
        </Typography>
        <Typography
          className="max-line-text-2"
          variant="body2"
          color="textSecondary"
          component="p"
        >
          {desc}
        </Typography>
      </CardContent>
      <ButtonBase onClick={onClick} className={classes.icon}>
        <PlayCircleFilledIcon fontSize="large" />
      </ButtonBase>
    </Card>
  );
};

export default VideoLessonCard;

VideoLessonCard.propTypes = {
  url: PropTypes.string,
  name: PropTypes.string,
  desc: PropTypes.string,
  onClick: PropTypes.func,
};

VideoLessonCard.defaultProps = {
  url: "/?path=/story/presentations-cards-courscard--primary",
  name: "Video Lesson Card",
  desc:
    'hough the "loose" option was set to "false" in your @babel/preset-env config, it will not be used for @babel/plugin-proposal-private-property-in-object since the "loose" mode',
  onClick: undefined,
};
