import React from "react";
import { Card, CardMedia, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  root: {
    position: "relative",
  },
  text: {
    position: "absolute",
    bottom: 10,
    left: 25,
  },
}));
const BackgroundCard = ({ src, title }) => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Card>
        <CardMedia
          image={src}
          style={{
            width: "100%",
            height: "25vh",
          }}
        />
      </Card>
      <Typography variant="h4" color="primary" className={classes.text}>
        {title}
      </Typography>
    </div>
  );
};

export default BackgroundCard;
