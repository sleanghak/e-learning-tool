import { Paper, Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { useRouter } from "next/router";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    padding: 16,
    marginBottom: 30,
    textAlign: "center",
    cursor: "pointer",
  },
}));
const InfoCard = ({ label, amount, color, url }) => {
  const classes = useStyles();
  const router = useRouter();
  return (
    <Paper onClick={() => router.push(url)} className={classes.root}>
      <Typography style={{ color: color }} variant="h2">
        {amount}
      </Typography>
      <Typography>{label}</Typography>
    </Paper>
  );
};

export default InfoCard;
