import { BallTriangle } from "react-loading-icons";

const SabaiCodeLoading = () => {
  return <BallTriangle stroke="#06BCC1" strokeOpacity={1} />;
};

export default SabaiCodeLoading;
