import React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import Slide from "@mui/material/Slide";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
import deleteDataFunc from "../../../utils/func/api/deleteDataFunc";
import PropTypes from "prop-types";
import { Typography } from "@mui/material";
import Image from "next/image";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function ConfirmDialog({
  _id,
  open,
  onClose,
  message,
  desc,
  module,
  disable,
  status,
  query,
  socket,
}) {
  const handleDisable = async () => {
    /**
     * disable = true => delete item from database
     *
     * disable = false => update status of item  disable = true => disable = false
     * (active =>inactive) and vice versa )
     */
    if (disable) {
      const data = await deleteDataFunc(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/${module}/${_id}`
      );
      socket?.emit(`meta-${module}`, query);
      onClose();
    } else {
      const data = await updateDataFunc(
        `${
          process.env.NEXT_PUBLIC_API_URL
        }/api/v1/admin/${module}/disable/${_id}?status=${!status}`
      );
      socket?.emit(`meta-${module}`, query);
      onClose();
    }
  };
  return (
    <div>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={onClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle style={{ minWidth: 400 }} id="alert-dialog-slide-title">
          <Typography color="secondary">
            Do you want to {disable ? "delete" : status ? "restore" : "disable"}{" "}
            {module}?
          </Typography>
        </DialogTitle>
        <DialogContent style={{ textAlign: "center" }}>
          <Image
            src="/images/attention.svg"
            width={50}
            height={50}
            alt={"attention"}
          />
          <Typography style={{ marginTop: 10 }}>
            {disable && "It will delete forever. Are you sure?"}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose}>Cancel</Button>
          <Button onClick={handleDisable} color="secondary">
            Ok
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

ConfirmDialog.propTypes = {
  _id: PropTypes.string.isRequired,
  open: PropTypes.bool.isRequired,
  onClose: PropTypes.func,
  message: PropTypes.string.isRequired,
  desc: PropTypes.string,
  module: PropTypes.string.isRequired,
  disable: PropTypes.bool,
};
