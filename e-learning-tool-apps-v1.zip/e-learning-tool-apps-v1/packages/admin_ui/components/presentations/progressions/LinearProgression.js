import React from "react";
import { makeStyles } from "@mui/styles";
import LinearProgressWithLabel from "./LinearWithLabel";
import PropTypes from "prop-types";

const useStyles = makeStyles({
  root: {
    width: "100%",
  },
});

export default function LinearProgression({ increase = 0, show = false }) {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      {show && <LinearProgressWithLabel value={increase} />}
    </div>
  );
}

LinearProgression.propTypes = {
  increase: PropTypes.number,
  show: PropTypes.bool.isRequired,
};

LinearProgression.defaultProps = {
  increase: 50,
  show: false,
};
