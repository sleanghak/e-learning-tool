import LinearProgression from "./LinearProgression";
export {
    LinearProgression
}