import React from "react";
import { withStyles } from "@mui/styles";
import { Tabs, Tab } from "@mui/material";
import { useRouter } from "next/router";

const StyledTabs = withStyles((theme) => ({
  root: {
    backgroundColor: "#fff",
  },
  indicator: {
    display: "flex",
    justifyContent: "center",
    backgroundColor: "transparent",
    height: 5,

    "& > span": {
      maxWidth: 60,
      width: "100%",

      borderRadius: "8px 8px 0px 0px",
      backgroundColor: theme.palette.primary.main,
    },
  },
}))((props) => <Tabs {...props} TabIndicatorProps={{ children: <span /> }} />);

const StyledTab = withStyles((theme) => ({
  root: {
    textTransform: "none",
    color: "#5f6368",

    fontWeight: theme.typography.fontWeightRegular,
    fontSize: theme.typography.pxToRem(15),
    marginRight: theme.spacing(1),
    "&:focus": {
      opacity: 1,
    },
  },
}))((props) => <Tab disableRipple {...props} />);
const labels = [
  {
    name: "Invoices",
    path: "invoices",
  },
  {
    name: "Lessons",
    path: "lessons",
  },
  {
    name: "Stream",
    path: "stream",
  },
  {
    name: "Classwork",
    path: "classwork",
  },
  {
    name: "Student",
    path: "student",
  },
  {
    name: "Grade",
    path: "grade",
  },
];
const TabNavigation = ({ classId, tab }) => {
  const router = useRouter();
  const handleChange = (event, newMenu) => {
    console.log(newMenu);
    router.replace(
      {
        pathname: `/classes/${classId}`,
        query: { tab: newMenu },
      },
      undefined,
      { shallow: true }
    );
  };
  return (
    <StyledTabs
      indicatorColor="secondary"
      textColor="primary"
      onChange={handleChange}
      centered
      value={tab}
    >
      {labels.map((label, index) => {
        return <StyledTab value={label.path} key={index} label={label.name} />;
      })}
    </StyledTabs>
  );
};

export default TabNavigation;
