import React, { useState } from "react";
import PropTypes from "prop-types";
import { Box, ListItemButton, Typography, IconButton } from "@mui/material";
import { makeStyles } from "@mui/styles";
import PlayCircleOutlineRoundedIcon from "@mui/icons-material/PlayCircleOutlineRounded";
import LockRoundedIcon from "@mui/icons-material/LockRounded";
import DeleteRounded from "@mui/icons-material/DeleteRounded";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: "5px 0px",
  },
  sub_list_item: {
    display: "flex",
    alignItems: "center",
    width: "100%",
  },
  sub_list_item_icon: {
    color: "#7D7878",
    fontSize: 35,
    marginRight: 20,
    [theme.breakpoints.down("xs")]: {
      marginRight: 5,
    },
    [theme.breakpoints.down("sm")]: {
      fontSize: 25,
      marginRight: 10,
    },
  },
  sub_list_icon_lock: {
    color: "#7D7878",
    fonstSize: 25,
    [theme.breakpoints.down("sm")]: {
      fonstSize: 20,
    },
  },
  hover_detail_false: {
    color: "#7D7878",
    display: "flex",
    alignItems: "center",
    marginRight: "40px",
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
  },
  hover_detail_true: {
    display: "none",
  },
  sub_list_lock_box: {
    display: "flex",
    alignItems: "center",
  },
}));

const CourseSubList = ({ title, quiz, assignment, time, playFunc }) => {
  const classes = useStyles();
  const [hover, setHover] = useState(true);
  return (
    <ListItemButton onClick={playFunc} className={classes.root}>
      <Box
        className={classes.sub_list_item}
        onMouseOver={() => setHover(false)}
        onMouseOut={() => setHover(true)}
      >
        <PlayCircleOutlineRoundedIcon className={classes.sub_list_item_icon} />
        <Typography variant="secondary" noWrap sx={{ minWidth: 100 }}>
          {title}
        </Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Box
          className={
            hover ? classes.hover_detail_true : classes.hover_detail_false
          }
        >
          <Typography variant="secondary" sx={{ ml: "10px", maxWidth: 100 }}>
            {quiz} Quiz
          </Typography>
          <Typography variant="secondary" sx={{ ml: "10px", maxWidth: 100 }}>
            {assignment} Assignment
          </Typography>
        </Box>
        <Box className={classes.sub_list_lock_box}>
          <Typography
            variant="secondary"
            sx={{ display: { xs: "none", sm: "block" } }}
          >
            {time} min
          </Typography>
          {/* <IconButton>
            <DeleteRounded />
          </IconButton> */}
        </Box>
      </Box>
    </ListItemButton>
  );
};

export default CourseSubList;

CourseSubList.propTypes = {
  title: PropTypes.string.isRequired,
  quiz: PropTypes.number.isRequired,
  assignment: PropTypes.number.isRequired,
  time: PropTypes.string.isRequired,
};

CourseSubList.defaultProps = {};
