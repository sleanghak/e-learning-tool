import { Box, List, ListItem, ListItemIcon, ListItemText } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { Checkbox } from "@mui/material";
import deleteDataFunc from "../../../utils/func/api/deleteDataFunc";
import updateDataFunc from "../../../utils/func/api/updateDataFunc";
const ListPhoneNumber = ({ phones, postId }) => {
  const handleDeletePhone = async (phoneId) => {
    await deleteDataFunc(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/post/contact/${phoneId}/${postId}`
    );
  };
  const handleUpdateContact = async (phone) => {
    await updateDataFunc(
      `${process.env.NEXT_PUBLIC_API_URL}/api/v1/admin/post/contact/${
        phone._id
      }/${postId}?status=${!phone.status}`
    );
  };
  return (
    <List
      style={{
        maxHeight: "75vh",
        minWidth: 350,
      }}
    >
      <ListItem>
        <ListItemText>Student Register </ListItemText>
        <ListItemIcon>Total: {phones.length}</ListItemIcon>
      </ListItem>
      {phones.map((item, index) => {
        return (
          <ListItem key={index}>
            <ListItemIcon onClick={() => handleDeletePhone(item._id)}>
              <DeleteIcon color="secondary" />
            </ListItemIcon>
            <ListItemText>{item.phone}</ListItemText>
            <ListItemIcon>
              <Checkbox
                onChange={() => handleUpdateContact(item)}
                color="primary"
                checked={item.status}
              />
            </ListItemIcon>
          </ListItem>
        );
      })}
    </List>
  );
};

export default ListPhoneNumber;
