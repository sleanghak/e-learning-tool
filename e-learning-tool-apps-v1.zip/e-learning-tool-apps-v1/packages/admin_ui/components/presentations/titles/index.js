import HeadPageTitle from "./HeadPageTitle";

export {
    HeadPageTitle
}