import React from "react";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  title: {
    backgroundImage:
      "url(https://static.vecteezy.com/system/resources/thumbnails/001/879/853/small/geometric-technology-background-free-vector.jpg)",
    textAlign: `center`,
    textTransform: `uppercase`,
    borderBottomWidth: 2,
    borderBottomStyle: `solid`,
    borderBottomColor: "#555555",
    marginBottom: 10,
    padding: 25,
    color: "#FFFFFF",
  },
}));
const HeadPageTitle = ({ title, url }) => {
  const classes = useStyles();
  return <h2 className={classes.title}>{title}</h2>;
};

export default HeadPageTitle;
