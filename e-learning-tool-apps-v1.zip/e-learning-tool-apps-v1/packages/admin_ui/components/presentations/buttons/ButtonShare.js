import React from "react";
import ShareIcon from "@mui/icons-material/Share";
import Button from "@mui/material/Button";
import { FacebookShareButton } from "react-share";
const domain = "www.sabaicode.com";
const quote =
  "Sabai code is school where provide the best coding and robotics class for the students who are hunger to learn and extend their knowledge in technology";
const ShareButton = ({ bgColor }) => {
  return (
    <div>
      <FacebookShareButton url={domain} quote={quote} hashtag="#SabaiCode">
        <Button
          style={{
            width: 200,
            height: 50,
            padding: 10,
            borderRadius: 20,
            borderwidth: 5,
            color: "white",
          }}
          variant="outlined"
          startIcon={<ShareIcon style={{ marginRight: 10 }} />}
        >
          Share This
        </Button>
      </FacebookShareButton>
    </div>
  );
};

export default ShareButton;
