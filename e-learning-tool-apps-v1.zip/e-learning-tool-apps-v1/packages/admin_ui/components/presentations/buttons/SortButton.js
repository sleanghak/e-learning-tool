import React, { useState, } from 'react';
import PropTypes from 'prop-types';
import {
    Button,
    Typography,
} from '@mui/material';
import { makeStyles } from '@mui/styles';
import KeyboardArrowUpRoundedIcon from '@mui/icons-material/KeyboardArrowUpRounded';
import KeyboardArrowDownRoundedIcon from '@mui/icons-material/KeyboardArrowDownRounded';

const useStyles = makeStyles((theme) => ({
    root: {
        borderRadius: 0,
        paddingLeft: 0,
    }
}));

const SortButton = ({
    title,
}) => {
    const classes = useStyles();
    const [sort, setSort] = useState(true);
    return (
        <Button
            variant='text'
            className={classes.root}
            onClick={()=>{setSort(!sort)}}
            endIcon={
                sort ? <KeyboardArrowUpRoundedIcon /> : <KeyboardArrowDownRoundedIcon />
            }
        >
            <Typography
                variant='primary'
            >
                {title}
            </Typography>
        </Button>
    );
}

export default SortButton;

SortButton.propTypes = {
    title: PropTypes.string.isRequired,
};

SortButton.defaultProps = {
    title: 'class',
};