import React from "react";
import { FacebookIcon, LinkedinIcon } from "react-share";
import { SocialIcon } from "react-social-icons";
import { ButtonGroup, Stack } from "@mui/material";
const facebookUrl = "https://web.facebook.com/sabaicode";
const linkedinUrl = "https://www.linkedin.com/company/sabaicode";
const youtubeUrl = "https://www.youtube.com/channel/UCc0MApkzNAeFyEk9-hGAOeg/";

const GroupSocialMedia = () => {
  return (
    <ButtonGroup>
      <Stack direction={"row"} spacing={3.5} justifyContent="space-evenly">
        <a href={facebookUrl}>
          <FacebookIcon size={40} round={true} />
        </a>

        <SocialIcon
          network="youtube"
          url={youtubeUrl}
          style={{ width: 40, height: 40 }}
        />
        <a href={linkedinUrl}>
          <LinkedinIcon size={40} round={true} />
        </a>
      </Stack>
    </ButtonGroup>
  );
};
export default GroupSocialMedia;
