import MuiAlert from "@mui/lab/Alert";
import PropTypes from "prop-types";
/**
 *
 * @param {*}  // type : warn, info, warning, error
 * @returns
 */
function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}
const Message = ({ message, type, open }) => {
  return <>{open && <Alert severity={type}>{message}</Alert>}</>;
};

export default Message;

Message.propTypes = {
  message: PropTypes.string.isRequired,
  type: PropTypes.oneOf(["success", "warning"]),
  open: PropTypes.bool,
};

Message.defaultProps = {
  message: "Message",
  type: "success",
  open: false,
};
