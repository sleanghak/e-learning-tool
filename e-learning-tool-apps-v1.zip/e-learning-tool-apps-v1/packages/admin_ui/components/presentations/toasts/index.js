import { toast } from "react-toastify";

const character = {
  position: "top-right",
  autoClose: 5000,
  hideProgressBar: false,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: true,
  progress: undefined,
};
function customToast(statusCode, message) {
  if (statusCode == 200 || statusCode == 201) {
    toast.success(message, character);
  } else if (statusCode == 400 || statusCode == 404 || statusCode == 500) {
    toast.error(message, character);
  } else {
    toast.error(message, character);
  }
}
async function customPromiseToast(fetchAPI) {
  const data = await toast.promise(fetchAPI, {
    pending: "Operator is processing",
    success: "Operator is success",
    error: "Operator is error",
  });
  customToast(data.statusCode, data.message);
}

export { customToast, customPromiseToast };
