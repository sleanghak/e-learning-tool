import React from "react";
import Paper from "@mui/material/Paper";
import InputBase from "@mui/material/InputBase";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
import { Stack } from "@mui/material";

export default function SearchBox({ query, setQuery }) {
  const [text, setText] = React.useState("");
  return (
    <Paper component="form">
      <Stack direction={"row"} alignItems="center" sx={{ padding: "2px 4px" }}>
        <IconButton aria-label="menu">
          <MenuIcon />
        </IconButton>
        <InputBase
          onChange={(e) => setQuery(e.target.value)}
          sx={{ ml: 1, flex: 1 }}
          value={query}
          placeholder="Search Student"
          inputProps={{ "aria-label": "search student" }}
        />
        <Divider sx={{ height: "28px", m: 0.5 }} orientation="vertical" />
        <IconButton
          color="primary"
          sx={{ p: 1.5 }}
          aria-label="directions"
          onClick={() => setQuery(text)}
        >
          <SearchIcon />
        </IconButton>
      </Stack>
    </Paper>
  );
}
